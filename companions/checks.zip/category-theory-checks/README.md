# Category Theory: finite computational checks

This archive contains readable Python checkers for the released lectures of
Category Theory for Mathematical Physics. Code and comments are in English.
The same mathematical conventions apply to both language editions.

## What a check establishes

The output distinguishes EXACT arithmetic, SYMBOLIC identities and NUMERICAL
calculations with floating-point tolerances. A control deliberately tests a
wrong formula and succeeds when that formula is rejected. Read the printed
claim beside each result; an `OK` line applies to that claim and its stated
instance. A successful run does not prove a universal theorem, a classification,
a cited construction, or the physical interpretation of a model. The proofs
and their hypotheses remain in the lecture notes. Pictures are not certified
by these algebra scripts.

## Read and run

Extract the archive, then open the `category-theory-checks` directory in a
terminal. Its `scripts/` directory contains the original lecture checkers and
the shared `anyons.py` and `pentagon.py` helpers that the selected files import.
No course repository, private lecture source, TeX installation or sibling
workspace is needed for the independent checks.

Use a Python environment with the packages in `requirements.txt`. The bundle
was tested with Python 3.11.14, NumPy 1.26.4, SymPy 1.14.0 and mpmath 1.3.0.
These package pins record the tested environment, rather than claiming that
every other version fails. The runner does not download or install anything.
If you need a separate environment and package installation is available:

```sh
python3 -m venv .venv
. .venv/bin/activate
python3 -m pip install -r requirements.txt
```

On Windows, activate the environment with `.venv\Scripts\activate` instead.
Read the source files before running them. Then use:

```sh
python3 run_checks.py --list
python3 run_checks.py 7
python3 run_checks.py --independent
```

The first command lists the released checkers. Replace `7` by a listed lecture
number to run one file. The last command runs all released independent checks.
Some symbolic checks take longer than a minute. Each checker runs in a
separate Python process and returns a nonzero exit status if a claim fails.
Keep the folder structure intact so that local helper imports resolve.

## Lecture 8: an additional representation package

The `--independent` selection explicitly leaves out this lecture.

The original Lecture 8 checker compares its classical limit with
`rep-engine==0.0.3`. That package is **not included** in this archive. The build
machine used version 0.0.3 from a local sibling source checkout of the
`rep-engine` project. Its project metadata declares the MIT license, but no
standalone upstream license notice was available in that checkout or the
installed distribution, so this companion does not redistribute its source.
The course makes no claim that this local package is available from a public
package index. `requirements-l8.txt` records the extra version requirement.

If you already have that version, or have access to the corresponding source
package and can install it in your Python environment, run:

```sh
python3 run_checks.py 8
python3 run_checks.py --all
```

Selecting Lecture 8 without its dependency fails with an explanation. The
runner never silently skips that comparison. The Lecture 8 source remains
readable even when you cannot run it. The comparison uses the raw rational
backend; Sage and the optional gmpy2 speedup are not required.

## Scope and provenance

The archive contains only original `check-lN-algebra.py` files whose lectures
are released in English, plus the Python helpers they require. Source-locking
checks that inspect private TeX files, exercise-sheet solutions, build tools,
review material and repository metadata are excluded. The complete scripts
retain their original checks and negative controls; no test is disabled for
this download.

`manifest.json` lists the released lecture numbers, selected checkers, tested
dependencies and SHA-256 hashes of every payload file. The runner verifies
those hashes before execution. This detects accidental changes to the
extracted files; it is not an authenticity signature. To verify without
running the mathematics:

```sh
python3 run_checks.py --verify-only
```

Released lecture checkers in this archive: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14.

