#!/usr/bin/env python3
"""Run the released lecture checks from this extracted companion directory."""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent


def main() -> int:
    manifest = json.loads((ROOT / 'manifest.json').read_text(encoding='utf-8'))
    checks = {str(item['lecture']): item for item in manifest['checks']}
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('lectures', nargs='*', metavar='N',
                        help='released lecture numbers to run')
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--all', action='store_true', help='run every released checker, including Lecture 8')
    group.add_argument('--independent', action='store_true', help='run released checkers without the extra Lecture 8 dependency')
    group.add_argument('--list', action='store_true', help='list released checkers')
    group.add_argument('--verify-only', action='store_true', help='verify payload hashes without running checks')
    args = parser.parse_args()
    unknown = set(args.lectures) - checks.keys()
    if unknown:
        parser.error(f'not released in this archive: {", ".join(sorted(unknown))}')
    if args.lectures and any((args.all, args.independent, args.list, args.verify_only)):
        parser.error('choose lecture numbers or one named selection')

    for name, expected in manifest['files'].items():
        file = ROOT / name
        if not file.is_file() or hashlib.sha256(file.read_bytes()).hexdigest() != expected:
            print(f'Payload verification failed: {name}. Extract a fresh copy of the archive.', file=sys.stderr)
            return 1
    print(f'Payload verified: {len(manifest["files"])} files.', flush=True)
    if args.verify_only:
        return 0
    if args.list or not (args.lectures or args.all or args.independent):
        for lecture, item in checks.items():
            extra = ' [requires external rep-engine 0.0.3]' if item['external'] else ''
            print(f'Lecture {lecture}: {item["path"]}{extra}')
        print('\nRun one lecture by number, --independent, or --all.')
        return 0

    selected = list(checks) if args.all else [n for n, item in checks.items() if not item['external']] if args.independent else args.lectures
    if args.independent and '8' in checks:
        print('Selection: independent checks. Lecture 8 is not selected; it requires the separate rep-engine package.', flush=True)
    packages = ['numpy', 'sympy', 'mpmath'] + (['rep-engine'] if '8' in selected else [])
    for package in packages:
        try:
            version = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError:
            print(f'Missing dependency: {package}. See README.md; no checks have been skipped.', file=sys.stderr)
            return 1
        if package == 'rep-engine' and version != '0.0.3':
            print(f'Lecture 8 requires rep-engine 0.0.3; found {version}. See README.md.', file=sys.stderr)
            return 1
        print(f'Dependency: {package} {version}', flush=True)

    # Isolated mode ignores ambient PYTHONPATH and the user site. Only the
    # extracted scripts directory is added for the course's local helpers.
    bootstrap = 'import runpy,sys; sys.path.insert(0,sys.argv[1]); runpy.run_path(sys.argv[2],run_name="__main__")'
    environment = {key: value for key, value in os.environ.items()
                   if key not in {'PYTHONPATH', 'PYTHONHOME'}}
    for lecture in selected:
        item = checks[lecture]
        print(f'\n=== Lecture {lecture}: {item["path"]} ===', flush=True)
        result = subprocess.run([sys.executable, '-I', '-c', bootstrap,
                                 str(ROOT / 'scripts'), str(ROOT / item['path'])],
                                cwd=ROOT, env=environment)
        if result.returncode:
            print(f'Lecture {lecture} failed (exit {result.returncode}).', file=sys.stderr)
            return result.returncode
    print(f'\nPassed {len(selected)} selected lecture checker(s).')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
