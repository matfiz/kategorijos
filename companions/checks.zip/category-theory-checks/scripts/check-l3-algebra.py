"""Algebra script for Lecture 3, *Monoidal categories and string diagrams*.

Every formula, number and diagram equation that lectures/lec03.tex prints is checked here
before it is printed, on instances, labelled SYMBOLIC, EXACT or NUMERICAL, most with a
control that must fail.  A string-diagram equation is checked as an equation between
composites of Kronecker products of matrices: time runs upward (a box drawn above another
acts after it), and the left strand is the first (slow) Kronecker factor (Bible K1).  The
diagram equations of L3 are exact equalities, with no scalar.

Conventions (Bible K20): the associator runs (X (x) Y) (x) Z -> X (x) (Y (x) Z); the unitors
are l_X: 1 (x) X -> X and r_X: X (x) 1 -> X.  In skeletal Vec_G^omega the associator of
simple objects is alpha_{g,h,k} = omega(g, h, k) id, and a monoidal functor that is the
identity on objects has J_{g,h} = j(g, h) id and J_0 = j0 id.

Run:  python3 scripts/check-l3-algebra.py     (exit status 1 on failure)
"""
import itertools
import sys

import numpy as np
import sympy as sp

FAILS = []
RNG = np.random.default_rng(20261023)


def check(label, kind, ok, what):
    print(f"{'OK  ' if ok else 'FAIL'} [{kind:9s}] {label}: {what}")
    if not ok:
        FAILS.append(label)


def control(label, kind, failed, what):
    check(label + ' (control)', kind, failed, what + ' -- must fail, and does')


def crandn(*shape):
    return RNG.standard_normal(shape) + 1j * RNG.standard_normal(shape)


def close(a, b, tol=1e-10):
    return np.allclose(a, b, atol=tol, rtol=0)


K = np.kron

# ================================================================ S3.1 the definition
# ex:3:mat -- Mat_C with the Kronecker product is strict: (A (x) B) (x) C = A (x) (B (x) C)
# exactly, and the 1x1 matrix 1 is a unit on both sides.
A, B, C = crandn(2, 3), crandn(3, 2), crandn(2, 2)
check('ex:3:mat(associative)', 'NUMERICAL', close(K(K(A, B), C), K(A, K(B, C))),
      'Kronecker: (A (x) B) (x) C = A (x) (B (x) C) as matrices')
check('ex:3:mat(unit)', 'NUMERICAL', close(K(np.eye(1), A), A) and close(K(A, np.eye(1)), A),
      '1 (x) A = A = A (x) 1 for the 1 x 1 identity')
control('ex:3:mat(unit)', 'NUMERICAL', not close(K(2 * np.eye(1), A), A),
        'the 1 x 1 matrix (2) is a unit for the Kronecker product')

# ex:3:vect -- in Vect the associator (u (x) v) (x) w -> u (x) (v (x) w) is natural:
# alpha o ((f (x) g) (x) h) = (f (x) (g (x) h)) o alpha.  In coordinates (slow index first)
# both triple products are the same column, so alpha is the identity matrix.
u, v, w = crandn(2), crandn(3), crandn(2)
check('ex:3:vect(alpha)', 'NUMERICAL', close(K(K(u, v), w), K(u, K(v, w))),
      'in coordinates (slow index first) alpha is the identity matrix: Kronecker associativity')

# ex:3:rep -- Rep(G): g acts on V (x) W by rho_V(g) (x) rho_W(g), a homomorphism.
S3 = list(itertools.permutations(range(3)))


def rho(s):
    M = np.zeros((3, 3))
    for i in range(3):
        M[s[i], i] = 1
    return M


def comp(s, t):
    return tuple(s[t[i]] for i in range(3))


check('ex:3:rep', 'EXACT', all(close(K(rho(comp(s, t)), rho(comp(s, t))),
                                     K(rho(s), rho(s)) @ K(rho(t), rho(t))) for s in S3 for t in S3),
      'g -> rho(g) (x) rho(g) is a representation on C^3 (x) C^3 (interchange)')
control('ex:3:rep', 'EXACT', not all(close(K(rho(comp(s, t)), rho(comp(s, t))),
                                           K(rho(t), rho(t)) @ K(rho(s), rho(s))) for s in S3 for t in S3),
        'g -> rho(g) (x) rho(g) reversing the order of multiplication')

# ================================================================ S3.3 interchange
f, g = crandn(3, 2), crandn(2, 3)
h, k = crandn(2, 2), crandn(4, 2)
check('thm:3:interchange', 'NUMERICAL', close(K(g, k) @ K(f, h), K(g @ f, k @ h)),
      '(g (x) k) o (f (x) h) = (g o f) (x) (k o h)')
control('thm:3:interchange', 'NUMERICAL', not close(K(g, k) @ K(f, h), K(k @ h, g @ f)),
        'the factors exchanged on one side')
# eq:3:slide -- (id (x) h) o (f (x) id) = f (x) h = (f (x) id) o (id (x) h)
fs, hs = crandn(3, 2), crandn(4, 5)
one_two = K(np.eye(3), hs) @ K(fs, np.eye(5))
two_one = K(fs, np.eye(4)) @ K(np.eye(2), hs)
check('eq:3:slide', 'NUMERICAL', close(one_two, K(fs, hs)) and close(two_one, K(fs, hs)),
      'boxes on different strands slide past each other: all three pictures agree')
control('eq:3:slide', 'NUMERICAL', not close(K(fs, hs), K(hs, fs)),
        'f (x) h = h (x) f (the strands exchanged)')

# ================================================================ S3.4 Eckmann-Hilton
# thm:3:scalars -- in a strict monoidal category s o t = s (x) t = t (x) s = t o s for
# s, t in End(1).  In Vect, End(C) = C and (x) of 1x1 matrices is their product.
s1, t1 = crandn(1, 1), crandn(1, 1)
check('thm:3:scalars', 'NUMERICAL',
      close(s1 @ t1, K(s1, t1)) and close(K(s1, t1), K(t1, s1)) and close(K(t1, s1), t1 @ s1),
      's o t = s (x) t = t (x) s = t o s for scalars')
check('thm:3:scalars(interchange steps)', 'NUMERICAL',
      close(K(s1, np.eye(1)) @ K(np.eye(1), t1), K(s1, t1))
      and close(K(np.eye(1), t1) @ K(s1, np.eye(1)), K(s1, t1)),
      '(s (x) id) o (id (x) t) = s (x) t = (id (x) t) o (s (x) id), with 1 (x) 1 = 1')
# eq:3:floating -- a scalar box beside f: s (x) f = s f, and it may float to any height
fv = crandn(3, 2)
# the printed equation: the scalar box beside f, below it and above it (same side):
# (f (x) id_1) o (id_X (x) s) = (id_Y (x) s) o (f (x) id_1), with 1 = C (1 x 1)
fsq = crandn(2, 3)
check('eq:3:floating', 'NUMERICAL',
      close(K(fsq, np.eye(1)) @ K(np.eye(3), s1), K(np.eye(2), s1) @ K(fsq, np.eye(1))),
      'the scalar box slides up beside f on the same side (interchange)')
# control: in a strict monoidal category whose tensor of scalar arrows is twisted by
# complex conjugation on the strand X (f (x) h = f sigma_a(h), sigma_X = conjugation; the
# model of C.3-L03 round 2), s (x) id_X and id_X (x) s differ: the scalar cannot cross X.
lam = 1j
control('eq:3:floating(cross the strand)', 'NUMERICAL', not np.isclose(lam, np.conj(lam)),
        'in the conjugation-twisted model, s (x) id_X = lambda equals id_X (x) s = conj(lambda)')
check('eq:3:floating(Vect)', 'NUMERICAL', close(K(s1, fv), s1[0, 0] * fv) and close(K(fv, s1), s1[0, 0] * fv),
      'in Vect, with bilinear tensor, s (x) f = f (x) s = s f: the scalar floats anywhere')
# non-commuting End(X) for X != 1, as a control: End(C^2) is not commutative
a2, b2 = crandn(2, 2), crandn(2, 2)
control('thm:3:scalars', 'NUMERICAL', not close(a2 @ b2, b2 @ a2), 'End(X) is commutative for X = C^2')

# ================================================================ S3.5 Vec_G^omega
def pentagon_ok(omega, G, mul):
    """The pentagon for alpha_{g,h,k} = omega(g,h,k) id, on every quadruple: the two paths
    (W(x)X)(x)Y)(x)Z -> W(x)(X(x)(Y(x)Z)) multiply out to
        omega(gh,k,m) omega(g,h,km)   and   omega(g,h,k) omega(g,hk,m) omega(h,k,m)."""
    bad = []
    for g_, h_, k_, m_ in itertools.product(G, repeat=4):
        two = omega(mul(g_, h_), k_, m_) * omega(g_, h_, mul(k_, m_))
        three = omega(g_, h_, k_) * omega(g_, mul(h_, k_), m_) * omega(h_, k_, m_)
        if sp.simplify(two - three) != 0:
            bad.append((g_, h_, k_, m_))
    return bad


# thm:3:vecgw(Z2) -- normalised omega on Z2 = {0, 1} (1 = s): only omega(s,s,s) = eps is free
eps = sp.Symbol('epsilon')
Z2 = [0, 1]
mul2 = lambda a, b: (a + b) % 2                          # noqa: E731
om = lambda g_, h_, k_: eps if (g_, h_, k_) == (1, 1, 1) else 1  # noqa: E731
eqs = set()
for g_, h_, k_, m_ in itertools.product(Z2, repeat=4):
    two = om(mul2(g_, h_), k_, m_) * om(g_, h_, mul2(k_, m_))
    three = om(g_, h_, k_) * om(g_, mul2(h_, k_), m_) * om(h_, k_, m_)
    e = sp.simplify(two - three)
    if e != 0:
        eqs.add(sp.factor(e))
check('thm:3:vecgw(Z2 equations)', 'SYMBOLIC', eqs == {sp.factor(1 - eps ** 2)} or eqs == {sp.factor(eps ** 2 - 1)},
      'of the 16 pentagons only (s,s,s,s) is not automatic, and it reads 1 = eps^2')
check('thm:3:vecgw(Z2 solutions)', 'SYMBOLIC', set(sp.solve(1 - eps ** 2, eps)) == {1, -1},
      'eps = omega(s,s,s) = +1 or -1')
check('thm:3:vecgw(Z2 instance)', 'EXACT',
      sp.sympify(om(1, 1, 1)).subs(eps, -1) ** 2 == 1
      and pentagon_ok(lambda a, b, c: sp.sympify(om(a, b, c)).subs(eps, -1), Z2, mul2) == [],
      'omega(s,s,s) = -1 passes all 16 pentagons')
control('thm:3:vecgw(Z2 instance)', 'EXACT',
        pentagon_ok(lambda a, b, c: sp.sympify(om(a, b, c)).subs(eps, sp.I), Z2, mul2) != [],
        'omega(s,s,s) = i passes the pentagons')


# ex:3:z2(normalisation) -- h = 1 in the pentagon, using the triangle,
# gives w(g,k,m) = w(g,k,m) w(1,k,m).  Here 0 is the group identity.
# Keep w(1,k,m) free so this verifies the substitution, not just a pre-normalised table.
wfree = {t: sp.Symbol('v' + ''.join(map(str, t)), nonzero=True)
         for t in itertools.product(Z2, repeat=3)}
wnorm = lambda a, b, c: sp.Integer(1) if b == 0 else wfree[(a, b, c)]
normalisation_steps = []
for a, c, d in itertools.product(Z2, repeat=3):
    two = wnorm(mul2(a, 0), c, d) * wnorm(a, 0, mul2(c, d))
    three = wnorm(a, 0, c) * wnorm(a, c, d) * wnorm(0, c, d)
    normalisation_steps.append(sp.simplify(two - three
                               - wnorm(a, c, d) * (1 - wnorm(0, c, d))) == 0)
# With first-slot normalisation now established, k = 1 leaves only w(g,h,1).
wnorm_first = lambda a, b, c: sp.Integer(1) if a == 0 or b == 0 else wfree[(a, b, c)]
for a, b, d in itertools.product(Z2, repeat=3):
    two = wnorm_first(mul2(a, b), 0, d) * wnorm_first(a, b, d)
    three = wnorm_first(a, b, 0) * wnorm_first(a, b, d) * wnorm_first(b, 0, d)
    normalisation_steps.append(sp.simplify(two - three
                               - wnorm_first(a, b, d) * (1 - wnorm_first(a, b, 0))) == 0)
check('ex:3:z2(normalisation substitution)', 'SYMBOLIC', all(normalisation_steps),
      'h = 1 gives w(g,k,m) = w(g,k,m) w(1,k,m); nonzero factors cancel')
control('ex:3:z2(normalisation substitution)', 'EXACT',
        pentagon_ok(lambda a, b, c: 2 if (a, b, c) == (0, 1, 1) else 1, Z2, mul2) != [],
        'the triangle alone permits w(1,s,s) = 2, but the pentagon does not')


# ex:3:zn -- EGNO (2.34): omega_p(a,b,c) = exp(2 pi i p a (b + c - [b+c]_N) / N^2) is a
# normalised 3-cocycle on Z_N; check N = 2, 3, 4 and every p.
def omega_p(N, p):
    return lambda a, b, c: sp.exp(2 * sp.pi * sp.I * p * a * (b + c - (b + c) % N) / N ** 2)


ok = True
for N in (2, 3, 4):
    ZN = list(range(N))
    mulN = lambda a, b, N=N: (a + b) % N               # noqa: E731
    for p in range(N):
        w_ = omega_p(N, p)
        ok &= pentagon_ok(w_, ZN, mulN) == []
        ok &= all(sp.simplify(w_(a, 0, c) - 1) == 0 for a in ZN for c in ZN)
check('ex:3:zn', 'SYMBOLIC', ok, 'omega_p is a normalised 3-cocycle on Z_N for N = 2, 3, 4, all p')
check('ex:3:zn(Z2)', 'SYMBOLIC', sp.simplify(omega_p(2, 1)(1, 1, 1) + 1) == 0,
      'for N = 2, p = 1: omega(s,s,s) = exp(2 pi i * 2 / 4) = -1')
bad = lambda a, b, c: sp.exp(2 * sp.pi * sp.I * a * (b + c) / 9)  # noqa: E731
control('ex:3:zn', 'SYMBOLIC', pentagon_ok(bad, list(range(3)), lambda a, b: (a + b) % 3) != [],
        'without the carry term -[b+c]_N (N = 3, p = 1) omega is a cocycle')
triv = lambda a, b, c: sp.exp(2 * sp.pi * sp.I * a * (b + c - (b + c) % 3) / 3)  # noqa: E731
check('ex:3:zn(N not N^2)', 'SYMBOLIC', all(sp.simplify(triv(a, b, c) - 1) == 0 for a in range(3) for b in range(3) for c in range(3)),
      'with N in place of N^2 the formula is identically 1: the N^2 matters')

# ex:3:s3z3 -- the tensor product separates Rep(S3) from Rep(Z3): std (x) std = 1 (+) sgn (+) std,
# while the characters of Z3 multiply, chi_i (x) chi_j = chi_{i+j}.
Fm = sp.Matrix([[1, 0], [-1, 1], [0, -1]])


def rho3(s_):
    M = sp.zeros(3, 3)
    for i in range(3):
        M[s_[i], i] = 1
    return M


def std(s_):
    return (Fm.T * Fm).inv() * Fm.T * rho3(s_) * Fm


def sgn(s_):
    return sp.Matrix([[rho3(s_).det()]])


def triv(s_):
    return sp.Matrix([[1]])


def kron(Am, Bm):
    return sp.kronecker_product(Am, Bm)


def homdim(Ar, Br):
    da, db = Ar(S3[0]).shape[0], Br(S3[0]).shape[0]
    T = sp.Matrix(db, da, sp.symbols(f't0:{da * db}'))
    eqs = []
    for s_ in S3:
        eqs += list(T * Ar(s_) - Br(s_) * T)
    Mx = sp.Matrix([[sp.diff(e, t) for t in T] for e in eqs])
    return da * db - Mx.rank()


stst = lambda s_: kron(std(s_), std(s_))                # noqa: E731
mults = [homdim(irr, stst) for irr in (triv, sgn, std)]
check('ex:3:s3z3(std x std)', 'EXACT', mults == [1, 1, 1] and 4 == 1 + 1 + 2,
      'std (x) std = 1 (+) sgn (+) std: multiplicities 1, 1, 1 and dimensions 4 = 1 + 1 + 2')
w3 = sp.exp(2 * sp.pi * sp.I / 3)
check('ex:3:s3z3(Z3)', 'SYMBOLIC', all(sp.simplify(w3 ** (i * k) * w3 ** (j * k) - w3 ** (((i + j) % 3) * k)) == 0
                                       for i in range(3) for j in range(3) for k in range(3)),
      'chi_i (x) chi_j = chi_{i+j} for the characters chi_j(k) = w^{jk} of Z3')
control('ex:3:s3z3(std x std)', 'EXACT', homdim(stst, stst) != 1,
        'std (x) std is simple (End = C), as for a tensor product of characters')

# eq:3:vectpentagon -- in Vect both paths send ((w (x) x) (x) y) (x) z to w (x) (x (x) (y (x) z)):
# in coordinates every bracketing is the same Kronecker column.
w4, x4, y4, z4 = crandn(2), crandn(2), crandn(3), crandn(2)
check('eq:3:vectpentagon', 'NUMERICAL', close(K(K(K(w4, x4), y4), z4), K(w4, K(x4, K(y4, z4)))),
      'in coordinates every bracketing is the same Kronecker column, so both pentagon paths agree')

# rem:3:coboundary -- the coherence omega' j(h,k) j(g,hk) = j(g,h) j(gh,k) omega says
# omega' = omega (delta j)^{-1} with (delta j)(g,h,k) = j(h,k) j(g,hk) / (j(gh,k) j(g,h)) (Bible K20);
# and if omega, omega' are normalised, the condition at (g,1,h) gives j(g,1) = j(1,h).
jgen = {(a, b): sp.Symbol(f'J{a}{b}', nonzero=True) for a in Z2 for b in Z2}
dj = lambda a, b, c: jgen[(b, c)] * jgen[(a, mul2(b, c))] / (jgen[(mul2(a, b), c)] * jgen[(a, b)])  # noqa: E731
wsym = {t: sp.Symbol('w' + ''.join(map(str, t)), nonzero=True) for t in itertools.product(Z2, repeat=3)}
ok = True
for t in itertools.product(Z2, repeat=3):
    a, b, c = t
    wprime = sp.solve(sp.Eq(sp.Symbol('wp') * jgen[(b, c)] * jgen[(a, mul2(b, c))],
                            jgen[(a, b)] * jgen[(mul2(a, b), c)] * wsym[t]), sp.Symbol('wp'))[0]
    ok &= sp.simplify(wprime - wsym[t] / dj(a, b, c)) == 0
check('rem:3:coboundary', 'SYMBOLIC', ok, "the coherence gives omega' = omega (delta j)^{-1}, delta j as in K20")
control('rem:3:coboundary', 'SYMBOLIC',
        any(sp.simplify(sp.solve(sp.Eq(sp.Symbol('wp') * jgen[(b, c)] * jgen[(a, mul2(b, c))],
                                       jgen[(a, b)] * jgen[(mul2(a, b), c)] * wsym[(a, b, c)]), sp.Symbol('wp'))[0]
                        - wsym[(a, b, c)] * dj(a, b, c)) != 0 for a, b, c in itertools.product(Z2, repeat=3)),
        "omega' = omega (delta j), the opposite sign convention")
step = sp.solve(sp.Eq(1 * jgen[(0, 1)] * jgen[(1, 1)], jgen[(1, 0)] * jgen[(1, 1)] * 1), jgen[(1, 0)])
check('rem:3:coboundary(normalised)', 'SYMBOLIC', step == [jgen[(0, 1)]],
      'normalised omega, omega\': the condition at (s,1,s) gives j(s,1) = j(1,s)')

# ================================================================ S3.6 monoidal functors
# thm:3:vecgw(inequivalent) -- an identity-on-objects monoidal functor Vec_Z2^omega ->
# Vec_Z2^omega' with J_{g,h} = j(g,h) id, J_0 = j0 id: the unit axioms (trivial unitors,
# omega normalised) force j(1,g) = j(g,1) = 1/j0, and the coherence (Bible K20)
#   omega'(g,h,k) j(h,k) j(g,hk) = j(g,h) j(gh,k) omega(g,h,k)
# at (s,s,s) then reads omega'(s,s,s) = omega(s,s,s).
j0, jss, ep, epp = sp.symbols('j0 j_ss epsilon epsilon_p')
jf = lambda a, b: 1 / j0 if 0 in (a, b) else jss        # noqa: E731
lhs = epp * jf(1, 1) * jf(1, mul2(1, 1))
rhs = jf(1, 1) * jf(mul2(1, 1), 1) * ep
check('thm:3:vecgw(inequivalent)', 'SYMBOLIC', sp.solve(sp.Eq(lhs, rhs), epp) == [ep],
      "at (s,s,s) the coherence gives omega'(s,s,s) = omega(s,s,s): eps is invariant")
# the coherence at every triple, for the normalised j: consistent with omega' = omega
ok = all(sp.simplify(om(a, b, c) * jf(b, c) * jf(a, mul2(b, c)) - jf(a, b) * jf(mul2(a, b), c) * om(a, b, c)) == 0
         for a, b, c in itertools.product(Z2, repeat=3))
check('thm:3:vecgw(identity functor)', 'SYMBOLIC', ok,
      "with omega' = omega every normalised j satisfies the coherence (any j_ss, j0)")

# prop:3:z2 (normalised coboundaries) -- if omega' = omega * delta j is normalised whenever
# omega is, then j(g,1) = j(1,h) for all g, h, and the ratio at (s,s,s) is 1.
ja = {(a, b): sp.Symbol(f'j{a}{b}') for a in Z2 for b in Z2}
ratio = lambda a, b, c: ja[(a, b)] * ja[(mul2(a, b), c)] / (ja[(b, c)] * ja[(a, mul2(b, c))])  # noqa: E731
norm_eqs = [sp.numer(sp.together(ratio(a, 0, c) - 1)) for a in Z2 for c in Z2]
sol = sp.solve(norm_eqs, [ja[(1, 0)], ja[(0, 1)]], dict=True)
check('prop:3:z2(normalised coboundary)', 'SYMBOLIC',
      all(sp.simplify(ratio(1, 1, 1).subs(sd) - 1) == 0 for sd in sol) and len(sol) > 0,
      'a coboundary that keeps omega normalised has ratio 1 at (s,s,s)')
control('prop:3:z2(normalised coboundary)', 'SYMBOLIC', sp.simplify(ratio(1, 1, 1) - 1) != 0,
        'an arbitrary coboundary (j(s,1), j(1,s) free) has ratio 1 at (s,s,s)')

print()
if FAILS:
    print(f'{len(FAILS)} FAILED: ' + ', '.join(FAILS))
    sys.exit(1)
print('All L3 checks pass.')
