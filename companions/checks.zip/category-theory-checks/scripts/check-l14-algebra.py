"""Algebra script for Lecture 14, *Topological quantum field theory: a synthesis*.

This script checks, on instances: the 1D snake v = sum_i a_i ev(b_i (x) v) and the trace
ev o P o coev = dim V; Mednykh's Z(Sigma_g) = #Hom(pi_1 Sigma_g, G)/|G| = sum_chi
(|G|/dim chi)^{2g-2} by brute force for Z2 and S3 (genus 2: 81); the Frobenius algebra of
class functions with the unnormalised convolution and eps(f) = f(1)/|G|, built from its
structure constants, whose handle element w = mu Delta iota gives eps(w^g) = Mednykh; the
counit trap (rescaling eps by lambda, with Delta recomputed, multiplies Z(Sigma_g) by
lambda^{1-g}) and the convolution trap (the normalised convolution gives 27/2 at genus 2);
dim V(T^2) = rank Z(Vec_G) for Z2 (4) and S3 (8) as commuting pairs up to simultaneous
conjugation; and the framing anomaly: p_+/p_- = e^{2 pi i c/4}, so Fibonacci (c = 14/5) is
anomalous and the toric code is not; the three-fermion model (c = 4) is anomaly-free when
the square root of dim C may be negative (Bakalov-Kirillov, p_+ = p_- = -2) and anomalous
with the positive root (p_+/sqrt(dim C) = -1).  Every check is
EXACT (fractions, integers) or NUMERICAL; some carry a control that must fail.

Run:  python3 scripts/check-l14-algebra.py     (exit status 1 on failure)
"""
import cmath
import itertools
import math
import pathlib
import sys
from fractions import Fraction

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import anyons  # noqa: E402

FAILS = []


def check(label, kind, ok, what):
    print(f"{'OK  ' if ok else 'FAIL'} [{kind:9s}] {label}: {what}")
    if not ok:
        FAILS.append(label)


def control(label, kind, failed, what):
    """failed must be True: the false statement `what` is refuted."""
    check(label + ' (control)', kind, failed, what + ' -- must fail, and does')


# ---------------------------------------------------------------- groups
S3 = list(itertools.permutations(range(3)))
m3 = lambda p, q: tuple(p[q[i]] for i in range(3))                        # noqa: E731
i3 = lambda p: tuple(sorted(range(3), key=lambda i: p[i]))                 # noqa: E731
e3 = (0, 1, 2)
Z2 = [0, 1]
m2 = lambda a, b: (a + b) % 2                                             # noqa: E731
i2 = lambda a: a                                                          # noqa: E731


def count_hom_surface(G, mul, inv, e, g):
    """#Hom(pi_1 Sigma_g, G): 2g-tuples with prod_i [a_i, b_i] = e (brute force)."""
    comm = {}
    for a in G:
        for b in G:
            comm[a, b] = mul(mul(a, b), mul(inv(a), inv(b)))
    # distribution of a single commutator value, then convolve g times
    dist = {}
    for v in comm.values():
        dist[v] = dist.get(v, 0) + 1
    total = {e: 1}
    for _ in range(g):
        new = {}
        for x, cx in total.items():
            for y, cy in dist.items():
                z = mul(x, y)
                new[z] = new.get(z, 0) + cx * cy
        total = new
    return total.get(e, 0)


def mednykh(order, dims, g):
    return sum(Fraction(order, d) ** (2 * g - 2) for d in dims)


ok = True
for G, mul, inv, e, dims in [(S3, m3, i3, e3, [1, 1, 2]), (Z2, m2, i2, 0, [1, 1])]:
    for g in range(0, 4):
        ok &= Fraction(count_hom_surface(G, mul, inv, e, g), len(G)) == mednykh(len(G), dims, g)
check('thm:14:dw(Mednykh)', 'EXACT', ok, 'S3 and Z2, genus 0..3: #Hom(pi_1 Sigma_g, G)/|G| = sum_chi (|G|/dim chi)^{2g-2}')
z_s3_2 = Fraction(count_hom_surface(S3, m3, i3, e3, 2), 6)
check('thm:14:dw(S3)', 'EXACT', z_s3_2 == 81 and mednykh(6, [1, 1, 2], 2) == 81 and mednykh(6, [1, 1, 2], 1) == 3,
      'S3 at genus 2: 486/6 = 36 + 36 + 9 = 81; at genus 1: 3 = number of classes')
control('thm:14:dw(S3)', 'EXACT', mednykh(6, [1, 1, 2], 2) != sum(Fraction(d, 6) ** 2 for d in [1, 1, 2]),
        'the exponent is 2 - 2g with (|G|/dim chi), i.e. sum (dim chi/|G|)^{2g-2}')

# ---------------------------------------------------------------- the Frobenius algebra of class functions
def class_algebra(G, mul, inv, e, norm=1):
    """class indicators 1_K as a basis; (f*h)(x) = norm * sum_{yz=x} f(y) h(z); returns the
    classes, the structure constants and the unit (in the class basis)."""
    classes = []
    for g in G:
        K = frozenset(mul(mul(h, g), inv(h)) for h in G)
        if K not in classes:
            classes.append(K)
    idx = {g: i for i, K in enumerate(classes) for g in K}
    n = len(classes)
    mult = [[[Fraction(0)] * n for _ in range(n)] for _ in range(n)]
    for a, K in enumerate(classes):
        for b, L in enumerate(classes):
            for y in K:
                for z in L:
                    mult[a][b][idx[mul(y, z)]] += Fraction(norm)
    for a in range(n):                          # (1_K * 1_L)(x) counts each x in a class; the coefficient of 1_M is the value at one x
        for b in range(n):
            for c in range(n):
                mult[a][b][c] /= len(classes[c])
    unit = [Fraction(0)] * n
    unit[idx[e]] = Fraction(1, norm)
    return classes, mult, unit, idx[e]


def times(mult, u, v):
    n = len(u)
    return [sum(u[a] * v[b] * mult[a][b][c] for a in range(n) for b in range(n)) for c in range(n)]


# Character idempotents for the unnormalised convolution used in the lecture.
classes_s3, mult_s3, unit_s3, identity_class = class_algebra(S3, m3, i3, e3)
sign_s3 = lambda p: (-1) ** sum(p[i] > p[j] for i in range(3) for j in range(i + 1, 3))
characters_s3 = [(1, lambda p: 1), (1, sign_s3),
                 (2, lambda p: sum(p[i] == i for i in range(3)) - 1)]
idempotents = [[Fraction(d, 6) * chi(i3(next(iter(K)))) for K in classes_s3]
               for d, chi in characters_s3]
check('thm:14:dw(idempotents)', 'EXACT',
      all(times(mult_s3, u, v) == (u if j == k else [Fraction(0)] * len(classes_s3))
          for j, u in enumerate(idempotents) for k, v in enumerate(idempotents))
      and all(u[identity_class] / 6 == Fraction(d, 6) ** 2
              for u, (d, _) in zip(idempotents, characters_s3)),
      'e_chi(x)=(dim chi/|G|) chi(x^(-1)): orthogonal convolution idempotents and epsilon(e_chi)=(dim chi/|G|)^2 for S3')
control('thm:14:dw(idempotents)', 'EXACT',
        any(times(mult_s3, [6 * x / d for x in u], [6 * x / d for x in u])
            != [6 * x / d for x in u] for u, (d, _) in zip(idempotents, characters_s3)),
        'the character itself, without dim chi/|G|, is the convolution idempotent')

# The 2--3 Pachner move: same boundary, one new internal edge.
from collections import Counter


def boundary_faces(tetrahedra):
    counts = Counter(tuple(sorted(face)) for tetra in tetrahedra
                     for face in itertools.combinations(tetra, 3))
    return {face for face, count in counts.items() if count == 1}


two_tetrahedra = [(0, 1, 2, 3), (0, 1, 2, 4)]
three_tetrahedra = [(0, 1, 3, 4), (1, 2, 3, 4), (0, 2, 3, 4)]
edges_two = {tuple(sorted(edge)) for tetra in two_tetrahedra for edge in itertools.combinations(tetra, 2)}
edges_three = {tuple(sorted(edge)) for tetra in three_tetrahedra for edge in itertools.combinations(tetra, 2)}
check('thm:14:tv(2-3)', 'EXACT',
      boundary_faces(two_tetrahedra) == boundary_faces(three_tetrahedra)
      and edges_three - edges_two == {(3, 4)},
      'the labelled bipyramid replaces two tetrahedra sharing face 012 by three sharing the new edge 34')
control('thm:14:tv(2-3)', 'EXACT',
        boundary_faces(two_tetrahedra) != boundary_faces(three_tetrahedra[:2]),
        'two tetrahedra on the right suffice to fill the same bipyramid boundary')


def inverse(M):
    n = len(M)
    A = [row[:] + [Fraction(int(i == j)) for j in range(n)] for i, row in enumerate(M)]
    for c in range(n):
        p = next(r for r in range(c, n) if A[r][c] != 0)
        A[c], A[p] = A[p], A[c]
        A[c] = [x / A[c][c] for x in A[c]]
        for r in range(n):
            if r != c and A[r][c] != 0:
                A[r] = [x - A[r][c] * y for x, y in zip(A[r], A[c])]
    return [row[n:] for row in A]


def z_frobenius(G, mul, inv, e, genus, lam=1, norm=1):
    """Z(Sigma_g) = eps(w^g), w = mu o Delta o iota = sum_{ab} (B^{-1})_{ab} e_a e_b, with the
    Frobenius pairing B_ab = eps(e_a e_b) and eps(f) = lam f(1)/|G|; Delta is the one the pairing fixes."""
    classes, mult, unit, i1 = class_algebra(G, mul, inv, e, norm)
    n = len(classes)
    eps = lambda f: lam * f[i1] / len(G)                                          # noqa: E731  f(1) is the coefficient of 1_{e}
    basis = [[Fraction(int(i == j)) for j in range(n)] for i in range(n)]
    B = [[eps(times(mult, basis[a], basis[b])) for b in range(n)] for a in range(n)]
    Binv = inverse(B)
    w = [Fraction(0)] * n
    for a in range(n):
        for b in range(n):
            w = [x + Binv[a][b] * y for x, y in zip(w, times(mult, basis[a], basis[b]))]
    power = unit
    for _ in range(genus):
        power = times(mult, power, w)
    return eps(power)


ok = all(z_frobenius(G, mul, inv, e, g) == mednykh(len(G), dims, g)
         for G, mul, inv, e, dims in [(S3, m3, i3, e3, [1, 1, 2]), (Z2, m2, i2, 0, [1, 1])] for g in range(0, 4))
check('thm:14:dw(handle)', 'EXACT', ok,
      'class functions, (f*h)(x) = sum_{yz=x} f(y)h(z), eps(f) = f(1)/|G|, built from structure constants: '
      'eps(w^g) with w = mu Delta iota equals Mednykh for S3 and Z2, genus 0..3')
lam = 6
ok = all(z_frobenius(S3, m3, i3, e3, g, lam=lam) == Fraction(lam) ** (1 - g) * mednykh(6, [1, 1, 2], g) for g in range(0, 4))
check('thm:14:dw(scale)', 'EXACT', ok, 'eps rescaled by lambda = 6, Delta recomputed from the pairing: Z(Sigma_g) gains lambda^{1-g}')
control('thm:14:dw(scale)', 'EXACT', z_frobenius(S3, m3, i3, e3, 2, lam=lam) != 81, 'the genus-2 value does not depend on the counit')
control('thm:14:dw(convolution)', 'EXACT', z_frobenius(S3, m3, i3, e3, 2, norm=Fraction(1, 6)) == Fraction(27, 2),
        'the normalised convolution (1/|G|) sum_{yz=x} gives the same Z(Sigma_2) = 81 (it gives 27/2)')

# ---------------------------------------------------------------- 1D: the snake and the trace
# V = C^3 with a non-orthonormal basis a_i (columns of Bm) and W = V^* with the dual basis b_i
# (rows of Bm^{-1}); coev(1) = sum_i a_i (x) b_i, ev(b (x) v) = b(v).  Round 1's slip (ev(v (x) a_i),
# with v in V) was a type error: under any identification of V with V^* it reconstructs v as well,
# so no numerical check sees it; the types are kept apart here by construction.
Bm = [[Fraction(1), Fraction(2), Fraction(0)], [Fraction(0), Fraction(1), Fraction(3)], [Fraction(1), Fraction(0), Fraction(1)]]
Bt = [list(col) for col in zip(*Bm)]                             # a_i = Bt[i]
Binv = inverse(Bm)                                               # b_i = Binv[i]  (Binv @ Bm = 1)
dot = lambda u, v: sum(x * y for x, y in zip(u, v))              # noqa: E731
ok = True
for trial in range(3):
    v = [Fraction(k * k + trial, 1 + k) for k in range(3)]
    snake = [sum(Bt[i][k] * dot(Binv[i], v) for i in range(3)) for k in range(3)]       # sum_i a_i ev(b_i (x) v)
    ok &= snake == v
trace = sum(dot(Binv[i], Bt[i]) for i in range(3))                # ev o P o coev = sum_i b_i(a_i)
check('thm:14:atiyah', 'EXACT', ok and trace == 3,
      'V = C^3, a_i a non-orthonormal basis of V, b_i the dual basis of V^*: v = sum_i a_i ev(b_i (x) v), and ev o P o coev = dim V = 3')

# ---------------------------------------------------------------- dim V(T^2) = rank Z(C)
def commuting_orbits(G, mul, inv):
    """commuting pairs (a, b) up to simultaneous conjugation: the 3D state space on T^2."""
    pairs = {(a, b) for a in G for b in G if mul(a, b) == mul(b, a)}
    orbits = set()
    for a, b in pairs:
        orbits.add(frozenset((mul(mul(h, a), inv(h)), mul(mul(h, b), inv(h))) for h in G))
    return len(orbits), len(pairs)


n_s3, pairs_s3 = commuting_orbits(S3, m3, i3)
n_z2, _ = commuting_orbits(Z2, m2, i2)
check('thm:14:rt(torus)', 'EXACT', n_s3 == 8 and n_z2 == 4,
      'dim V(T^2) = commuting pairs up to conjugation = rank Z(Vec_G): 4 for Z2 (the toric code), 8 for S3')
control('thm:14:rt(torus)', 'EXACT', n_s3 != Fraction(pairs_s3, 6),
        'the 3D state space on T^2 is the 2D partition function Z(T^2) = #Hom(Z^2, G)/|G| = 3')

# ---------------------------------------------------------------- the framing anomaly
def gauss(model):
    L = model.L
    th = {a: model.theta(a) for a in L}
    p_plus = sum(model.d[a] ** 2 * th[a] for a in L)
    p_minus = sum(model.d[a] ** 2 / th[a] for a in L)
    return p_plus, p_minus


fib = anyons.fibonacci()
pp, pm = gauss(fib)
c_fib = 14 / 5
check('thm:14:rt(anomaly)', 'NUMERICAL', abs(pp / pm - cmath.exp(2j * math.pi * c_fib / 4)) < 1e-9 and abs(pp / pm - 1) > 1e-6,
      'Fibonacci: p_+/p_- = e^{2 pi i c/4} with c = 14/5, not 1: RT(Fib) carries a framing anomaly')
tc = anyons.toric_code()
pp_t, pm_t = gauss(tc)
check('thm:14:rt(centre)', 'NUMERICAL', abs(pp_t / pm_t - 1) < 1e-9,
      'the toric code, a centre: p_+ = p_-, no anomaly (c = 0)')
theta3 = [1, -1, -1, -1]                                                  # three fermions: four invertibles, theta = 1, -1, -1, -1
p3_plus, p3_minus = sum(theta3), sum(1 / t for t in theta3)
c3 = (8 * cmath.phase(p3_plus / math.sqrt(len(theta3))) / (2 * math.pi)) % 8              # p_+/D = e^{2 pi i c/8}, D = sqrt(dim) = 2
check('thm:14:rt(mod 4)', 'NUMERICAL', abs(c3 - 4) < 1e-9 and abs(p3_plus / p3_minus - 1) < 1e-12,
      'the three-fermion model: p_+ = p_- = -2, so c = 4 (from the Gauss sum) and, with the square root of dim C free in sign '
      '(the root -2 = p_+), no anomaly: then the condition is c = 0 mod 4, not c = 0')
D3, Dtc = math.sqrt(len(theta3)), 2.0                                      # D > 0: sqrt(dim C), dim = 4 for both
check('thm:14:rt(mod 8)', 'NUMERICAL', abs(p3_plus / D3 + 1) < 1e-12 and abs(pp_t / Dtc - 1) < 1e-9,
      'with the positive root of dim C the gluing phase p_+/sqrt(dim C) = e^{2 pi i c/8} is -1 for the three fermions (c = 4) and 1 for the toric code (c = 0): '
      'the condition is c = 0 mod 8')
control('thm:14:rt(mod 8)', 'NUMERICAL', abs(p3_plus / D3 - 1) > 1e-6, 'with the positive root the three-fermion model is anomaly-free (c = 0 mod 4 suffices)')
semion = anyons.pointed_z2(-1, 1j)
pp_s, pm_s = gauss(semion)
control('thm:14:rt(anomaly)', 'NUMERICAL', abs(pp_s / pm_s - 1) > 1e-6, 'the anomaly vanishes whenever c != 0 (the semion has c = 1)')

print()
if FAILS:
    print(f'{len(FAILS)} FAILED: ' + ', '.join(FAILS))
    sys.exit(1)
print('All L14 checks pass.')
