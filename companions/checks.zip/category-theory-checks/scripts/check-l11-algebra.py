"""Algebra script for Lecture 11, *Algebras in tensor categories and module categories*.

This script checks, on instances, the module pentagon of a rank-one module category over
Vec_H^omega and its cocycle equation (bible K21: psi(g,h) psi(gh,k) = omega(g,h,k) psi(h,k)
psi(g,hk), and EGNO's printed omega = d psi as the wrong sign), the associativity of the
twisted group algebra C_psi[H] in Vec_G^omega (the same equation), the obstruction on Z_2
with omega(s,s,s) = -1 (no psi at all), the simple modules of C_psi[H] in Vec_G as cosets,
the semisimple internal Hom [M, N] = (+)_c Hom(c (x) M, N) (x) c on Vec_G's modules, and the
count of indecomposable module categories over Vec_Z2 and Vec_{Z2 x Z2}.  Every check is
EXACT (sympy) or brute force over roots of unity; some carry a control that must fail.

Run:  python3 scripts/check-l11-algebra.py     (exit status 1 on failure)
"""
import cmath
import itertools
import math
import random
import sys

import sympy as sp

FAILS = []


def check(label, kind, ok, what):
    print(f"{'OK  ' if ok else 'FAIL'} [{kind:9s}] {label}: {what}")
    if not ok:
        FAILS.append(label)


def control(label, kind, failed, what):
    check(label + ' (control)', kind, failed, what + ' -- must fail, and does')


close = lambda a, b, tol=1e-9: abs(complex(a) - complex(b)) < tol           # noqa: E731


# ---------------------------------------------------------------- groups as tables
def cyclic(n):
    G = list(range(n))
    return G, (lambda a, b: (a + b) % n), 0


def z2z2():
    G = [(a, b) for a in range(2) for b in range(2)]
    return G, (lambda x, y: ((x[0] + y[0]) % 2, (x[1] + y[1]) % 2)), (0, 0)


def k21_defect(G, mul, omega, psi):
    """max over g,h,k of |psi(g,h) psi(gh,k) - omega(g,h,k) psi(h,k) psi(g,hk)| (bible K21)."""
    return max(abs(psi[g, h] * psi[mul(g, h), k] - omega[g, h, k] * psi[h, k] * psi[g, mul(h, k)])
               for g in G for h in G for k in G)


def module_pentagon_defect(G, mul, omega, psi):
    """EGNO (7.2) for the rank-one module category Vec over Vec_G^omega, m_{g,h} = psi(g,h):
    m_{X,Y,Z(x)M} m_{X(x)Y,Z,M} = (id (x) m_{Y,Z,M}) m_{X,Y(x)Z,M} (a_{X,Y,Z} (x) id)."""
    return max(abs(psi[g, h] * psi[mul(g, h), k] - psi[h, k] * psi[g, mul(h, k)] * omega[g, h, k])
               for g in G for h in G for k in G)


def assoc_defect(G, mul, omega, psi):
    """C_psi[G] in Vec_G^omega: mu (mu (x) id) = mu (id (x) mu) a, with a = omega on (gh)k -> g(hk)."""
    return max(abs(psi[g, h] * psi[mul(g, h), k] - omega[g, h, k] * psi[h, k] * psi[g, mul(h, k)])
               for g in G for h in G for k in G)


# ================================================================ S11.2 the module associator (K21)
G3, m3, e3 = cyclic(3)
random.seed(11)
psi = {(g, h): (1 if e3 in (g, h) else cmath.exp(2j * math.pi * random.random())) for g in G3 for h in G3}
# omega solving K21 for this psi: omega = psi(g,h) psi(gh,k) / (psi(h,k) psi(g,hk)) = (d psi)^{-1}
omega = {(g, h, k): psi[g, h] * psi[m3(g, h), k] / (psi[h, k] * psi[g, m3(h, k)]) for g in G3 for h in G3 for k in G3}
dpsi = {(g, h, k): psi[h, k] * psi[g, m3(h, k)] / (psi[g, h] * psi[m3(g, h), k]) for g in G3 for h in G3 for k in G3}
check('thm:11:assoc(pentagon)', 'NUMERICAL', module_pentagon_defect(G3, m3, omega, psi) < 1e-12 and k21_defect(G3, m3, omega, psi) < 1e-12,
      'Z3, random psi: the module pentagon of Vec over Vec^omega with m = psi is K21, with omega = (d psi)^{-1}')
control('thm:11:assoc(pentagon)', 'NUMERICAL', module_pentagon_defect(G3, m3, dpsi, psi) > 1e-6,
        'EGNO Ex. 7.8.3 / (9.13) as printed: omega = d psi')
check('thm:11:assoc(algebra)', 'NUMERICAL', assoc_defect(G3, m3, omega, psi) < 1e-12,
      'the same psi makes C_psi[Z3] associative in Vec_{Z3}^omega: algebra associativity is the module pentagon')

# the obstruction: Vec_Z2^omega with omega(s,s,s) = -1 has no module category Vec (no psi at all, normalised or not)
G2, m2, e2 = cyclic(2)
x = sp.symbols('x0:4')                                       # psi(e,e), psi(e,s), psi(s,e), psi(s,s)
P = {(0, 0): x[0], (0, 1): x[1], (1, 0): x[2], (1, 1): x[3]}
t = sp.Symbol('t')


def system(om):
    eqs = [P[g, h] * P[m2(g, h), k] - om(g, h, k) * P[h, k] * P[g, m2(h, k)] for g in G2 for h in G2 for k in G2]
    return eqs + [t * x[0] * x[1] * x[2] * x[3] - 1]           # every psi(g,h) != 0


om_minus = lambda g, h, k: -1 if (g, h, k) == (1, 1, 1) else 1          # noqa: E731
om_plus = lambda g, h, k: 1                                               # noqa: E731
gb_minus = sp.groebner(system(om_minus), *x, t, order='lex')
gb_plus = sp.groebner(system(om_plus), *x, t, order='lex')
check('thm:11:assoc(Z2)', 'EXACT', list(gb_minus.exprs) == [1],
      'omega(s,s,s) = -1 on Z2: the K21 equations have no solution with every psi(g,h) != 0 (Groebner basis {1})')
control('thm:11:assoc(Z2)', 'EXACT', list(gb_plus.exprs) != [1], 'omega = 1 on Z2 also admits no psi')

# ================================================================ S11.2 simples of Mod(C_psi[H]) are the cosets G/H
# A = C_psi[H] in Vec_G (omega = 1).  An A-module in Vec_G is a G-graded space with M_g . h -> M_{gh}.  The free
# module delta_g (x) A has End = C (it is simple) and delta_g (x) A ~ delta_{g'} (x) A iff gH = g'H.


def coset_rep(G, mul, H, g):
    return frozenset(mul(g, h) for h in H)


def free_hom_dim(G, mul, H, g1, g2):
    """dim Hom_A(delta_g1 (x) A, delta_g2 (x) A) = dim Hom_{Vec_G}(delta_g1, delta_g2 (x) A) = #{h in H: g2 h = g1}."""
    return sum(1 for h in H if mul(g2, h) == g1)


ok = True
for (G, mul, e), Hs in [(cyclic(4), [[0], [0, 2], [0, 1, 2, 3]]), (z2z2(), [[(0, 0)], [(0, 0), (1, 0)], [(0, 0), (0, 1), (1, 0), (1, 1)]])]:
    for H in Hs:
        cosets = {coset_rep(G, mul, H, g) for g in G}
        reps = [next(iter(c)) for c in cosets]
        ok &= all(free_hom_dim(G, mul, H, g, g) == 1 for g in reps)                    # each delta_g (x) A is simple
        ok &= all((free_hom_dim(G, mul, H, g1, g2) > 0) == (coset_rep(G, mul, H, g1) == coset_rep(G, mul, H, g2))
                  for g1 in G for g2 in G)                                             # iso iff same coset
        ok &= len(cosets) == len(G) // len(H)
check('thm:11:assoc(cosets)', 'EXACT', ok, 'Z4 and Z2 x Z2: the simple C_psi[H]-modules in Vec_G are delta_g (x) A, one per coset gH')

# ================================================================ S11.3 the internal Hom
# Regular module Vec_G over itself: [delta_x, delta_y] = (+)_c Hom(c (x) delta_x, delta_y) (x) c = delta_{y x^{-1}}.
# Vec as a module over Vec_G (H = G, psi): [k, k] = (+)_g delta_g, the algebra C_psi[G] of the module.
G, mul, e = cyclic(5)
inv = lambda g: (-g) % 5                                                  # noqa: E731
ok = all(sum(1 for c in G if mul(c, xx) == y) == 1 and [c for c in G if mul(c, xx) == y] == [mul(y, inv(xx))]
         for xx in G for y in G)
check('thm:11:ihom(regular)', 'EXACT', ok, 'Vec_Z5 over itself: [delta_x, delta_y] = delta_{y x^{-1}}')
# adjunction Hom_C(c, [M, N]) = Hom_M(c (x) M, N) dimension by dimension, for M = Mod(A), A = C[H], G = Z4, H = {0, 2}
G, mul, e = cyclic(4)
H = [0, 2]
cos = sorted({coset_rep(G, mul, H, g) for g in G}, key=lambda s_: min(s_))     # simples M_0 = {0,2}, M_1 = {1,3}
act = lambda c, Mi: coset_rep(G, mul, H, mul(c, min(cos[Mi])))           # noqa: E731 delta_c (x) M_i
ihom = {(i, j): [c for c in G if act(c, i) == cos[j]] for i in range(2) for j in range(2)}
ok = all(len(ihom[i, j]) == 2 for i in range(2) for j in range(2)) and sorted(ihom[0, 0]) == [0, 2] and sorted(ihom[0, 1]) == [1, 3]
check('thm:11:ihom(cosets)', 'EXACT', ok,
      'Vec_Z4, M = Mod(C[Z2]): [M_i, M_j] = (+)_c Hom(c (x) M_i, M_j) (x) c; [M_0, M_0] = delta_0 + delta_2 = A')
control('thm:11:ihom(cosets)', 'EXACT', not all(len(ihom[i, j]) == 1 for i in range(2) for j in range(2)),
        '[M_i, M_j] is a single delta_c (as for the regular module)')

# Existing Z2 example: reconstruct from each chosen simple M.
Gz, mz, ez = cyclic(2)
mult_regular = [free_hom_dim(Gz, mz, [ez], c, ez) for c in Gz]
mult_rank_one = [free_hom_dim(Gz, mz, Gz, c, ez) for c in Gz]
# In the rank-one case M = A, the evaluation on delta_s (x) A shifts its grading.
t1, ts = sp.eye(2), sp.Matrix([[0, 1], [1, 0]])
# Fix a basis v_s of the degree-s line.  Under v_s tensor v_s -> 1,
# t_s o (id_s tensor t_s) has the matrix ts * ts on A.
a1, a_s = sp.eye(2)[:, 0], sp.eye(2)[:, 1]
check('ex:11:ihom(typed evaluation)', 'EXACT', ts * a1 == a_s
      and ts * a_s == a1 and ts * ts == t1,
      't_s(v_s tensor a_1)=a_s, t_s(v_s tensor a_s)=a_1; the typed double evaluation is id_A')
check('ex:11:ihom(Z2)', 'EXACT', mult_regular == [1, 0] and mult_rank_one == [1, 1]
      and ts * ts == t1 and t1 * ts == ts * t1 == ts,
      'Z2: regular M = delta_1 gives multiplicities (1,0); rank-one M = A gives (1,1), with t_s^2 = t_1')
control('ex:11:ihom(Z2)', 'EXACT', ts * ts != -t1,
        'the reconstructed untwisted product has t_s^2 = -t_1')

# ================================================================ S11.4 counting module categories over Vec_G
# Indecomposable module categories over Vec_G <-> (H <= G, psi in H^2(H, C^x)) up to conjugacy; G abelian here.


def h2_order(H, mul, e, n):
    """|H^2(H, C^x)| by brute force: normalised mu_n-valued 2-cocycles modulo mu_n-valued coboundaries (n = |H|: every class has such a representative)."""
    nontriv = [h for h in H if h != e]
    pairs = [(g, h) for g in nontriv for h in nontriv]
    roots = list(range(n))                                     # exponents of e^{2 pi i/n}
    cocycles = 0
    for vals in itertools.product(roots, repeat=len(pairs)):
        f = {p: v for p, v in zip(pairs, vals)}
        F = lambda g, h: 0 if e in (g, h) else f[g, h]          # noqa: E731
        if all((F(g, h) + F(mul(g, h), k) - F(h, k) - F(g, mul(h, k))) % n == 0 for g in H for h in H for k in H):
            cocycles += 1
    cob = set()
    for phi in itertools.product(range(2 * n), repeat=len(nontriv)):   # phi with values in mu_{2n}
        P_ = dict(zip(nontriv, phi))
        Pf = lambda g: 0 if g == e else P_[g]                  # noqa: E731
        d = tuple(((Pf(g) + Pf(h) - Pf(mul(g, h))) % (2 * n)) for g, h in pairs)
        if all(v % 2 == 0 for v in d):                         # lands in mu_n
            cob.add(tuple(v // 2 for v in d))
    return cocycles // len(cob)


def subgroups(G, mul, e):
    out = []
    for r in range(1, len(G) + 1):
        for S in itertools.combinations(G, r):
            if e in S and all(mul(a, b) in S for a in S for b in S):
                out.append(list(S))
    return out


def count_modules(G, mul, e):
    return sum(h2_order(H, mul, e, len(H)) for H in subgroups(G, mul, e))   # abelian: conjugacy is trivial


G, mul, e = cyclic(2)
n2 = count_modules(G, mul, e)
G, mul, e = z2z2()
n22 = count_modules(G, mul, e)
check('thm:11:vecG(count)', 'EXACT', n2 == 2 and n22 == 6 and h2_order(G, mul, e, 4) == 2,
      'Vec_Z2 has 2 indecomposable module categories (H = 1, Z2); Vec_{Z2 x Z2} has 6 (H^2(Z2 x Z2) = Z2)')
control('thm:11:vecG(count)', 'EXACT', n22 != len(subgroups(G, mul, e)), 'one module category per subgroup of Z2 x Z2 (no psi)')

print()
if FAILS:
    print(f'{len(FAILS)} FAILED: ' + ', '.join(FAILS))
    sys.exit(1)
print('All L11 checks pass.')
