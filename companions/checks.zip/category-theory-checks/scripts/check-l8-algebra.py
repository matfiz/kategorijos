"""Algebra script for Lecture 8, *Hopf algebras and quantum groups*.

This script checks, on instances, the bialgebra and Hopf structures, the antipodes, the
quasitriangular structure of U_q(sl2) on V1 (x) V1, the categorical crossing c = A^{-1} B_q,
and the Tannaka obstruction that lectures/lec08.tex prints, labelled SYMBOLIC, EXACT or
NUMERICAL, most with a control that must fail.  Conventions: Bible K18 (K = q^h on V1,
E = e1 e2^T, F = e2 e1^T, Delta(E) = K (x) E + E (x) 1, Delta(F) = 1 (x) F + F (x) K^{-1},
Delta(K) = K (x) K; B_q in the basis up-up, up-down, down-up, down-down; q = A^2), K19
(mu, iota, Delta, eps_H, S_H), K2.  Pictures are checked by rendering, not here.

Run:  python3 scripts/check-l8-algebra.py     (exit status 1 on failure)
"""
import itertools
import sys

import sympy as sp

FAILS = []


def check(label, kind, ok, what):
    print(f"{'OK  ' if ok else 'FAIL'} [{kind:9s}] {label}: {what}")
    if not ok:
        FAILS.append(label)


def control(label, kind, failed, what):
    check(label + ' (control)', kind, failed, what + ' -- must fail, and does')


tp = sp.kronecker_product
zero = lambda M: sp.simplify(M) == sp.zeros(*M.shape)                      # noqa: E731

# ================================================================ S8.1 bialgebras: C[G], C^G, U(g)
S3 = list(itertools.permutations(range(3)))
mul = lambda g, h: tuple(g[h[i]] for i in range(3))                        # noqa: E731
inv = lambda g: tuple(sorted(range(3), key=lambda i: g[i]))                # noqa: E731
e = (0, 1, 2)


def perm(g):
    M = sp.zeros(3)
    for i in range(3):
        M[g[i], i] = 1
    return M


# C[G]: Delta(g) = g (x) g; on V (x) W this is rho(g) (x) rho(g), and it is multiplicative
ok = all(tp(perm(mul(g, h)), perm(mul(g, h))) == tp(perm(g), perm(g)) * tp(perm(h), perm(h)) for g in S3 for h in S3)
check('ex:8:CG', 'EXACT', ok, 'C[S3]: Delta(gh) = Delta(g) Delta(h) on C^3 (x) C^3, the tensor product of representations')
control('ex:8:CG', 'EXACT', not all(tp(perm(mul(g, h)), sp.eye(3)) + tp(sp.eye(3), perm(mul(g, h)))
                                    == (tp(perm(g), sp.eye(3)) + tp(sp.eye(3), perm(g))) * (tp(perm(h), sp.eye(3)) + tp(sp.eye(3), perm(h)))
                                    for g in S3 for h in S3),
        'the primitive coproduct g -> g (x) 1 + 1 (x) g is multiplicative on C[S3]')
# C^G: delta_g delta_h = [g = h] delta_g; Delta(delta_g) = sum_{hk = g} delta_h (x) delta_k is multiplicative
basis = {g: i for i, g in enumerate(S3)}


def dvec(g):
    v = sp.zeros(6, 1)
    v[basis[g]] = 1
    return v


def Delta_fun(g):
    return sum((tp(dvec(h), dvec(k)) for h in S3 for k in S3 if mul(h, k) == g), sp.zeros(36, 1))


pointwise = lambda u, w: sp.Matrix([u[i] * w[i] for i in range(u.shape[0])])  # noqa: E731
ok = all(pointwise(Delta_fun(g), Delta_fun(h)) == (Delta_fun(g) if g == h else sp.zeros(36, 1)) for g in S3 for h in S3)
ok &= sum((Delta_fun(g) for g in S3), sp.zeros(36, 1)) == sp.ones(36, 1)    # Delta(1) = 1 (x) 1
check('ex:8:CfunG', 'EXACT', ok, 'C^{S3}: Delta(delta_g) = sum_{hk = g} delta_h (x) delta_k is an algebra map, Delta(1) = 1 (x) 1')
# U(sl2): Delta(x) = x (x) 1 + 1 (x) x preserves the brackets (adding angular momenta)
e2, f2, h2 = sp.Matrix([[0, 1], [0, 0]]), sp.Matrix([[0, 0], [1, 0]]), sp.diag(1, -1)
I2 = sp.eye(2)
D = lambda x: tp(x, I2) + tp(I2, x)                                       # noqa: E731
br = lambda x, y: x * y - y * x                                          # noqa: E731
check('ex:8:Ug', 'EXACT', br(D(e2), D(f2)) == D(h2) and br(D(h2), D(e2)) == 2 * D(e2) and br(D(h2), D(f2)) == -2 * D(f2),
      'U(sl2): Delta(x) = x (x) 1 + 1 (x) x preserves [e,f] = h, [h,e] = 2e, [h,f] = -2f on V1 (x) V1')
control('ex:8:Ug', 'EXACT', br(tp(e2, e2), tp(f2, f2)) != tp(h2, h2), 'Delta(x) = x (x) x preserves [e,f] = h')

# ================================================================ S8.2 antipodes = duals
# C[G]: S(g) = g^{-1} gives the contragredient rho(g^{-1})^T, and ev intertwines
ev3 = sp.eye(3).reshape(1, 9)
check('ex:8:SCG', 'EXACT', all(ev3 * tp(perm(inv(g)).T, perm(g)) == ev3 for g in S3),
      'C[S3]: with S(g) = g^{-1} on V*, ev: V* (x) V -> C is an intertwiner')
control('ex:8:SCG', 'EXACT', not all(ev3 * tp(perm(g).T, perm(g)) == ev3 for g in S3),
        'with S = id (g acting on V* by rho(g)^T), ev is an intertwiner')
# U(g): S(x) = -x: x acts on V* by -x^T, and ev (Delta(x)) = 0 (the trivial action on C)
ev2 = sp.eye(2).reshape(1, 4)
check('ex:8:SUg', 'EXACT', all(ev2 * (tp(-x.T, I2) + tp(I2, x)) == sp.zeros(1, 4) for x in (e2, f2, h2)),
      'U(sl2): with S(x) = -x, ev intertwines: ev (-x^T (x) 1 + 1 (x) x) = 0')
control('ex:8:SUg', 'EXACT', any(ev2 * (tp(x.T, I2) + tp(I2, x)) != sp.zeros(1, 4) for x in (e2, f2, h2)),
        'with S(x) = x, ev intertwines')

# ex:8:sVec -- C[Z2] with R = (1 (x) 1 + 1 (x) g + g (x) 1 - g (x) g)/2: on V_a (x) V_b (g acting by (-1)^a)
# it acts by (-1)^{ab}, so c = P R is the braiding of sVec; (Delta (x) id)(R) = R13 R23 on every V_a V_b V_c
Rz2 = lambda a, b: sp.Rational(1, 2) * (1 + (-1) ** b + (-1) ** a - (-1) ** (a + b))   # noqa: E731
ok = all(Rz2(a, b) == (-1) ** (a * b) for a in (0, 1) for b in (0, 1))
ok &= all(Rz2((a + b) % 2, c_) == Rz2(a, c_) * Rz2(b, c_) and Rz2(a, (b + c_) % 2) == Rz2(a, c_) * Rz2(a, b)
          for a in (0, 1) for b in (0, 1) for c_ in (0, 1))
check('ex:8:sVec', 'EXACT', ok, 'C[Z2] with R = (1 + 1g + g1 - gg)/2 acts by (-1)^{ab}; (Delta (x) id)R = R13 R23, (id (x) Delta)R = R13 R12')
control('ex:8:sVec', 'EXACT', Rz2(1, 1) != 1, 'this R is 1 (x) 1 on the odd-odd sector')

# ================================================================ S8.5 U_q(sl2) on V1 (K18)
A = sp.Symbol('A', nonzero=True)
q = A ** 2
E, Fm, K = sp.Matrix([[0, 1], [0, 0]]), sp.Matrix([[0, 0], [1, 0]]), sp.diag(q, 1 / q)
Ki = K.inv()
check('def:8:uqsl2', 'EXACT', zero(K * E * Ki - q ** 2 * E) and zero(K * Fm * Ki - Fm / q ** 2)
      and zero(E * Fm - Fm * E - (K - Ki) / (q - 1 / q)),
      'on V1: K E K^-1 = q^2 E, K F K^-1 = q^-2 F, [E, F] = (K - K^-1)/(q - q^-1)')
ours = {'E': tp(K, E) + tp(E, I2), 'F': tp(I2, Fm) + tp(Fm, Ki), 'K': tp(K, K)}
kas = {'E': tp(E, K) + tp(I2, E), 'F': tp(Fm, I2) + tp(Ki, Fm), 'K': tp(K, K)}
check('def:8:uqsl2(Delta)', 'EXACT', zero(ours['K'] * ours['E'] * ours['K'].inv() - q ** 2 * ours['E'])
      and zero(ours['K'] * ours['F'] * ours['K'].inv() - ours['F'] / q ** 2)
      and zero(ours['E'] * ours['F'] - ours['F'] * ours['E'] - (ours['K'] - ours['K'].inv()) / (q - 1 / q)),
      'the coproduct of K18 is an algebra map: the relations hold for Delta(E), Delta(F), Delta(K) on V1 (x) V1')
control('def:8:uqsl2(Delta)', 'EXACT', not zero((tp(E, I2) + tp(I2, E)) * (tp(Fm, I2) + tp(I2, Fm))
                                                - (tp(Fm, I2) + tp(I2, Fm)) * (tp(E, I2) + tp(I2, E))
                                                - (ours['K'] - ours['K'].inv()) / (q - 1 / q)),
        'the undeformed coproduct E (x) 1 + 1 (x) E, F (x) 1 + 1 (x) F satisfies the U_q relation')
# coassociativity of K18's Delta on V1^{(x)3}: (Delta (x) id) Delta = (id (x) Delta) Delta on E, F, K
I2_ = sp.eye(2)
coassoc = all(zero(left - right) for left, right in [
    (tp(tp(K, K), E) + tp(ours['E'], I2_), tp(K, ours['E']) + tp(E, tp(I2_, I2_))),       # E
    (tp(tp(I2_, I2_), Fm) + tp(ours['F'], Ki), tp(I2_, ours['F']) + tp(Fm, tp(Ki, Ki))),  # F
    (tp(tp(K, K), K), tp(K, tp(K, K)))])                                                  # K
check('def:8:uqsl2(coassoc)', 'EXACT', coassoc, 'Delta is coassociative on V1^{(x)3} for E, F, K')
# the antipode: S(K) = K^-1, S(E) = -K^-1 E, S(F) = -F K solve mu (S (x) id) Delta = iota eps on generators
# the dual V1* is V1 with x acting by rho(S(x))^T; ev: V1* (x) V1 -> C must intertwine, ev Delta(x) = eps(x) ev
Sx = {'E': -Ki * E, 'F': -Fm * K, 'K': Ki}
dual = {k: Sx[k].T for k in Sx}
DeltaDual = {'E': tp(dual['K'], E) + tp(dual['E'], I2), 'F': tp(sp.eye(2), Fm) + tp(dual['F'], Ki),
             'K': tp(dual['K'], K)}
eps = {'E': 0, 'F': 0, 'K': 1}
check('def:8:antipode', 'EXACT', all(zero(ev2 * DeltaDual[k] - eps[k] * ev2) for k in 'EFK'),
      'with S(E) = -K^{-1}E, S(F) = -FK, S(K) = K^{-1} acting on V1*, ev: V1* (x) V1 -> C is a U_q-map')
DualBad = {'E': tp(Ki.T, E) + tp((-E).T, I2), 'F': DeltaDual['F'], 'K': DeltaDual['K']}
control('def:8:antipode', 'EXACT', not all(zero(ev2 * DualBad[k] - eps[k] * ev2) for k in 'EFK'),
        'the classical antipode S(E) = -E also makes ev a U_q-map')

# ================================================================ S8.3 quasitriangular; S8.5 c = A^{-1} B_q
Bq = sp.Matrix([[q, 0, 0, 0], [0, q - 1 / q, 1, 0], [0, 1, 0, 0], [0, 0, 0, q]])
P4 = sp.Matrix([[1, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0], [0, 0, 0, 1]])
R = sp.diag(A, 1 / A, 1 / A, A) * (sp.eye(4) + (q - 1 / q) * tp(Fm, E))
Rinv = R.inv()
check('thm:8:qt', 'EXACT', all(zero(R * ours[k] * Rinv - kas[k]) for k in 'EFK'),
      'R Delta(x) R^{-1} = Delta^op(x) on V1 (x) V1, x = E, F, K (Delta^op is Kassel\'s coproduct)')
# the link to Kassel's formula: q^{h (x) h/2} = diag(A, A^-1, A^-1, A) on V1 (x) V1 (h = diag(1, -1))
hh = sp.diag(1, -1, -1, 1)
check('thm:8:uqsl2(Kassel)', 'EXACT', zero(sp.diag(*[A ** hh[i, i] for i in range(4)]) - sp.diag(A, 1 / A, 1 / A, A))
      and zero(Fm * Fm) and zero(E * E),
      'q^{h (x) h/2} = diag(A, A^-1, A^-1, A), and E^2 = F^2 = 0 on V1, so Kassel\'s series truncates at n = 1')
# the two coproduct conditions on V1^{(x)3}: (Delta (x) id)(R) = R13 R23, (id (x) Delta)(R) = R13 R12
Hh = sp.diag(1, -1)
qhh = lambda H1, H2: sp.diag(*[A ** (H1[i, i] * H2[j, j]) for i in range(H1.shape[0]) for j in range(H2.shape[0])])  # q^{H1 (x) H2 /2}
Dh = tp(Hh, I2) + tp(I2, Hh)                                     # Delta(h) on V1 (x) V1
DR_left = qhh(Dh, Hh) * (sp.eye(8) + (q - 1 / q) * tp(ours['F'], E))     # (Delta (x) id)(R), n <= 1 since E^2 = 0
DR_right = qhh(Hh, Dh) * (sp.eye(8) + (q - 1 / q) * tp(Fm, ours['E']))   # (id (x) Delta)(R), n <= 1 since F^2 = 0
R12_, R23_ = tp(R, I2), tp(I2, R)
P23_ = tp(I2, P4)
R13_ = P23_ * R12_ * P23_
check('thm:8:uqsl2(coproduct)', 'EXACT', zero(DR_left - R13_ * R23_) and zero(DR_right - R13_ * R12_),
      '(Delta (x) id)(R) = R13 R23 and (id (x) Delta)(R) = R13 R12 on V1^{(x)3}')
control('thm:8:uqsl2(coproduct)', 'EXACT', not zero(DR_left - R12_ * R23_), '(Delta (x) id)(R) = R12 R23')
# rem:8:sign -- the one-dimensional module L (E = F = 0, K = -1) admits no braiding with V1: c_{L,V} must be
# a diag(1, -1); a hexagon and naturality with L (x) L = 1 give a^2 = 1, with the cup v give -a^2 = 1
a_ = sp.Symbol('a')
Dm = a_ * sp.diag(1, -1)
LV = {'E': -E, 'F': Fm, 'K': -K}           # on L (x) V: Delta(E) = K (x) E + E (x) 1 -> (-1) E, etc.
VL = {'E': E, 'F': -Fm, 'K': -K}           # on V (x) L
ok_int = all(zero(Dm * LV[k_] - VL[k_] * Dm) for k_ in 'EFK')
vv = sp.Matrix([0, 1, -q, 0])
eqs_sign = [sp.Eq(a_ ** 2, 1), sp.Eq(-a_ ** 2, 1)]
check('rem:8:sign', 'SYMBOLIC', ok_int and zero(tp(Dm, Dm) * vv + a_ ** 2 * vv) and sp.solve(eqs_sign, a_) == [],
      'on the sign module, c_{L,V} = a diag(1,-1) intertwines, (D (x) D) v = -a^2 v; a^2 = 1 and -a^2 = 1 have no common root')
c = P4 * R
check('thm:8:qt(c)', 'EXACT', zero(c - Bq / A) and all(zero(c * ours[k] - ours[k] * c) for k in 'EFK'),
      'c = P R = A^{-1} B_q, and it commutes with the action of U_q: a module map V1 (x) V1 -> V1 (x) V1')
I8 = sp.eye(2)
R12, R23 = tp(R, I8), tp(I8, R)
P23 = tp(I8, P4)
R13 = P23 * R12 * P23
check('thm:8:qt(ybe)', 'EXACT', zero(R12 * R13 * R23 - R23 * R13 * R12)
      and zero(tp(c, I8) * tp(I8, c) * tp(c, I8) - tp(I8, c) * tp(c, I8) * tp(I8, c)),
      'R12 R13 R23 = R23 R13 R12, and c satisfies the braid relation')
Rkas = P4 * R * P4
control('thm:8:qt', 'EXACT', not all(zero(Rkas * ours[k] * Rkas.inv() - kas[k]) for k in 'EFK'),
        'Kassel\'s unflipped R conjugates our Delta to Delta^op')
# Hecke, eigenvalues, the singlet, the forced factor A^{-1}
v = sp.Matrix([0, 1, -q, 0])
check('eq:8:hecke', 'EXACT', zero((Bq - q * sp.eye(4)) * (Bq + sp.eye(4) / q)),
      '(B_q - q)(B_q + q^{-1}) = 0')
check('eq:8:eigen', 'EXACT', set(sp.simplify(x) for x in c.eigenvals()) == {A, -A ** -3}
      and zero(Bq * v + v / q) and all(zero(ours[k] * v - (v if k == 'K' else sp.zeros(4, 1))) for k in 'EFK'),
      'c has eigenvalues A (triplet) and -A^{-3}; v = e1 e2 - q e2 e1 is invariant and B_q v = -q^{-1} v')
Um = Bq - q * sp.eye(4)
check('rem:8:tl', 'EXACT', zero(Um * Um + (q + 1 / q) * Um) and zero(Um * v - (-(q + 1 / q)) * v),
      'U = B_q - q satisfies U^2 = -(q + q^{-1}) U, and U v = -(q + q^{-1}) v on the q-singlet')
c1, c2 = tp(c, I8), tp(I8, c)
B1, B2 = tp(Bq, I8), tp(I8, Bq)
vx1, onexv = tp(v, I8), tp(I8, v)
check('eq:8:naturality', 'EXACT', zero(c1 * c2 * vx1 - onexv) and zero(B1 * B2 * vx1 - q * onexv),
      'naturality with the cup: c1 c2 (v (x) 1) = 1 (x) v, while B1 B2 (v (x) 1) = q (1 (x) v)')
# The printed basis calculation uses e_ijk = e_i (x) e_j (x) e_k.
e111, e112, e121, e122, e211, e212, e221, e222 = [sp.eye(8)[:, j] for j in range(8)]
basis_images = sp.Matrix.hstack(q * (e112 - q * e121), q * (e212 - q * e221))
scale = sp.Symbol('z', nonzero=True)
check('eq:8:naturality(basis)', 'EXACT', zero(B1 * B2 * vx1 - basis_images)
      and zero(scale ** 2 * B1 * B2 * vx1 - (scale ** 2 * q) * onexv),
      'on e1 and e2, B1 B2 (v (x) e_i) = q (e_i (x) v); c = z B requires z^2 q = 1')
control('eq:8:naturality(basis)', 'EXACT', not zero(B1 * B2 * vx1 - sp.Matrix.hstack(q * (e112 + q * e121), q * (e212 + q * e221))),
        'the cup has a plus sign in the two printed basis images')
control('eq:8:naturality', 'EXACT', not zero(B1 * B2 * vx1 - onexv), 'B_q itself satisfies the naturality')
check('eq:8:q1', 'EXACT', Bq.subs(A, 1) == P4 and c.subs(A, 1) == P4,
      'at A = 1 (hence q = 1), B_q and c become the flip P')
check('eq:8:q1(A=-1)', 'EXACT', Bq.subs(A, -1) == P4 and c.subs(A, -1) == -P4,
      'at A = -1, also q = 1: B_q = P but c = -P (the other root)')

# the q -> 1 limit against rep-engine's sl2 irreps
try:
    from rep_engine import HighestWeight, Representation, get_field
    Rsl2 = Representation.type_A(HighestWeight.type_A_from_dynkin([1]), get_field('QQ'))
    P2 = sp.Matrix([[0, 1], [1, 0]])                                     # rep-engine lists the lowest weight first
    reM = lambda M: P2 * sp.Matrix([[sp.Rational(x.numerator, x.denominator) for x in row] for row in M]) * P2  # noqa: E731
    Hq = sp.simplify((K - Ki) / (q - 1 / q))
    check('eq:8:limit', 'EXACT', E == reM(Rsl2.rho_e(1)) and Fm == reM(Rsl2.rho_f(1))
          and all(sp.limit(Hq[i, i], A, 1) == reM(Rsl2.rho_h(1))[i, i] for i in range(2)),
          'q -> 1: E, F and (K - K^{-1})/(q - q^{-1}) become rep-engine\'s sl2 e, f, h on V1')
except ImportError:
    check('eq:8:limit', 'EXACT', False, 'rep-engine not installed')

# ================================================================ S8.5 the XXZ dictionary (QC survey S5)
# Integrability's trigonometric R (eq. 15.22): diag-ish in up-up, up-down, down-up, down-down, Delta = cos(eta)
lam, eta = sp.symbols('lambda eta', real=True)
Rx = sp.Matrix([[sp.sinh(lam - sp.I * eta), 0, 0, 0], [0, sp.sinh(lam), -sp.I * sp.sin(eta), 0],
                [0, -sp.I * sp.sin(eta), sp.sinh(lam), 0], [0, 0, 0, sp.sinh(lam - sp.I * eta)]])
Dg = sp.diag(sp.exp(lam / 2), sp.exp(-lam / 2))
D1 = tp(Dg, I2)
Rt = D1 * Rx * D1.inv()                                                    # the gauge change on the first factor
qx = sp.exp(sp.I * eta)
Bqx = sp.Matrix([[qx, 0, 0, 0], [0, qx - 1 / qx, 1, 0], [0, 1, 0, 0], [0, 0, 0, qx]])
lim_minus = (-2 * sp.exp(lam) * P4 * Rt).applyfunc(lambda z: sp.limit(sp.simplify(z.rewrite(sp.exp)), lam, -sp.oo))
check('tab:8:xxz(minus)', 'SYMBOLIC', zero(lim_minus - Bqx),
      'lim_{lambda -> -oo} (-2 e^lambda) P R~(lambda) = B_q with q = e^{i eta} (after the gauge change D_1(lambda))')
lim_plus = (2 * sp.exp(-lam) * P4 * Rt).applyfunc(lambda z: sp.limit(sp.simplify(z.rewrite(sp.exp)), lam, sp.oo))
ratio = sp.simplify(lim_plus * Bqx)
check('tab:8:xxz(plus)', 'SYMBOLIC', zero(ratio - sp.eye(4)),
      'lim_{lambda -> +oo} (2 e^{-lambda}) P R~(lambda) = B_q^{-1} exactly: the two ends of the spectral line are the two crossings')
lim_nogauge = (-2 * sp.exp(lam) * P4 * Rx).applyfunc(lambda z: sp.limit(sp.simplify(z.rewrite(sp.exp)), lam, -sp.oo))
control('tab:8:xxz(minus)', 'SYMBOLIC', not zero(lim_nogauge - Bqx), 'without the gauge change the limit is already B_q')
check('tab:8:xxz(q)', 'SYMBOLIC', sp.simplify(Bqx - Bq.subs(A, sp.exp(sp.I * eta / 2))) == sp.zeros(4)
      and sp.simplify((qx + 1 / qx) / 2 - sp.cos(eta)) == 0,
      'q = e^{i eta} = A^2, and (q + q^{-1})/2 = cos(eta) = Delta, Integrability\'s anisotropy')

# ================================================================ S8.4 Tannaka: the FPdim obstruction
phi = (1 + sp.sqrt(5)) / 2
check('thm:8:tannaka', 'SYMBOLIC', not phi.is_integer and not (sp.sqrt(2)).is_integer and sp.simplify(phi ** 2 - phi - 1) == 0,
      'FPdim(tau) = phi and FPdim(sigma) = sqrt 2 are not integers: no fibre functor for Fibonacci or Ising')
w3 = sp.exp(2 * sp.pi * sp.I / 3)
check('rem:8:vecz3', 'SYMBOLIC', sp.simplify(w3 ** 3 - 1) == 0 and not sp.im(sp.N(w3)) == 0,
      'Vec_Z3 has the fibre functor to Vect (forget the grading) and a pivotal structure with d_r = e^{2 pi i/3}')

print()
if FAILS:
    print(f'{len(FAILS)} FAILED: ' + ', '.join(FAILS))
    sys.exit(1)
print('All L8 checks pass.')
