"""Algebra script for Lecture 4, *Duality: cups, caps and quantum dimension*.

Every formula, number and diagram equation that lectures/lec04.tex prints is checked here
before it is printed, on instances, labelled SYMBOLIC, EXACT or NUMERICAL, most with a
control that must fail.  A string diagram is evaluated as a composite of Kronecker
products, read upward with the left strand the first (slow) factor (Bible K1).  Duals as
Bible K3: ev_X : X* (x) X -> 1 (a cap, X* on the left), coev_X : 1 -> X (x) X* (a cup, X
on the left); with a pivotal structure a, the other cap is
    ev~_X = ev_{X*} o (a_X (x) id_{X*}) : X (x) X* -> 1
and the other cup coev~_X : 1 -> X* (x) X.  In Vect_fd, a is L1's canonical map, and in
coordinates ev~ and coev~ are again the identity matrix reshaped.  The diagram equations
of L4 are exact equalities unless a scalar is stated.

Spin-1/2 (Bible K4): Omega(e1, e2) = 1 = -Omega(e2, e1); as a cup C -> V (x) V it is
e1 (x) e2 - e2 (x) e1.

Run:  python3 scripts/check-l4-algebra.py     (exit status 1 on failure)
"""
import itertools
import sys

import numpy as np
import sympy as sp

FAILS = []
RNG = np.random.default_rng(20261024)


def check(label, kind, ok, what):
    print(f"{'OK  ' if ok else 'FAIL'} [{kind:9s}] {label}: {what}")
    if not ok:
        FAILS.append(label)


def control(label, kind, failed, what):
    check(label + ' (control)', kind, failed, what + ' -- must fail, and does')


def crandn(*shape):
    return RNG.standard_normal(shape) + 1j * RNG.standard_normal(shape)


def close(a, b, tol=1e-10):
    return np.allclose(a, b, atol=tol, rtol=0)


def K(*ms):
    out = np.eye(1)
    for m in ms:
        out = np.kron(out, m)
    return out


# ================================================================ S4.1 duals and the snake
n = 3
I = np.eye(n)
coev = I.reshape(n * n, 1)                       # 1 -> X (x) X*:   sum_i e_i (x) e^i
ev = I.reshape(1, n * n)                         # X* (x) X -> 1:   e^i (x) e_j -> delta_ij
check('eq:4:snakes(1)', 'NUMERICAL', close(K(I, ev) @ K(coev, I), I),
      '(id_X (x) ev_X)(coev_X (x) id_X) = id_X')
check('eq:4:snakes(2)', 'NUMERICAL', close(K(ev, I) @ K(I, coev), I),
      '(ev_X (x) id_X*)(id_X* (x) coev_X) = id_X*')
control('eq:4:snakes(1)', 'NUMERICAL', not close(K(I, ev) @ K(2 * coev, I), I),
        'the snake with coev scaled by 2 is still the identity')

# thm:4:snake(a) -- two left duals (X*, ev, coev) and (X', ev', coev') with X' = X* via an
# invertible P (ev' = ev o (P^{-1} (x) id), coev' = (id (x) P) coev): phi = (ev (x) id_X')
# (id_X* (x) coev') : X* -> X' is P, and is the unique compatible isomorphism.
P = crandn(n, n)
evp = ev @ K(np.linalg.inv(P), I)
coevp = K(I, P) @ coev
phi = K(ev, I) @ K(I, coevp)
check('thm:4:snake(unique)', 'NUMERICAL', close(phi, P),
      'phi = (ev (x) id)(id (x) coev\') : X* -> X\' recovers the comparison P')
check('thm:4:snake(compatible)', 'NUMERICAL',
      close(evp @ K(phi, I), ev) and close(K(I, phi) @ coev, coevp),
      "ev' o (phi (x) id) = ev and (id (x) phi) o coev = coev'")
check('thm:4:snake(primed snakes)', 'NUMERICAL', close(K(I, evp) @ K(coevp, I), I),
      'the primed pair satisfies the snake too')

# eq:4:rotated -- f* = (ev_Y (x) id_X*)(id_Y* (x) f (x) id_X*)(id_Y* (x) coev_X) is the
# transpose (L1's dual map), and (g o f)* = f* o g*.
m = 2
Iy = np.eye(m)
evY = Iy.reshape(1, m * m)
f = crandn(m, n)                                 # f : X = C^3 -> Y = C^2
fstar = K(evY, I) @ K(Iy, f, I) @ K(Iy, coev)
check('eq:4:rotated', 'NUMERICAL', close(fstar, f.T), 'the rotated box is the transpose: f* = f^T')
control('eq:4:rotated', 'NUMERICAL', not close(fstar, f.conj().T), 'the rotated box is the adjoint f^dagger')
g = crandn(4, m)
gstar = g.T
check('thm:4:snake(contravariant)', 'NUMERICAL', close((g @ f).T, fstar @ gstar), '(g o f)* = f* o g*')

# ex:4:rep -- the contragredient rho*(g) = (rho(g)^{-1})^T makes ev and coev intertwiners.
S3 = list(itertools.permutations(range(3)))


def rho(s):
    M = np.zeros((3, 3))
    for i in range(3):
        M[s[i], i] = 1
    return M


Rg = lambda s: K(rho(s), np.eye(1))                     # noqa: E731
ok_ev = all(close(ev @ K(np.linalg.inv(rho(s)).T, rho(s)), ev) for s in S3)
ok_coev = all(close(K(rho(s), np.linalg.inv(rho(s)).T) @ coev, coev) for s in S3)
# a non-unitary representation, to see the inverse-transpose (Z acting by [[1,1],[0,1]])
A = np.array([[1.0, 1.0], [0.0, 1.0]])
ev2, coev2 = np.eye(2).reshape(1, 4), np.eye(2).reshape(4, 1)
ok_jordan = close(ev2 @ K(np.linalg.inv(A).T, A), ev2) and close(K(A, np.linalg.inv(A).T) @ coev2, coev2)
check('ex:4:rep', 'NUMERICAL', ok_ev and ok_coev and ok_jordan,
      'ev and coev intertwine rho* (x) rho and rho (x) rho* with the trivial representation')
control('ex:4:rep', 'NUMERICAL', not close(ev2 @ K(A, A), ev2),
        'with rho*(g) = rho(g) (not inverse-transposed) ev is an intertwiner')

# ex:4:vecg -- Vec_G^omega with identity unitors and coev = id: the first snake is
# r o (id (x) ev) o alpha_{g,g^-1,g} o (coev (x) id) o l^{-1} = ev * omega(g, g^-1, g), so
# ev_g = omega(g, g^-1, g)^{-1}; the second snake then holds by the cocycle condition.
def omega_p(N, p):
    return lambda a, b, c: sp.exp(2 * sp.pi * sp.I * p * a * (b + c - (b + c) % N) / N ** 2)


ok = True
for N, p in [(2, 1), (3, 1), (4, 1), (4, 3)]:
    w = omega_p(N, p)
    for gg in range(N):
        ginv = (-gg) % N
        ev_g = 1 / w(gg, ginv, gg)
        snake1 = ev_g * w(gg, ginv, gg)
        snake2 = ev_g / w(ginv, gg, ginv)              # alpha^{-1}_{g^-1, g, g^-1}
        ok &= sp.simplify(snake1 - 1) == 0 and sp.simplify(snake2 - 1) == 0
check('ex:4:vecg', 'SYMBOLIC', ok,
      'ev_g = omega(g,g^-1,g)^{-1}, coev_g = 1 satisfy both snakes (omega_p, several N, p)')
w2 = omega_p(2, 1)
check('ex:4:vecg(Z2)', 'SYMBOLIC', sp.simplify(w2(1, 1, 1) + 1) == 0,
      'for Z2 with omega(s,s,s) = -1 the naive snake (ev = coev = id) is -id_s')
control('ex:4:vecg', 'SYMBOLIC', sp.simplify(sp.exp(2 * sp.pi * sp.I / 3) * omega_p(3, 1)(1, 2, 1) - 1) != 0,
        'ev_g = omega(g,g^-1,g) (not its inverse) satisfies the first snake for Z3')

# prop:4:tensordual -- (X (x) Y)* = Y* (x) X* with the nested cup and cap:
# coev_{X (x) Y} = (id_X (x) coev_Y (x) id_X*) o coev_X : 1 -> X Y Y* X*,
# ev_{X (x) Y}  = ev_Y o (id_Y* (x) ev_X (x) id_Y) : Y* X* X Y -> 1; both snakes hold.
nx, ny = 2, 3
Ix, Iy3 = np.eye(nx), np.eye(ny)
coevX, evX = Ix.reshape(nx * nx, 1), Ix.reshape(1, nx * nx)
coevY, evY3 = Iy3.reshape(ny * ny, 1), Iy3.reshape(1, ny * ny)
coevXY = K(Ix, coevY, Ix) @ coevX
evXY = evY3 @ K(Iy3, evX, Iy3)
Ixy = np.eye(nx * ny)
check('prop:4:tensordual', 'NUMERICAL',
      close(K(Ixy, evXY) @ K(coevXY, Ixy), Ixy) and close(K(evXY, Ixy) @ K(Ixy, coevXY), Ixy),
      'the nested cup and cap make Y* (x) X* a left dual of X (x) Y (both snakes)')
coev_wrong = K(coevX, coevY)                              # X X* Y Y*: not nested
control('prop:4:tensordual', 'NUMERICAL', not close(K(Ixy, evXY) @ K(coev_wrong, Ixy), Ixy),
        'the unnested cup coev_X (x) coev_Y with the nested cap gives a straight snake')

# ================================================================ S4.2 bending wires
dU, dV, dW = 2, 3, 2
IU, IV, IW = np.eye(dU), np.eye(dV), np.eye(dW)
coevV, evV = IV.reshape(dV * dV, 1), IV.reshape(1, dV * dV)
fb = crandn(dW, dU * dV)                                # f : U (x) V -> W
bend = K(fb, IV) @ K(IU, coevV)                         # U -> W (x) V*
unbend = lambda gm: K(IW, evV) @ K(gm, IV)              # noqa: E731  W (x) V* (x) V -> W
check('thm:4:bend', 'NUMERICAL', close(unbend(bend), fb),
      'f -> (f (x) id)(id (x) coev) and g -> (id (x) ev)(g (x) id) are inverse')
gb = crandn(dW * dV, dU)
check('thm:4:bend(other order)', 'NUMERICAL', close(K(unbend(gb), IV) @ K(IU, coevV), gb),
      'and in the other order')
control('thm:4:bend', 'NUMERICAL', not close(unbend(K(fb, IV) @ K(IU, 2 * coevV)), fb),
        'bending with a cup scaled by 2 and unbending still gives f')

# teleportation: |psi> (x) Phi+ projected on Phi+ in the first two factors gives psi / 2.
psi = crandn(2)
phip = np.eye(2).reshape(4) / np.sqrt(2)
out = K(phip.reshape(1, 4).conj(), np.eye(2)) @ np.kron(psi, phip)
check('ex:4:teleport', 'NUMERICAL', close(out, psi / 2),
      '(<Phi+| (x) id)(|psi> (x) |Phi+>) = |psi>/2: the snake, with the normalisation 1/2')
X_ = np.array([[0, 1], [1, 0]])
phix = K(np.eye(2), X_) @ phip                           # (id (x) X) Phi+
outx = K(phix.reshape(1, 4).conj(), np.eye(2)) @ np.kron(psi, phip)
check('ex:4:teleport(Pauli)', 'NUMERICAL', close(X_ @ outx, psi / 2),
      'the outcome (id (x) X)Phi+ leaves X psi / 2, undone by X')
Z_ = np.diag([1, -1])
ok = True
for P_ in (Z_, X_ @ Z_):                                  # the other two outcomes (id (x) P) Phi+
    phiP = K(np.eye(2), P_) @ phip
    outP = K(phiP.reshape(1, 4).conj(), np.eye(2)) @ np.kron(psi, phip)
    ok &= close(np.linalg.inv(P_) @ outP, psi / 2)
check('ex:4:teleport(all four)', 'NUMERICAL', ok, 'the Z and XZ outcomes are undone by a Pauli matrix too')

# ================================================================ S4.3 pivotal, trace, dimension
# In Vect_fd with the canonical a: ev~ and coev~ are the identity reshaped (coordinates).
evt = I.reshape(1, n * n)                               # X (x) X* -> 1
coevt = I.reshape(n * n, 1)                             # 1 -> X* (x) X
h = crandn(n, n)
trL = (evt @ K(h, I) @ coev).item()                     # close to the right
trR = (ev @ K(I, h) @ coevt).item()                     # close to the left
check('def:4:trace', 'NUMERICAL', np.isclose(trL, np.trace(h)) and np.isclose(trR, np.trace(h)),
      'in Vect_fd both traces are the ordinary trace')
control('def:4:trace', 'NUMERICAL', not np.isclose(trL, np.trace(h @ h)), 'the left trace is tr(h^2)')
# cyclicity and multiplicativity
f1, g1 = crandn(n, m), crandn(m, n)
check('thm:4:pivotal(cyclic)', 'NUMERICAL', np.isclose(np.trace(f1 @ g1), np.trace(g1 @ f1)),
      'tr(f o g) = tr(g o f) for f: Y -> X, g: X -> Y')
h2 = crandn(m, m)
check('thm:4:pivotal(multiplicative)', 'NUMERICAL', np.isclose(np.trace(np.kron(h, h2)), np.trace(h) * np.trace(h2)),
      'tr(h (x) h\') = tr(h) tr(h\')')
check('thm:4:pivotal(dimension)', 'NUMERICAL', np.isclose(np.trace(np.kron(I, Iy)), n * m),
      'd_{X (x) Y} = d_X d_Y = dim X dim Y in Vect_fd')
# the partial trace: close the right strand of h12 on X (x) Y
h12 = crandn(n * m, n * m)
ptr = sum(K(I, Iy[:, [k]].T) @ h12 @ K(I, Iy[:, [k]]) for k in range(m))
ptr_pic = K(I, Iy.reshape(1, m * m)) @ K(h12, Iy) @ K(I, Iy.reshape(m * m, 1))
check('eq:4:partialtrace', 'NUMERICAL', close(ptr, ptr_pic),
      'closing the right strand is the partial trace over the second factor')
control('eq:4:partialtrace', 'NUMERICAL', not close(ptr_pic, K(I, Iy[:, [0]].T) @ h12 @ K(I, Iy[:, [0]])),
        'the partial trace keeps only the k = 1 term (one diagonal block)')

# a pivotal structure on Vec_Z2 with a_s = -1: d_s = ev~ coev with ev~ = ev_{s*} (a_s (x) id) and
# ev = coev = 1 (omega = 1), so d_s = a_s; d_1 = 1, and d_{s (x) s} = d_s^2 = 1 = d_1
a_piv = {0: 1, 1: -1}
d = {g_: 1 * (a_piv[g_] * 1) * 1 for g_ in (0, 1)}
check('ex:4:negdim', 'EXACT', d[1] == -1 and d[(1 + 1) % 2] == d[1] * d[1] and d[0] == 1,
      'Vec_Z2 with a_s = -1: d_s = -1, and d_{s (x) s} = d_s d_s = 1 = d_1')

# ex:4:z3pivot -- on Vec_Z3 a character chi: k -> w^k (w = e^{2 pi i/3}) gives a pivotal
# structure with d_g = chi(g); d_{g*} = chi(g^{-1}) = conj(chi(g)) != chi(g) for g = 1: not spherical.
w3 = sp.exp(2 * sp.pi * sp.I / 3)
dch = lambda k: w3 ** (k % 3)                             # noqa: E731
check('ex:4:z3pivot', 'SYMBOLIC',
      all(sp.simplify(dch((a_ + b_) % 3) - dch(a_) * dch(b_)) == 0 for a_ in range(3) for b_ in range(3))
      and sp.simplify(dch(1) - dch(2)) != 0 and sp.simplify(dch(2) - sp.conjugate(dch(1))) == 0,
      'd_g = chi(g) is multiplicative; d_{g*} = d_{g^-1} = conj(d_g) differs from d_g for g = 1')
# ex:4:repdims -- in Rep(S3) the loop on std is its dimension 2 (canonical pivotal structure)
Fm = np.array([[1, 0], [-1, 1], [0, -1]], dtype=float)
std = lambda s_: np.linalg.solve(Fm.T @ Fm, Fm.T @ rho(s_) @ Fm)  # noqa: E731
I2s = np.eye(2)
check('ex:4:repdims', 'NUMERICAL', np.isclose((I2s.reshape(1, 4) @ I2s.reshape(4, 1)).item(), 2)
      and all(np.isclose(np.trace(std(s_)), np.trace(rho(s_)) - 1) for s_ in S3),
      'the loop on std is 2 = dim std; its character is chi_perm - 1')

# ================================================================ S4.4 Penrose and Frobenius-Schur
I2 = np.eye(2)
Om = np.array([[0, 1], [-1, 0]]).reshape(4, 1)          # e1 (x) e2 - e2 (x) e1
OmD = Om.conj().T
check('thm:4:penrose(cap = cup dagger)', 'NUMERICAL',
      close(K(I2, OmD) @ K(Om, I2), -I2) and np.isclose((OmD @ Om).item(), 2),
      'with cap = Omega^dagger: snake = -id, loop = +2')
check('thm:4:penrose(cap = -cup dagger)', 'NUMERICAL',
      close(K(I2, -OmD) @ K(Om, I2), I2) and np.isclose((-OmD @ Om).item(), -2),
      'with cap = -Omega^dagger: snake = +id, loop = -2')
# the second snake for the same pair
check('thm:4:penrose(other snake)', 'NUMERICAL', close(K(-OmD, I2) @ K(I2, Om), I2),
      'the other snake with cap = -Omega^dagger is also +id')
# uniqueness: any cap c with (id (x) c)(Omega (x) id) = id is -Omega^dagger
cs = sp.Matrix(1, 4, sp.symbols('c0:4'))
OmS = sp.Matrix([0, 1, -1, 0])
snake = sp.kronecker_product(sp.eye(2), cs) * sp.kronecker_product(OmS, sp.eye(2))
sol = sp.solve(list(snake - sp.eye(2)), list(cs), dict=True)
check('thm:4:penrose(unique cap)', 'SYMBOLIC', len(sol) == 1 and sp.Matrix(1, 4, [sol[0][c] for c in cs]) == -OmS.T,
      'the snake equation forces the cap to be -Omega^dagger')
# invariance: U (x) U Omega = det(U) Omega, so Omega is SU(2)-invariant
U = np.linalg.qr(crandn(2, 2))[0]
U = U / np.sqrt(np.linalg.det(U))
check('ex:4:singlet(invariant)', 'NUMERICAL', close(K(U, U) @ Om, Om), '(U (x) U) Omega = Omega for U in SU(2)')
# Frobenius-Schur: j: V -> V* the map v -> Omega(., v), matrix J; j* o a = J^T = -J: kappa = -1
J = np.array([[0, 1], [-1, 0]])
check('def:4:fs(spin 1/2)', 'EXACT', close(J.T, -J), 'j* o a = J^T = -J: kappa_{1/2} = -1')
Sym = np.array([[1, 0], [0, 1]])
check('def:4:fs(symmetric)', 'EXACT', close(Sym.T, Sym), 'a symmetric invariant form gives kappa = +1')
control('def:4:fs(spin 1/2)', 'EXACT', not close(J.T, J), 'the singlet form is symmetric')
# Symmetries' character formula for S3's standard representation: (1/6) sum chi(g^2) = 1
chi_std = lambda s: np.trace(rho(s)) - 1                 # noqa: E731
comp = lambda s, t: tuple(s[t[i]] for i in range(3))     # noqa: E731
fs_std = sum(chi_std(comp(s, s)) for s in S3) / 6
check('def:4:fs(S3 std)', 'EXACT', np.isclose(fs_std, 1), 'Symmetries\' (1/|G|) sum chi(g^2) = 1 for S3\'s std')

# ================================================================ S4.5 dagger
# Hilb_fd with orthonormal bases: ev~ = coev^dagger and ev = coev~^dagger (dagger pivotal)
check('thm:4:dagger', 'NUMERICAL', close(evt, coev.conj().T) and close(ev, coevt.conj().T),
      'in Hilb_fd (orthonormal bases) the caps are the daggers of the cups')

# ================================================================ round-1 repairs (C.3 L4)
# thm:4:pivotal needs End(1) = C: Opus's strict model, objects Z2, End(g) = C x C, the generator
# acting on End(1) by the swap; s (x) id_g != id_g (x) s, and multiplicativity fails.
def _act(g_, r):
    return r if g_ == 0 else (r[1], r[0])


def _mul(r, t):
    return (r[0] * t[0], r[1] * t[1])


def _tens(g_, r, h_, t, act=_act):                         # (r on g) (x) (t on h)
    return _mul(r, act(g_, t))


one2 = (1, 1)
trL2 = lambda g_, f_, act=_act: _tens(g_, f_, g_, one2, act)   # noqa: E731  ev = coev = a = 1
s_ = (1, 0)
control('thm:4:pivotal(End 1 = C)', 'EXACT', trL2(1, _tens(1, one2, 0, s_)) != _mul(trL2(1, one2), trL2(0, s_)),
        'with End(1) = C x C (swap action) tr_L(id_g (x) s) = tr_L(id_g) tr_L(s)')
# the scalars that are numbers, (x, x), are fixed by the swap by definition, so they move out: this
# records the model's consistency (it is not a test that can fail for End(1) = C)
check('thm:4:pivotal(End 1 = C: consistency)', 'EXACT',
      all(trL2(g_, _tens(g_, one2, 0, (x_, x_))) == _mul(trL2(g_, one2), trL2(0, (x_, x_)))
          for g_ in (0, 1) for x_ in (2, -3, 5)),
      'for scalars x id_1 (End(1) = C) tr_L(id_g (x) x) = tr_L(id_g) tr_L(x)')

# thm:4:penrose and the pivotal structure: in the presentation X* = V, coev = Omega, ev = c = -Omega^dag
# (straight snakes), the canonical a: X -> X** is the matrix A with A^T C = C^T; d = ev~ coev with
# ev~ = c (a (x) id).  Canonical a gives d = +2 and kappa = -1; (-1)^{2j} a gives d = -2 and kappa = +1.
Om4 = np.array([0, 1, -1, 0.]).reshape(4, 1)
c4 = -Om4.T
C4 = c4.reshape(2, 2)
A4 = (C4.T @ np.linalg.inv(C4)).T
d_can = (c4 @ K(A4, np.eye(2)) @ Om4).item()
d_flip = (c4 @ K(-A4, np.eye(2)) @ Om4).item()
check('thm:4:penrose(pivotal)', 'NUMERICAL', close(A4, -np.eye(2)) and np.isclose(d_can, 2) and np.isclose(d_flip, -2)
      and np.isclose((c4 @ Om4).item(), -2),
      'canonical a = -id here, d_V = +2; the straight cap closes the loop with -a: -2')
# kappa: j = id_V : X -> X* (= V).  Its dual j*: X** -> X* is the rotated box of L4 (b), computed:
# j* = (ev_{X*} (x) id_{X*}) (id_{X**} (x) j (x) id_{X*}) (id_{X**} (x) coev_X), with ev_{X*} = c4 (the
# presentation X** = V uses the same pairing) and coev_X = Om4; then j* a = kappa j
I2_ = np.eye(2)
J4 = I2_
jstar = K(c4, I2_) @ K(I2_, J4, I2_) @ K(I2_, Om4)
kap_can = (jstar @ A4)[0, 0] / J4[0, 0]
kap_flip = (jstar @ (-A4))[0, 0] / J4[0, 0]
check('def:4:fs(pivotal)', 'NUMERICAL', close(jstar @ A4, kap_can * J4) and np.isclose(kap_can, -1) and np.isclose(kap_flip, 1),
      'j* computed as a rotated box; j* a = kappa j with kappa_{1/2} = -1 (canonical a), +1 ((-1)^{2j} a)')
control('thm:4:penrose(pivotal)', 'NUMERICAL', not np.isclose(d_can, -2), 'with the canonical a the loop is -2')
# eq:4:loop orientation on Vec_Z3 = {1, r, r^2} with a_g = chi(g): tr_L(id_r) = chi(r), tr_R(id_r) = chi(r)^{-1}
trL_r = 1 * w3 * 1                                         # ev_{r*} (a_r (x) id) coev_r
trR_r = 1 * (1 / w3) * 1                                   # ev_r (id (x) a_r^{-1}) coev~
# (these are the definitions evaluated on scalars; the record is that the two closures differ)
check('eq:4:loop(orientation, by definition)', 'SYMBOLIC', sp.simplify(trL_r - w3) == 0 and sp.simplify(trR_r - trL_r) != 0,
      'the clockwise and counter-clockwise loops on r differ (chi(r) vs chi(r)^-1): orientation matters')

# Writing revision: expand the first dual comparison using exact, non-orthogonal data.
# Different dual bases ensure that omitting phi, or its inverse, is detected.
Ix_exact = sp.eye(2)
co_exact = sp.Matrix([1, 0, 0, 1])
ev_exact = co_exact.T
P_exact = sp.Matrix([[2, 1], [1, 1]])
kp = sp.kronecker_product
ev_prime = ev_exact * kp(P_exact.inv(), Ix_exact)
co_prime = kp(Ix_exact, P_exact) * co_exact
phi_exact = kp(ev_exact, Ix_exact) * kp(Ix_exact, co_prime)
psi_exact = kp(ev_prime, Ix_exact) * kp(Ix_exact, co_exact)
snake_prime = kp(Ix_exact, ev_prime) * kp(co_prime, Ix_exact)
compat_steps = [ev_prime * kp(phi_exact, Ix_exact),
                ev_exact * kp(Ix_exact, kp(Ix_exact, ev_prime))
                * kp(Ix_exact, co_prime, Ix_exact),
                ev_exact * kp(Ix_exact, snake_prime), ev_exact]
check('thm:4:snake(expanded cancellation)', 'EXACT',
      all(a == b for a, b in zip(compat_steps, compat_steps[1:]))
      and psi_exact * phi_exact == kp(ev_exact, Ix_exact) * kp(Ix_exact, co_exact) == Ix_exact,
      "ev' (phi (x) id) = ev (id (x) primed snake) = ev; psi phi = the unprimed snake")
control('thm:4:snake(expanded cancellation)', 'EXACT',
        ev_prime * kp(Ix_exact, Ix_exact) != ev_exact and psi_exact != Ix_exact,
        'replace the comparison phi by id despite the nontrivial change of dual basis')

# The closing cap depends linearly on the pivotal structure, with the left-dual data fixed.
Om_exact = sp.Matrix([0, 1, -1, 0])
c_exact = -Om_exact.T
A_exact = -Ix_exact   # canonical pivotal map in the presentation V* = V, coev = Omega
closing_canonical = c_exact * kp(A_exact, Ix_exact)
closing_flipped = c_exact * kp(-A_exact, Ix_exact)
check('thm:4:penrose(closing cap)', 'EXACT',
      closing_canonical == Om_exact.T and closing_flipped == -Om_exact.T
      and closing_canonical * Om_exact == sp.Matrix([[2]])
      and closing_flipped * Om_exact == sp.Matrix([[-2]]),
      'canonical closing cap is Omega dagger; flipping a changes it to -Omega dagger')
control('thm:4:penrose(closing cap)', 'EXACT', closing_flipped != closing_canonical,
        'the closing cap stays fixed when the pivotal structure changes sign')

# Double transposition T(j) = j* a is an involution.  Verify the displayed chain
# with arbitrary j in canonical dual bases; no complex conjugation belongs in the dual.
J_exact = sp.Matrix(2, 2, sp.symbols('j0:4'))
fs_steps = [(J_exact.T * Ix_exact).T * Ix_exact,
            Ix_exact.T * J_exact.T.T * Ix_exact,
            Ix_exact.T * Ix_exact * J_exact, J_exact]
check('def:4:fs(dual again)', 'SYMBOLIC',
      all(a == b for a, b in zip(fs_steps, fs_steps[1:])),
      '(j* a)* a = a* j** a = a* a_X* j = j, using naturality and pivotal compatibility')
lam_exact = 2 + sp.I
j_skew = sp.Matrix([[0, 1], [-1, 0]])
check('def:4:fs(scale independent)', 'EXACT', (lam_exact * j_skew).T == -lam_exact * j_skew,
      'dual is linear: rescaling a self-duality does not change kappa')
control('def:4:fs(scale independent)', 'EXACT',
        (lam_exact * j_skew).conjugate().T != -lam_exact * j_skew,
        'use the antilinear adjoint instead of the dual in the FS relation')
check('eq:4:flags(operational)', 'EXACT',
      kp(Ix_exact, Om_exact.T) * kp(Om_exact, Ix_exact) == -Ix_exact
      and kp(Ix_exact, -Om_exact.T) * kp(Om_exact, Ix_exact) == Ix_exact,
      'same-way flags are Omega and Omega dagger; reversing the cap gives a straight snake')
control('eq:4:flags(operational)', 'EXACT',
        kp(Ix_exact, Om_exact.T) * kp(Om_exact, Ix_exact) != Ix_exact,
        'same-way flags already give a straight snake')

print()
if FAILS:
    print(f'{len(FAILS)} FAILED: ' + ', '.join(FAILS))
    sys.exit(1)
print('All L4 checks pass.')
