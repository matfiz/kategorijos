"""Algebra script for Lecture 2, *Universal properties, adjunctions, semisimple categories*.

Representative finite-dimensional calculations that lectures/lec02.tex prints are checked
here before they are printed, on instances, each labelled SYMBOLIC (sympy, generic
entries), EXACT (integers, exact matrices) or NUMERICAL (floating point on random
instances), most with a control that must fail.  Universal claims rest on the lecture's
proofs and their review.
L2 prints no diagram equation; its pictures are commutative diagrams of universal
properties.

Conventions: as L1 (Bible K1; composition g o f, f first).  Tensor products of matrices
are Kronecker products with the first factor the slow index (Linear Algebra L12), so
u (x) v is np.kron(u, v).  Rep(S3): S3 acts on C^3 by permuting coordinates (L1's rho);
the standard representation is its restriction to the sum-zero plane, in Symmetries'
basis f1 = e1 - e2, f2 = e2 - e3 (lec04.tex:473-482); sgn is the sign.  Hom spaces of
representations are computed as null spaces of the intertwiner equations, exactly.

Run:  python3 scripts/check-l2-algebra.py     (exit status 1 on failure)
"""
import itertools
import sys

import numpy as np
import sympy as sp

FAILS = []
RNG = np.random.default_rng(20261022)


def check(label, kind, ok, what):
    print(f"{'OK  ' if ok else 'FAIL'} [{kind:9s}] {label}: {what}")
    if not ok:
        FAILS.append(label)


def control(label, kind, failed, what):
    check(label + ' (control)', kind, failed, what + ' -- must fail, and does')


def crandn(*shape):
    return RNG.standard_normal(shape) + 1j * RNG.standard_normal(shape)


def close(a, b, tol=1e-10):
    return np.allclose(a, b, atol=tol, rtol=0)


# ===================================================================== S2.1 universal properties
# ex:2:setvect -- in Set the product and the coproduct differ: |X x Y| = 6, |X u Y| = 5 for 2, 3.
X, Y = range(2), range(3)
prod = list(itertools.product(X, Y))
coprod = [(0, x) for x in X] + [(1, y) for y in Y]
check('ex:2:setvect(Set)', 'EXACT', (len(prod), len(coprod)) == (6, 5),
      'in Set, |X x Y| = 6 and |X u Y| = 5 for |X| = 2, |Y| = 3')

# def:2:biproduct -- C^2 (+) C^3 with its injections and projections.
m, n = 2, 3
i1 = np.vstack([np.eye(m), np.zeros((n, m))])
i2 = np.vstack([np.zeros((m, n)), np.eye(n)])
p1, p2 = i1.T, i2.T
check('def:2:biproduct', 'EXACT',
      close(p1 @ i1, np.eye(m)) and close(p2 @ i2, np.eye(n)) and close(p1 @ i2, 0)
      and close(p2 @ i1, 0) and close(i1 @ p1 + i2 @ p2, np.eye(m + n)),
      'p_k i_l = delta_kl id and i1 p1 + i2 p2 = id on C^2 (+) C^3')
control('def:2:biproduct', 'EXACT', not close(i1 @ p1, np.eye(m + n)),
        'i1 p1 = id alone (dropping the second summand)')

# eq:2:matrixarrows -- a map X1 (+) X2 -> Y1 (+) Y2 is the matrix (p_j f i_k); composing is
# the matrix product of these matrices of maps.
dims_x, dims_y, dims_z = (2, 3), (1, 2), (3, 1)


def blocks(dims):
    tot = sum(dims)
    inj, proj, off = [], [], 0
    for d in dims:
        I = np.zeros((tot, d))
        I[off:off + d, :] = np.eye(d)
        inj.append(I)
        proj.append(I.T)
        off += d
    return inj, proj


iX, pX = blocks(dims_x)
iY, pY = blocks(dims_y)
iZ, pZ = blocks(dims_z)
f = crandn(sum(dims_y), sum(dims_x))
g = crandn(sum(dims_z), sum(dims_y))
fjk = [[pY[j] @ f @ iX[k] for k in range(2)] for j in range(2)]
check('eq:2:matrixarrows(reassemble)', 'NUMERICAL',
      close(sum(iY[j] @ fjk[j][k] @ pX[k] for j in range(2) for k in range(2)), f),
      'f = sum_{j,k} i_j f_jk p_k')
gf = g @ f
ok = all(close(pZ[l] @ gf @ iX[k], sum((pZ[l] @ g @ iY[j]) @ fjk[j][k] for j in range(2)))
         for l in range(2) for k in range(2))
check('eq:2:matrixarrows(compose)', 'NUMERICAL', ok, '(g o f)_lk = sum_j g_lj o f_jk')
control('eq:2:matrixarrows(compose)', 'NUMERICAL',
        not close(pZ[0] @ gf @ iX[0], (pZ[0] @ g @ iY[0]) @ fjk[0][0]),
        '(g o f)_11 = g_11 o f_11, keeping only the j = 1 term of the sum')

# ===================================================================== S2.2 representables
# prop:2:repunique -- a natural isomorphism alpha: Hom(X, -) => Hom(X', -) is
# alpha_Y(f) = f o phi with phi = alpha_X(id_X), and phi is invertible.  Instance in Vect_fd
# with X = X' = C^3: alpha_Y(f) = f o phi for an invertible phi.
phi = crandn(3, 3)
alpha = lambda fY: fY @ phi                            # noqa: E731
fy, gyy = crandn(2, 3), crandn(4, 2)
check('prop:2:repunique(natural)', 'NUMERICAL', close(alpha(gyy @ fy), gyy @ alpha(fy)),
      "alpha_{Y'}(g o f) = g o alpha_Y(f): precomposition is natural in Y")
check('prop:2:repunique(phi)', 'NUMERICAL', close(alpha(np.eye(3)), phi) and close(alpha(fy), fy @ alpha(np.eye(3))),
      'phi = alpha_X(id_X), and alpha_Y(f) = f o phi')
psi = np.linalg.inv(phi)
alpha_inv = lambda gY: gY @ psi                        # noqa: E731
check('prop:2:repunique(inverse)', 'NUMERICAL',
      close(alpha_inv(np.eye(3)), psi) and close(phi @ psi, np.eye(3)) and close(psi @ phi, np.eye(3)),
      'psi = alpha^{-1}_{X\'}(id), and phi psi = id, psi phi = id')
g33 = crandn(3, 3)
post = lambda h: phi @ h                               # noqa: E731  postcomposition, X = Y = C^3
f33 = crandn(3, 3)
control('prop:2:repunique(natural)', 'NUMERICAL', not close(post(g33 @ f33), g33 @ post(f33)),
        'alpha_Y(f) = phi o f (postcomposing) is natural in Y')

# ===================================================================== S2.3 adjunctions
# thm:2:tensorhom -- Phi: Hom(U (x) V, W) -> Hom(U, Hom(V, W)), Phi(f)(u)(v) = f(u (x) v).
# Represent Phi(f) as the array T[w, u, v] = f[w, (u, v)] (u slow), i.e. a reshape.
dU, dV, dW = 2, 3, 2
fUVW = crandn(dW, dU * dV)


def Phi(fm, dU=dU, dV=dV):
    return fm.reshape(fm.shape[0], dU, dV)             # T[w, u, v]


def Phi_inv(T):
    return T.reshape(T.shape[0], -1)


u, v = crandn(dU), crandn(dV)
check('thm:2:tensorhom(Phi)', 'NUMERICAL',
      close(np.einsum('wuv,u,v->w', Phi(fUVW), u, v), fUVW @ np.kron(u, v)),
      'Phi(f)(u)(v) = f(u (x) v)')
# The inverse by the universal property: from g: U -> Hom(V, W) (here T[w, u, v]) form the
# bilinear map (u, v) -> g(u)(v) and the unique linear f with f(e_i (x) e_j) = g(e_i)(e_j).
def from_bilinear(T):
    fm = np.zeros((T.shape[0], dU * dV), dtype=complex)
    for i_ in range(dU):
        for j_ in range(dV):
            fm[:, i_ * dV + j_] = np.einsum('wuv,u,v->w', T, np.eye(dU)[i_], np.eye(dV)[j_])
    return fm


Tg = crandn(dW, dU, dV)                                # an arbitrary g
check('thm:2:tensorhom(bijection)', 'NUMERICAL',
      close(Phi(from_bilinear(Tg)), Tg) and close(from_bilinear(Phi(fUVW)), fUVW),
      'Theta and the universal-property inverse are mutually inverse (both directions)')
# naturality in U: a: U' -> U, Phi(f o (a (x) id_V)) = Phi(f) o a
dU2 = 4
a = crandn(dU, dU2)
lhs = Phi(fUVW @ np.kron(a, np.eye(dV)), dU=dU2)
rhs = np.einsum('wuv,ux->wxv', Phi(fUVW), a)
check('thm:2:tensorhom(natural in U)', 'NUMERICAL', close(lhs, rhs), 'Phi(f o (a (x) id)) = Phi(f) o a')
control('thm:2:tensorhom(natural in U)', 'NUMERICAL',
        not close(lhs, np.einsum('wuv,ux->wxv', Phi(fUVW), a.conj())),
        'Phi(f o (a (x) id)) = Phi(f) o conj(a)')
# naturality in W: b: W -> W', Phi(b o f) = (b o -) o Phi(f)
b = crandn(3, dW)
check('thm:2:tensorhom(natural in W)', 'NUMERICAL',
      close(Phi(b @ fUVW), np.einsum('xw,wuv->xuv', b, Phi(fUVW))), 'Phi(b o f) = Hom(V, b) o Phi(f)')

# unit and counit: unit_U(u) = (v -> u (x) v); counit_W(g (x) v) = g(v), and the triangle
# identities  counit_{U (x) V} o (unit_U (x) id_V) = id_{U (x) V},
#             Hom(V, counit_W) o unit_{Hom(V, W)} = id_{Hom(V, W)}.
# unit_U as a matrix C^{dU} -> Hom(V, U (x) V) = C^{(dU dV) x dV}, flattened row-major.
def unit_U(uvec):
    return np.kron(uvec.reshape(-1, 1), np.eye(dV))   # (dU dV) x dV matrix: v -> u (x) v


def counit_W(Gm, vvec):
    return Gm @ vvec                                    # g (x) v -> g(v)


uu, vv = crandn(dU), crandn(dV)
check('def:2:adjunction(triangle 1)', 'NUMERICAL', close(counit_W(unit_U(uu), vv), np.kron(uu, vv)),
      'counit(unit(u) (x) v) = u (x) v')
Gm = crandn(dW, dV)


def counit_tensor(t):
    """counit on Hom(V, W) (x) V, the tensor given as an array t[w, a, b] (G_{wa} v_b):
    sum_a t[w, a, a], i.e. g (x) v -> g(v)."""
    return np.einsum('waa->w', t)


ok = True
for e in np.eye(dV):
    t = np.einsum('wa,b->wab', Gm, e)                  # unit_{Hom(V,W)}(G)(e) = G (x) e
    ok &= close(counit_tensor(t), Gm @ e)
check('def:2:adjunction(triangle 2)', 'NUMERICAL', ok,
      'Hom(V, counit) o unit sends G to G: v -> counit(G (x) v) = G v, on a basis')
control('def:2:adjunction(triangle 2)', 'NUMERICAL',
        not close(np.einsum('wab->w', np.einsum('wa,b->wab', Gm, np.eye(dV)[0])), Gm @ np.eye(dV)[0]),
        'a counit summing all entries of G (x) v instead of the trace over the matching slots')

# ============================================================ S2.4 linear and semisimple
S3 = list(itertools.permutations(range(3)))


def rho3(s):
    M = sp.zeros(3, 3)
    for i in range(3):
        M[s[i], i] = 1
    return M


def sgn(s):
    return sp.Matrix([[sp.Matrix(rho3(s)).det()]])


F = sp.Matrix([[1, 0], [-1, 1], [0, -1]])               # f1 = e1 - e2, f2 = e2 - e3


def std(s):
    return (F.T * F).inv() * F.T * rho3(s) * F        # the action on span(f1, f2)


triv = lambda s: sp.Matrix([[1]])                      # noqa: E731
check('ex:2:s3(std is a representation)', 'EXACT',
      all(rho3(s) * F == F * std(s) for s in S3)
      and all(std(tuple(s[t[i]] for i in range(3))) == std(s) * std(t) for s in S3 for t in S3),
      'the sum-zero plane is invariant, and std is a homomorphism (f1, f2 basis)')


def homdim(A, B):
    """dim Hom_G(A, B): the null space of T A(g) = B(g) T for all g."""
    da, db = A(S3[0]).shape[0], B(S3[0]).shape[0]
    T = sp.Matrix(db, da, sp.symbols(f't0:{da * db}'))
    eqs = []
    for s in S3:
        eqs += list(T * A(s) - B(s) * T)
    Mx = sp.Matrix([[sp.diff(e, t) for t in T] for e in eqs])
    return da * db - Mx.rank()


irr = {'1': triv, 'sgn': sgn, 'std': std}
schur = all(homdim(irr[a_], irr[b_]) == (1 if a_ == b_ else 0) for a_ in irr for b_ in irr)
check('def:2:semisimple(S1) for Rep(S3)', 'EXACT', schur,
      'Hom(X_i, X_j) = C delta_ij for the three irreducibles of S3 (Schur)')
mult = {k: homdim(irr[k], rho3) for k in irr}
check('ex:2:s3(multiplicities)', 'EXACT', mult == {'1': 1, 'sgn': 0, 'std': 1},
      'm_i = dim Hom(X_i, C^3) = 1, 0, 1: C^3 = 1 (+) std')
check('ex:2:s3(End)', 'EXACT', homdim(rho3, rho3) == 2 == sum(k * k for k in mult.values()),
      'dim End(C^3) = 2 = 1^2 + 0^2 + 1^2: spanned by I and L1\'s u o s (the ones matrix J here)')
a_, b_ = sp.symbols('a b')
Jm = sp.ones(3, 3)
P1 = Jm / 3
Pstd = sp.eye(3) - Jm / 3
check('ex:2:s3(aI + bJ)', 'SYMBOLIC',
      sp.simplify(a_ * sp.eye(3) + b_ * Jm - ((a_ + 3 * b_) * P1 + a_ * Pstd)) == sp.zeros(3, 3)
      and P1 * P1 == P1 and Pstd * Pstd == Pstd and P1 * Pstd == sp.zeros(3, 3),
      'a I + b J = (a + 3b) P_1 + a P_std: the scalars (a + 3b, a) on the two simples')
control('ex:2:s3(aI + bJ)', 'SYMBOLIC',
        sp.simplify(a_ * sp.eye(3) + b_ * Jm - ((a_ + b_) * P1 + a_ * Pstd)) != sp.zeros(3, 3),
        'a I + b J = (a + b) P_1 + a P_std')


def regular(s):
    """The regular representation of S3 on C[S3]."""
    idx = {t: k for k, t in enumerate(S3)}
    M = sp.zeros(6, 6)
    for t in S3:
        M[idx[tuple(s[t[i]] for i in range(3))], idx[t]] = 1
    return M


mreg = {k: homdim(irr[k], regular) for k in irr}
check('ex:2:s3(regular)', 'EXACT', mreg == {'1': 1, 'sgn': 1, 'std': 2},
      'C[S3] = 1 (+) sgn (+) std^2')
check('thm:2:schur(Hom formula)', 'EXACT',
      homdim(rho3, regular) == sum(mult[k] * mreg[k] for k in irr) == 3,
      'dim Hom(C^3, C[S3]) = sum_i m_i(C^3) m_i(C[S3]) = 1*1 + 0*1 + 1*2 = 3')
control('thm:2:schur(Hom formula)', 'EXACT', homdim(rho3, regular) != sum(mult[k] + mreg[k] for k in irr),
        'dim Hom = sum_i (m_i(C^3) + m_i(C[S3])), sums instead of products')

# ex:2:end -- End(1 (+) 1 (+) std) = M_2(C) x C: dimension 5, not commutative.
def X112(s):
    M = sp.zeros(4, 4)
    M[0, 0] = M[1, 1] = 1
    M[2:4, 2:4] = std(s)
    return M


check('ex:2:end', 'EXACT', homdim(X112, X112) == 2 * 2 + 1 * 1 == 5,
      'dim End(1 (+) 1 (+) std) = 2^2 + 1^2 = 5')
E12 = sp.zeros(4, 4); E12[0, 1] = 1
E21 = sp.zeros(4, 4); E21[1, 0] = 1
check('ex:2:end(non-commutative)', 'EXACT',
      all(E12 * X112(t) == X112(t) * E12 and E21 * X112(t) == X112(t) * E21 for t in S3)
      and E12 * E21 != E21 * E12,
      'the matrix units E12, E21 between the two trivial summands are intertwiners and do not commute')
# thm:2:schur(inverse) -- the map zeta_X: G(H(X)) -> X of the proof, for X = C^3 in Rep(S3):
# basis vectors of H_1(X) = Hom(1, C^3) and H_std(X) = Hom(std, C^3) (random multiples of u
# and of the inclusion F of the plane) assemble to zeta_X = [c1 u | c2 F]; it must be an
# intertwiner from 1 (+) std to C^3, and invertible.
c1, c2 = sp.Rational(3, 7), sp.Rational(-5, 2)
uvec = sp.Matrix([1, 1, 1])
zeta = sp.Matrix.hstack(c1 * uvec, c2 * F)
plus = lambda s_: sp.diag(triv(s_), std(s_))             # noqa: E731  1 (+) std
check('thm:2:schur(inverse)', 'EXACT', all(zeta * plus(t) == rho3(t) * zeta for t in S3) and zeta.det() != 0,
      'zeta_X = (b_ij) : 1 (+) std -> C^3 is an invertible intertwiner, for fixed non-zero basis scalars')
# naturality f o zeta_X = zeta_X o G(H(f)) for f = a I + b (u o s) in End(C^3): in the bases
# (c1 u) of H_1 and (c2 F e_1, c2 F e_2) of H_std, G(H(f)) = diag(a + 3b, a, a).
fa, fb = sp.symbols('f_a f_b')
fmat = fa * sp.eye(3) + fb * sp.ones(3, 3)
GHf = sp.diag(fa + 3 * fb, fa, fa)
check('thm:2:schur(inverse, natural)', 'SYMBOLIC', sp.simplify(fmat * zeta - zeta * GHf) == sp.zeros(3, 3),
      'f o zeta_X = zeta_X o G(H(f)) with G(H(f)) = diag(a + 3b, a, a)')
control('thm:2:schur(inverse, natural)', 'SYMBOLIC',
        sp.simplify(fmat * zeta - zeta * sp.diag(fa + fb, fa, fa)) != sp.zeros(3, 3),
        'G(H(f)) = diag(a + b, a, a) (the wrong scalar on the trivial summand)')
bad_zeta = sp.Matrix.hstack(sp.Matrix([1, 0, 0]), c2 * F)
control('thm:2:schur(inverse)', 'EXACT', any(bad_zeta * plus(t) != rho3(t) * bad_zeta for t in S3),
        'a "basis vector" e1 that is not a morphism 1 -> C^3 still assembles to an intertwiner')

# rem:2:z3 -- Rep(Z3) also has three simple objects (three characters, Z3 abelian), so
# Rep(S3), Rep(Z3) and Vect_fd^3 are equivalent as linear categories.
w = sp.exp(2 * sp.pi * sp.I / 3)
chars = [lambda k, j=j: sp.Matrix([[w ** (j * k)]]) for j in range(3)]
Z3 = list(range(3))


def homdimZ3(A, B):
    T = sp.Symbol('t')
    eqs = [sp.simplify(T * A(k)[0, 0] - B(k)[0, 0] * T) for k in Z3]
    return 0 if any(sp.simplify(e) != 0 for e in eqs) else 1


check('rem:2:z3', 'EXACT', all(homdimZ3(chars[i], chars[j]) == (1 if i == j else 0)
                                for i in range(3) for j in range(3))
      and all(sp.simplify(chars[j](k1 + k2)[0, 0] - chars[j](k1)[0, 0] * chars[j](k2)[0, 0]) == 0
              for j in range(3) for k1 in Z3 for k2 in Z3),
      'Z3 has three one-dimensional irreducibles k -> w^{jk}, pairwise non-isomorphic')
# rem:2:dims -- dim X = sum_i m_i(X) dim X_i with dims 1, 1, 2 for S3:
check('rem:2:dims', 'EXACT', 1 * 1 + 0 * 1 + 1 * 2 == 3 and 1 * 1 + 1 * 1 + 2 * 2 == 6,
      'dim C^3 = 1*1 + 0*1 + 1*2 = 3 and dim C[S3] = 1 + 1 + 2*2 = 6')
control('rem:2:dims', 'EXACT', 1 + 1 + 2 != 6, 'dim C[S3] = sum of multiplicities 1 + 1 + 2')

# ex:2:currying -- in Set, functions X x B -> C are functions X -> C^B: |C|^{|X||B|}.
Xs, Bs, Cs = 2, 3, 2
check('ex:2:currying', 'EXACT', Cs ** (Xs * Bs) == (Cs ** Bs) ** Xs,
      '|Hom(X x B, C)| = |C|^{|X||B|} = |Hom(X, C^B)|')

# ============================================================ S2.5 a Jordan block
N = sp.Matrix([[0, 1], [0, 0]])
rhoZ = lambda k: sp.eye(2) + k * N                     # noqa: E731
kk, ll = sp.symbols('k l', integer=True)
check('ex:2:jordan(representation)', 'SYMBOLIC', sp.simplify(rhoZ(kk + ll) - rhoZ(kk) * rhoZ(ll)) == sp.zeros(2, 2),
      'rho(k + l) = rho(k) rho(l) for rho(k) = [[1, k], [0, 1]]')
Tz = sp.Matrix(2, 2, sp.symbols('z0:4'))
solZ = sp.solve(list(Tz * rhoZ(1) - rhoZ(1) * Tz), list(Tz), dict=True)[0]
EndZ = Tz.subs(solZ)
check('guard:2:jordan(End)', 'SYMBOLIC', len(EndZ.free_symbols) == 2 and N * rhoZ(1) == rhoZ(1) * N,
      'End(C^2) = span(I, N) is two-dimensional, so C^2 is not one of the X_i (S1)')
ev = rhoZ(1).eigenvects()
check('guard:2:jordan', 'EXACT', len(ev) == 1 and ev[0][1] == 2 and len(ev[0][2]) == 1
      and ev[0][2][0].normalized() == sp.Matrix([1, 0]),
      'rho(1) has the single eigenvalue 1 with a single eigenline C e1: no invariant complement')
control('guard:2:jordan', 'EXACT', len((sp.eye(2) + 0 * N).eigenvects()[0][2]) != 1,
        'with N replaced by 0 (a semisimple representation) there is still only one eigenline')

print()
if FAILS:
    print(f'{len(FAILS)} FAILED: ' + ', '.join(FAILS))
    sys.exit(1)
print('All L2 checks pass.')
