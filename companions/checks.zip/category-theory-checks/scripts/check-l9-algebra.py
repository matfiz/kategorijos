"""Algebra script for Lecture 9, *Ribbon categories, Temperley-Lieb and SU(2)_k*.

This script checks, on instances, the twist axiom and the inverse curl on tensor powers of V1, the
Temperley-Lieb relations and the Kauffman bracket (RI, RII, RIII), the Jones-Wenzl
projectors p_2, p_3 and their traces and twists, the negligible p_{k+1}, and the pivotal
flip to SU(2)_k that lectures/lec09.tex prints, labelled SYMBOLIC, EXACT or NUMERICAL, some
with a control that must fail.  The curl is computed on cables (the right partial trace of
c_{X,X}, X = V1^{(x) n}), not assumed.  Conventions: Bible K2 (/-over), K18 (B_q, the cup
v = e1 e2 - q e2 e1, the cap u, c = A^{-1} B_q = A 1 + A^{-1} U, q = A^2, delta = -[2]_q),
K14 (the spin formula).  Pictures are checked by rendering, not here.

Run:  python3 scripts/check-l9-algebra.py     (exit status 1 on failure)
"""
import cmath
import math
import sys

import numpy as np
import sympy as sp

FAILS = []


def check(label, kind, ok, what):
    print(f"{'OK  ' if ok else 'FAIL'} [{kind:9s}] {label}: {what}")
    if not ok:
        FAILS.append(label)


def control(label, kind, failed, what):
    check(label + ' (control)', kind, failed, what + ' -- must fail, and does')


tp = sp.kronecker_product
zero = lambda M: sp.simplify(M) == sp.zeros(*M.shape)                      # noqa: E731
close = lambda a, b, tol=1e-9: abs(complex(a) - complex(b)) < tol           # noqa: E731
qint = lambda n, q: (q ** n - q ** -n) / (q - 1 / q)                       # noqa: E731

A = sp.Symbol('A', nonzero=True)
q = A ** 2
I2, I4 = sp.eye(2), sp.eye(4)
Bq = sp.Matrix([[q, 0, 0, 0], [0, q - 1 / q, 1, 0], [0, 1, 0, 0], [0, 0, 0, q]])
c = Bq / A
v = sp.Matrix([0, 1, -q, 0])               # the cup C -> V1 (x) V1 (K18)
u = sp.Matrix([[0, -1 / q, 1, 0]])         # the cap with both snakes straight
U = v * u
delta = (u * v)[0]

# ================================================================ S9.3 TL and the Kauffman bracket
check('def:9:tl', 'EXACT', zero(tp(u, I2) * tp(I2, v) - I2) and zero(tp(I2, u) * tp(v, I2) - I2)
      and sp.simplify(delta + A ** 2 + A ** -2) == 0,
      'both snakes are straight with cup v and cap u; the loop is delta = -A^2 - A^{-2} = -[2]_q')
check('eq:9:loop(cap)', 'EXACT', list(u) == [0, -1 / q, 1, 0]
      and sp.simplify((u * v)[0] - (-1 / q - q)) == 0,
      'u(e1 e1) = u(e2 e2) = 0, u(e1 e2) = -q^{-1}, u(e2 e1) = 1; u(v) = -q^{-1} - q')
control('eq:9:loop(cap)', 'EXACT', not zero(tp(-u, I2) * tp(I2, v) - I2),
        'reversing the cap sign still gives a straight snake')
U1, U2 = tp(U, I2), tp(I2, U)
check('def:9:tl(relations)', 'EXACT', zero(U * U - delta * U) and zero(U1 * U2 * U1 - U1) and zero(U2 * U1 * U2 - U2),
      'U = vu satisfies U^2 = delta U and U1 U2 U1 = U1, U2 U1 U2 = U2')
check('eq:9:skein', 'EXACT', zero(c - (A * I4 + U / A)) and zero(c.inv() - (I4 / A + A * U)),
      'the skein relation: the /-over crossing is A (id) + A^{-1} (cup-cap), its inverse A^{-1} (id) + A (cup-cap)')
control('eq:9:skein', 'EXACT', not zero(c - (I4 / A + A * U)), 'the crossing is A^{-1} (id) + A (cup-cap)')
curl = sp.simplify(tp(I2, u) * tp(c, I2) * tp(I2, v))
curl_inv = sp.simplify(tp(I2, u) * tp(c.inv(), I2) * tp(I2, v))
check('thm:9:kauffman(RI)', 'EXACT', zero(curl + A ** 3 * I2) and zero(curl_inv + A ** -3 * I2),
      'RI: a positive curl is -A^3, a negative one -A^{-3}')
check('thm:9:kauffman(RII,RIII)', 'EXACT', zero((A * I4 + U / A) * (I4 / A + A * U) - I4)
      and zero(tp(c, I2) * tp(I2, c) * tp(c, I2) - tp(I2, c) * tp(c, I2) * tp(I2, c)),
      'RII: the printed expansion (A + A^{-1}U)(A^{-1} + AU) = 1; RIII: the braid relation')
control('thm:9:kauffman(RII)', 'EXACT', not zero((A * I4 + U / A) * (A * I4 + U / A) - I4),
        'the crossing is its own inverse (RII with two equal crossings)')
# the Hopf link: two linked unknots with two positive crossings -> -A^4 - A^{-4} (Sheet 9 computes more)
hopf = sp.simplify((tp(u, u) * tp(I2, c * c, I2) * tp(v, v))[0])
check('eq:9:hopf', 'EXACT', sp.simplify(hopf / delta - (-A ** 4 - A ** -4)) == 0,
      'the Hopf link (two positive crossings) is delta (-A^4 - A^{-4}): -A^4 - A^{-4} with the unknot normalised to 1')

hopf_expansion = A ** 2 * delta ** 2 + (2 + A ** -2 * delta) * delta
check('eq:9:hopf(expansion)', 'EXACT', zero(c * c - (A ** 2 * I4 + (2 + A ** -2 * delta) * U))
      and sp.simplify(hopf - hopf_expansion) == 0
      and sp.simplify(hopf_expansion - delta * (-A ** 4 - A ** -4)) == 0,
      'expand c^2 = A^2 id + (2 + A^{-2} delta) U, then close id to delta^2 and U to delta')
control('eq:9:hopf(expansion)', 'EXACT', sp.simplify(hopf - (A ** 2 * delta + (2 + A ** -2 * delta) * delta ** 2)) != 0,
        'the closures of id and U are interchanged')

# ================================================================ S9.1 twist and ribbon on V1
theta1 = -A ** 3
# L7's spin formula with TL dims d_0 = 1, d_1 = -[2], d_2 = [3] and R-eigenvalues -A^{-3} (singlet), A (triplet)
d0, d1, d2 = 1, -(q + 1 / q), q ** 2 + 1 + q ** -2
th_from_R = (d0 * (-A ** -3) + d2 * A) / d1
check('thm:9:ribbon(curl)', 'SYMBOLIC', sp.simplify(th_from_R - theta1) == 0,
      'L7\'s formula theta_a = d_a^{-1} sum_c N d_c R^{aa}_c with TL\'s dimensions (TL\'s pivotal structure) gives -A^3, the TL curl')
# ribbon axiom on V1 (x) V1: theta_{V(x)V} = c^2 (theta (x) theta); on the triplet (p_2) it is theta_2 = A^8
cc = sp.simplify(c * c)
lhs_trip = sp.simplify((cc * theta1 ** 2)[0, 0])                 # e1 e1 is in the triplet
lhs_sing = sp.simplify(((cc * theta1 ** 2) * v)[1] / v[1])     # on the singlet
check('thm:9:ribbon', 'EXACT', sp.simplify(lhs_trip - A ** 8) == 0 and sp.simplify(lhs_sing - 1) == 0,
      'theta_{V1 (x) V1} = c^2 (theta_1 (x) theta_1) is A^8 on the triplet (theta_2) and 1 on the singlet (theta_0)')
control('thm:9:ribbon', 'EXACT', sp.simplify((theta1 ** 2 * I4)[0, 0] - A ** 8) != 0,
        'theta_{V (x) V} = theta (x) theta (no double braiding)')

# ================================================================ S9.4 JW projectors
dl = sp.Symbol('delta', nonzero=True)
check('thm:9:jw(p2)', 'EXACT', zero((I4 - U / delta) ** 2 - (I4 - U / delta)) and zero(U * (I4 - U / delta)),
      'p_2 = 1 - U/delta is idempotent and U p_2 = 0 (delta != 0)')


def jw(n, Aval):
    qv = Aval ** 2
    Un = np.array(sp.N(U.subs(A, Aval)), dtype=complex)
    ps = [np.eye(2, dtype=complex)]
    for m in range(1, n):
        p = np.kron(ps[-1], np.eye(2))
        Um = np.kron(np.eye(2 ** (m - 1)), Un)
        ps.append(p + qint(m, qv) / qint(m + 1, qv) * p @ Um @ p)
    return ps


def qtrace(X, n, Aval):
    vn = np.array(sp.N(v.subs(A, Aval)), dtype=complex).reshape(4, 1)
    un = np.array(sp.N(u.subs(A, Aval)), dtype=complex).reshape(1, 4)
    cup, cap = vn, un
    for m in range(1, n):
        cup = np.kron(np.kron(np.eye(2 ** m), vn), np.eye(2 ** m)) @ cup
        cap = cap @ np.kron(np.kron(np.eye(2 ** m), un), np.eye(2 ** m))
    return (cap @ np.kron(X, np.eye(2 ** n)) @ cup).item()


Ag = cmath.exp(0.37j)
ps = jw(4, Ag)
Uv = np.array(sp.N(U.subs(A, Ag)), dtype=complex)
ok = all(np.allclose(p @ p, p) for p in ps) and all(
    np.allclose(np.kron(np.kron(np.eye(2 ** i), Uv), np.eye(2 ** (n - i - 2))) @ ps[n - 1], 0)
    for n in range(2, 5) for i in range(n - 1))
check('thm:9:jw', 'NUMERICAL', ok and all(close(qtrace(ps[n - 1], n, Ag), (-1) ** n * qint(n + 1, Ag ** 2)) for n in range(1, 5)),
      'JW p_1..p_4 by the recursion: idempotent, killed by every U_i; tr p_n = (-1)^n [n+1]_q')
# p_2 is the projection onto the q-triplet (rank 3); at q = 1 it is the symmetriser (Symmetries)
p2 = np.array(sp.N((I4 - U / delta).subs(A, 1)), dtype=float)
sym = (np.eye(4) + np.array([[1, 0, 0, 0], [0, 0, 1, 0], [0, 1, 0, 0], [0, 0, 0, 1]])) / 2
check('ex:9:p2', 'NUMERICAL', np.allclose(p2, sym) and round(np.trace(ps[1]).real) == 3,
      'p_2 has rank 3 (spin 1), and at q = 1 it is the symmetriser (1 + P)/2')
# the twist on p_n: theta_n = (-1)^n A^{n(n+2)}
cn = np.array(sp.N(c.subs(A, Ag)), dtype=complex)


def full_twist(n):
    sig = [np.kron(np.kron(np.eye(2 ** i), cn), np.eye(2 ** (n - i - 2))) for i in range(n - 1)]
    w = np.eye(2 ** n, dtype=complex)
    for s_ in sig:
        w = s_ @ w
    return np.linalg.matrix_power(w, n)


ok = True
for n in range(2, 5):
    D2 = full_twist(n) @ ps[n - 1]
    lam = np.trace(D2) / np.trace(ps[n - 1])
    ok &= np.allclose(D2, lam * ps[n - 1]) and close(lam * (-Ag ** 3) ** n, (-1) ** n * Ag ** (n * (n + 2)))
check('eq:9:thetan', 'NUMERICAL', ok, 'theta_n = (-1)^n A^{n(n+2)} on p_n (the full twist times theta_1^n)')

# ---------------------------------------------------------------- the curl on cables, computed
def cup_n(n, Aval):
    vn = np.array(sp.N(v.subs(A, Aval)), dtype=complex).reshape(4, 1)
    cup = vn
    for m in range(1, n):
        cup = np.kron(np.kron(np.eye(2 ** m), vn), np.eye(2 ** m)) @ cup
    return cup


def cap_n(n, Aval):
    un = np.array(sp.N(u.subs(A, Aval)), dtype=complex).reshape(1, 4)
    cap = un
    for m in range(1, n):
        cap = cap @ np.kron(np.kron(np.eye(2 ** m), un), np.eye(2 ** m))
    return cap


def cross_XX(n):
    """c_{X,X} for X = V1^{(x) n}: each strand of the left cable crosses over the right cable."""
    sig = [np.kron(np.kron(np.eye(2 ** i), cn), np.eye(2 ** (2 * n - i - 2))) for i in range(2 * n - 1)]
    w = np.eye(2 ** (2 * n), dtype=complex)
    for i in reversed(range(n)):
        for j in range(i, i + n):
            w = sig[j] @ w
    return w


def curl_n(n, Aval):
    """the right partial trace of c_{X,X}: (id (x) cap)(c_{X,X} (x) id)(id (x) cup)."""
    N_ = 2 ** n
    return np.kron(np.eye(N_), cap_n(n, Aval)) @ np.kron(cross_XX(n), np.eye(N_)) @ np.kron(np.eye(N_), cup_n(n, Aval))


def left_inverse_curl_n(n, Aval, inverse=True):
    """the curl drawn with the inverse crossing and the cap on the other side:
    (cap (x) id)(id (x) c^{-1}_{X,X})(cup (x) id)."""
    N_ = 2 ** n
    W = cross_XX(n)
    W = np.linalg.inv(W) if inverse else W
    return np.kron(cap_n(n, Aval), np.eye(N_)) @ np.kron(np.eye(N_), W) @ np.kron(cup_n(n, Aval), np.eye(N_))


th1 = curl_n(1, Ag)
th2 = curl_n(2, Ag)
c2 = cn @ cn
check('thm:9:ribbon(cable)', 'NUMERICAL', np.allclose(th1, -Ag ** 3 * np.eye(2))
      and np.allclose(th2, c2 @ np.kron(th1, th1))
      and all(np.allclose(left_inverse_curl_n(n, Ag) @ curl_n(n, Ag), np.eye(2 ** n)) for n in (1, 2)),
      'the computed curl: -A^3 on V1; on V1 (x) V1 it equals c^2 (theta (x) theta) (twist axiom); the curl with the '
      'inverse crossing and the cap on the other side is its inverse (n = 1, 2)')
control('thm:9:ribbon(inverse)', 'NUMERICAL', not np.allclose(left_inverse_curl_n(2, Ag, inverse=False) @ curl_n(2, Ag), np.eye(4)),
        'the curl with the cap on the other side but the same crossing is the inverse')
control('thm:9:ribbon(cable)', 'NUMERICAL', not np.allclose(th2, np.kron(th1, th1)),
        'the curl of V1 (x) V1 is theta (x) theta, without the double braiding')
ok = True
for n in range(2, 4):
    T_ = curl_n(n, Ag) @ ps[n - 1]
    ok &= np.allclose(T_, (-1) ** n * Ag ** (n * (n + 2)) * ps[n - 1])
check('eq:9:thetan(cable)', 'NUMERICAL', ok, 'the computed curl of the cable V1^{(x) n} on p_n is (-1)^n A^{n(n+2)} p_n, n = 2, 3')

# ================================================================ S9.5 roots of unity; the flip
ok = True
for k in range(1, 7):
    Ak = cmath.exp(1j * math.pi / (2 * (k + 2)))
    ok &= close(qint(k + 2, Ak ** 2), 0) and all(abs(qint(n + 1, Ak ** 2)) > 1e-9 for n in range(k + 1))
check('eq:9:trzero', 'NUMERICAL', ok, 'at A = e^{i pi/(2(k+2))}: [k+2]_q = 0, so tr p_{k+1} = 0, while [n+1]_q != 0 for n <= k '
      '(zero trace only; negligibility is KL Lemma 5)')
ok = True
for k in range(1, 7):
    Ak = cmath.exp(1j * math.pi / (2 * (k + 2)))
    for n in range(0, k + 1):
        j = n / 2
        dTL, thTL = (-1) ** n * qint(n + 1, Ak ** 2), (-1) ** n * Ak ** (n * (n + 2))
        ok &= close((-1) ** n * dTL, qint(2 * j + 1, Ak ** 2)) and qint(2 * j + 1, Ak ** 2).real > 0 \
            and close((-1) ** n * thTL, cmath.exp(2j * math.pi * j * (j + 1) / (k + 2)))
check('thm:9:sutk(flip)', 'NUMERICAL', ok,
      'the flip (-1)^n: d_j = [2j+1]_q > 0 and theta_j = e^{2 pi i j(j+1)/(k+2)}, k = 1..6, n = 2j')
# ex:9:k3fib -- at k = 3 the integer spins 0, 1 form Fibonacci: d_1 = [3]_q = phi, theta_1 = e^{4 pi i/5} (L7's chirality)
A3 = cmath.exp(1j * math.pi / 10)
phi_ = (1 + 5 ** 0.5) / 2
check('ex:9:k3fib', 'NUMERICAL', close(qint(3, A3 ** 2), phi_) and close(cmath.exp(2j * math.pi * 1 * 2 / 5), cmath.exp(4j * math.pi / 5)),
      'k = 3: d_1 = [3]_q = phi and theta_1 = e^{2 pi i 1 2/5} = e^{4 pi i/5}, the theta_tau of L7')
control('ex:9:k3fib', 'NUMERICAL', not close(qint(3, A3 ** 2), 2), 'd_1 at k = 3 is the classical dimension 2')
A1 = cmath.exp(1j * math.pi / 6)
check('ex:9:k1', 'NUMERICAL', close(-A1 ** 3, -1j) and close(A1 ** 3, 1j), 'k = 1: theta_1 = -A^3 = -i before the flip, +i after')
A2 = cmath.exp(1j * math.pi / 8)
check('ex:9:k2', 'NUMERICAL', close(cmath.exp(2j * math.pi * 0.5 * 1.5 / 4), cmath.exp(3j * math.pi / 8))
      and close(qint(2, A2 ** 2), math.sqrt(2)),
      'k = 2: d_{1/2} = sqrt 2, theta_{1/2} = e^{3 pi i/8}: Kitaev\'s nu = 3, the kappa = -1 category (not the course\'s Ising)')
# the other root -A flips theta_j for half-integer j
ok = all(close((-1) ** n * (-Ak) ** (n * (n + 2)) * (-1) ** n, (-1) ** n * cmath.exp(2j * math.pi * (n / 2) * (n / 2 + 1) / (k + 2)))
         for k in range(1, 5) for Ak in [cmath.exp(1j * math.pi / (2 * (k + 2)))] for n in range(0, k + 1))
check('rem:9:minusA', 'NUMERICAL', ok, 'replacing A by -A multiplies theta_j by (-1)^{2j}')
# the trap: p_3 exists at delta = 0 (TL_3 basis 1, U1, U2, U1U2, U2U1), though the recursion needs [2] != 0


def tl3_mul(x, y, dlt):
    words = ['', '1', '2', '12', '21']

    def red(w):
        coef, out = 1, ''
        for ch in w:
            if out and out[-1] == ch:
                coef *= dlt
            else:
                out += ch
        while len(out) >= 3:
            out = out[:-2] if out[-3] == out[-1] else out
        return coef, out
    z = [0] * 5
    for i, wi in enumerate(words):
        for j, wj in enumerate(words):
            if x[i] and y[j]:
                cf, w = red(wi + wj)
                z[words.index(w)] += x[i] * y[j] * cf
    return z


p3 = [1, 0, 0, -1, -1]
U1w, U2w = [0, 1, 0, 0, 0], [0, 0, 1, 0, 0]
check('rem:9:jwtrap', 'EXACT', tl3_mul(p3, p3, 0) == p3 and tl3_mul(U1w, p3, 0) == [0] * 5 and tl3_mul(U2w, p3, 0) == [0] * 5,
      'at delta = 0 (where the recursion fails at p_2), p_3 = 1 - U1U2 - U2U1 is idempotent and killed by U1, U2')
control('rem:9:jwtrap', 'EXACT', tl3_mul([1, -1, -1, 0, 0], [1, -1, -1, 0, 0], 0) != [1, -1, -1, 0, 0],
        'at delta = 0 the naive 1 - U1 - U2 is idempotent')

print()
if FAILS:
    print(f'{len(FAILS)} FAILED: ' + ', '.join(FAILS))
    sys.exit(1)
print('All L9 checks pass.')
