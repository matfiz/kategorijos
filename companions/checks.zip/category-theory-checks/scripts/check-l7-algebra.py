"""Algebra script for Lecture 7, *Braiding: hexagons, Yang-Baxter and topological spin*.

Every formula and number that lectures/lec07.tex prints is checked here, on instances,
labelled SYMBOLIC, EXACT or NUMERICAL, most with a control that must fail.  Conventions:
Bible K2 (the braiding c_{X,Y}: X (x) Y -> Y (x) X drawn /-over), K13 (F), K14 (R-symbols
c_{a,b} psi^{ab}_c = R^{ab}_c psi^{ba}_c, the hexagons B2.57-B2.58, the spin
theta_a = d_a^{-1} sum_c N_{aa}^c d_c R^{aa}_c, the ribbon relation), K18 (B_q), K10
(Ising nu, kappa).  Pictures are checked by rendering, not here.

Run:  python3 scripts/check-l7-algebra.py     (exit status 1 on failure)
"""
import cmath
import itertools
import math
import pathlib
import sys

import numpy as np
import sympy as sp

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import anyons  # noqa: E402

FAILS = []


def check(label, kind, ok, what):
    print(f"{'OK  ' if ok else 'FAIL'} [{kind:9s}] {label}: {what}")
    if not ok:
        FAILS.append(label)


def control(label, kind, failed, what):
    check(label + ' (control)', kind, failed, what + ' -- must fail, and does')


def K(*ms):
    out = np.eye(1)
    for m in ms:
        out = np.kron(out, m)
    return out


phi = (1 + sp.sqrt(5)) / 2

# ================================================================ S7.3 YBE = RIII
# the braid relation c1 c2 c1 = c2 c1 c2 on V^{(x)3}, c1 = c (x) id, c2 = id (x) c
def braid_rel(c, n):
    I = np.eye(n)
    c1, c2 = K(c, I), K(I, c)
    return np.allclose(c1 @ c2 @ c1, c2 @ c1 @ c2)


n = 2
P = np.eye(n * n)[[i * n + j for j in range(n) for i in range(n)]]     # the flip v (x) w -> w (x) v
check('ex:7:flip', 'NUMERICAL', braid_rel(P, 2) and np.allclose(P @ P, np.eye(4)),
      'the flip of Vect satisfies the braid relation and squares to 1 (symmetric)')
q = 1.3 + 0.4j
Bq = np.array([[q, 0, 0, 0], [0, q - 1 / q, 1, 0], [0, 1, 0, 0], [0, 0, 0, q]])   # K18
check('ex:7:Bq', 'NUMERICAL', braid_rel(Bq, 2) and not np.allclose(Bq @ Bq, np.eye(4)),
      'K18\'s B_q (generic q) satisfies the braid relation and does not square to 1')
Aq = np.sqrt(q + 0j)
vq = np.array([0, 1, -q, 0]).reshape(4, 1)
cq = Bq / Aq
check('ex:7:Bq(scale)', 'NUMERICAL', np.allclose(K(cq, np.eye(2)) @ K(np.eye(2), cq) @ K(vq, np.eye(2)), K(np.eye(2), vq))
      and np.allclose(K(Bq, np.eye(2)) @ K(np.eye(2), Bq) @ K(vq, np.eye(2)), q * K(np.eye(2), vq)),
      'the braiding is A^{-1} B_q: it passes the cup, c1 c2 (v (x) 1) = 1 (x) v; B_q gives q (1 (x) v)')
# the trap: R = P c satisfies R12 R13 R23 = R23 R13 R12 iff c = P R satisfies the braid relation
R = P @ Bq
I2 = np.eye(2)
P23 = K(I2, P)
R12, R23 = K(R, I2), K(I2, R)
R13 = P23 @ R12 @ P23
check('rem:7:ybeforms', 'NUMERICAL', np.allclose(R12 @ R13 @ R23, R23 @ R13 @ R12),
      'R = P B_q satisfies R12 R13 R23 = R23 R13 R12 (Integrability\'s form)')
control('rem:7:ybeforms', 'NUMERICAL', not np.allclose(R12 @ R23 @ R12, R23 @ R12 @ R23),
        'R itself (not c = P R) satisfies the braid form R12 R23 R12 = R23 R12 R23')
rng = np.random.default_rng(7)
cbad = Bq + 0.1 * rng.standard_normal((4, 4))
control('ex:7:Bq', 'NUMERICAL', not braid_rel(cbad, 2), 'a perturbed B_q still satisfies the braid relation')


# Local leg convention: R_12 = R tensor id, R_23 = id tensor R, and
# R_13 = P_23 (R tensor id) P_23. Check every basis vector with a generic exact R.
R_entries = sp.symbols('r0:16')
R_exact = sp.Matrix(4, 4, R_entries)
P_exact = sp.eye(4)[:, [0, 2, 1, 3]]
P23_exact = sp.kronecker_product(sp.eye(2), P_exact)
R13_exact = P23_exact * sp.kronecker_product(R_exact, sp.eye(2)) * P23_exact
R13_direct = sp.zeros(8)
for i, j, k in itertools.product(range(2), repeat=3):
    for u, v in itertools.product(range(2), repeat=2):
        R13_direct[4 * u + 2 * j + v, 4 * i + 2 * j + k] = R_exact[2 * u + v, 2 * i + k]
check('rem:7:ybeforms(legs)', 'EXACT', R13_exact == R13_direct,
      'R_13 acts by R on ordered factors 1 and 3 and leaves factor 2 fixed')
control('rem:7:ybeforms(legs)', 'EXACT', sp.kronecker_product(R_exact, sp.eye(2)) != R13_direct,
        'R tensor id acts on factors 1 and 3 without the flips')
# ================================================================ S7.4 R-symbols; Fibonacci solved
def fib_data(R1, Rt):
    F = sp.Matrix([[1 / phi, 1 / sp.sqrt(phi)], [1 / sp.sqrt(phi), -1 / phi]])
    L = ['1', 't']

    def N(x, y, z):
        if x == '1':
            return y == z
        if y == '1':
            return x == z
        return True

    def Fs(a, b, c, d, e, f):
        if not (N(a, b, e) and N(e, c, d) and N(b, c, f) and N(a, f, d)):
            return 0
        if '1' in (a, b, c) or d == '1':
            return 1
        return F['1t'.index(e), '1t'.index(f)]

    def Rs(a, b, c):
        if not N(a, b, c):
            return 0
        if '1' in (a, b):
            return 1
        return {'1': R1, 't': Rt}[c]
    return L, Fs, Rs


def hexagon(L, Fs, Rs, a, b, c, d, e, g):
    """K14's first hexagon at (a,b,c,d,e,g): lhs - rhs."""
    lhs = Rs(c, a, e) * Fs(a, c, b, d, e, g) * Rs(c, b, g)
    rhs = sum(Fs(c, a, b, d, e, f) * Rs(c, f, d) * Fs(a, b, c, d, f, g) for f in L)
    return sp.simplify(lhs - rhs)


R1, Rt = sp.symbols('R1 Rt')
L, Fs, Rs = fib_data(R1, Rt)
eqs = {hexagon(L, Fs, Rs, *t) for t in itertools.product(L, repeat=6)} - {0}
sols = sp.solve(list(eqs), [R1, Rt], dict=True)
w = lambda k: sp.exp(sp.pi * sp.I * k / 5)                       # noqa: E731
target = [(w(-4), w(3)), (w(4), w(-3))]
got = [(complex(s[R1]), complex(s[Rt])) for s in sols]
check('thm:7:fibR', 'SYMBOLIC', len(sols) == 2 and all(any(abs(g[0] - complex(t[0])) < 1e-12 and abs(g[1] - complex(t[1])) < 1e-12
                                                         for g in got) for t in target),
      'the first hexagon has exactly two solutions: (R_1, R_tau) = (e^{-4 pi i/5}, e^{3 pi i/5}) and the conjugate')
# the two instances printed: (t,t,t,1,t,t): R_tau^2 = R_1; (t,t,t,t,t,t): R_tau^2 + R_tau/phi + 1 = 0
e1 = hexagon(L, Fs, Rs, 't', 't', 't', '1', 't', 't')
e2 = hexagon(L, Fs, Rs, 't', 't', 't', 't', 't', 't')
check('eq:7:fibhex1', 'SYMBOLIC', sp.simplify(e1 - (Rt ** 2 - R1)) == 0, 'd = 1 instance: R_tau^2 = R_1')
check('eq:7:fibhex2', 'SYMBOLIC', sp.simplify(sp.expand(e2 * (-phi)) - sp.expand(Rt ** 2 + Rt / phi + 1)) == 0,
      'all-tau instance: -R_tau^2/phi = 1/phi + R_tau/phi^2, i.e. R_tau^2 + R_tau/phi + 1 = 0')
check('eq:7:fibroots', 'SYMBOLIC', sp.simplify(2 * sp.cos(3 * sp.pi / 5) + 1 / phi) == 0
      and all(abs(complex(w(k) ** 2 + w(k) / phi + 1)) < 1e-12 for k in (3, -3))
      and all(abs(complex(w(k) ** 2 - w(-4 if k == 3 else 4))) < 1e-12 for k in (3, -3)),
      'its roots are e^{+-3 pi i/5}, since 2 cos(3 pi/5) = -1/phi; then R_1 = R_tau^2 = e^{-+4 pi i/5}')
# both solutions satisfy the second hexagon too (anyons.py, both chiralities)
check('thm:7:hexagonFR', 'NUMERICAL', all(anyons.fibonacci(ch).hexagon_defect() < 1e-10 for ch in (1, -1)),
      'Fibonacci with either chirality satisfies both hexagons')
bad = anyons.fibonacci()
bad._R = lambda a, b, c: {('t', 't', '1'): cmath.exp(4j * math.pi / 5), ('t', 't', 't'): cmath.exp(3j * math.pi / 5)}[(a, b, c)]
control('thm:7:hexagonFR', 'NUMERICAL', bad.hexagon_defect() > 1e-3, 'Fibonacci with only R_1 conjugated satisfies the hexagons')

# ================================================================ S7.5 topological spin
th_t = (1 * w(-4) + phi * w(3)) / phi
check('thm:7:spin(fib)', 'SYMBOLIC', abs(complex(th_t) - complex(w(4))) < 1e-12,
      'theta_tau = (R_1 + phi R_tau)/phi = e^{4 pi i/5}')
fib, isi = anyons.fibonacci(), anyons.ising(1)
check('thm:7:spin(ising)', 'NUMERICAL', abs(isi.theta('s') - cmath.exp(1j * math.pi / 8)) < 1e-12
      and abs(isi.theta('p') + 1) < 1e-12, 'Ising nu = 1: theta_sigma = e^{i pi/8}, theta_psi = -1')
check('thm:7:ribbon', 'NUMERICAL', fib.ribbon_defect() < 1e-10 and isi.ribbon_defect() < 1e-10,
      'R^{ab}_c R^{ba}_c = theta_c/(theta_a theta_b) for Fibonacci and Ising')
check('thm:7:spin(two ways)', 'NUMERICAL', fib.theta_two_ways_defect() < 1e-10 and isi.theta_two_ways_defect() < 1e-10,
      'theta_a = kappa_a (R^{abar a}_1)^*')
control('thm:7:spin(fib)', 'SYMBOLIC', abs(complex((w(-4) + w(3)) / 2) - complex(w(4))) > 1e-3,
        'theta_tau is the plain average (R_1 + R_tau)/2, without the dimensions')

# ================================================================ S7.6 pointed Z2 and Ising
# the hexagon for Vec_Z2^omega at a = b = c = d = s, e = g = 1: c^2 omega = omega^2, so c^2 = omega
cc, om = sp.symbols('c omega', nonzero=True)
Lz = ['1', 's']
Nz = lambda x, y, z: (x == '1' and y == z) or (y == '1' and x == z) or (x == y == 's' and z == '1')   # noqa: E731
Fz = lambda a, b, c, d, e, f: (0 if not (Nz(a, b, e) and Nz(e, c, d) and Nz(b, c, f) and Nz(a, f, d))  # noqa: E731
                               else om if (a, b, c) == ('s', 's', 's') else 1)
Rz = lambda a, b, c: (0 if not Nz(a, b, c) else cc if (a, b) == ('s', 's') else 1)                      # noqa: E731
inst = hexagon(Lz, Fz, Rz, 's', 's', 's', 's', '1', '1')
allz = {sp.factor(hexagon(Lz, Fz, Rz, *t)) for t in itertools.product(Lz, repeat=6)} - {0}


def hexagon2(L, Fs, Rs, a, b, c, d, e, g):
    """K14's second hexagon at (a,b,c,d,e,g): lhs - rhs (inverted crossings exchange their labels)."""
    inv_ = lambda z: 0 if z == 0 else sp.Integer(1) / z          # noqa: E731
    lhs = inv_(Rs(a, c, e)) * Fs(a, c, b, d, e, g) * inv_(Rs(b, c, g))
    rhs = sum(Fs(c, a, b, d, e, f) * inv_(Rs(f, c, d)) * Fs(a, b, c, d, f, g) for f in L)
    return sp.simplify(lhs - rhs)


allz2 = {sp.factor(hexagon2(Lz, Fz, Rz, *t)) for t in itertools.product(Lz, repeat=6)} - {0}
sols4 = [(1, 1), (1, -1), (-1, sp.I), (-1, -sp.I)]
both = lambda o, c_: all(sp.simplify(e_.subs({om: o, cc: c_})) == 0 for e_ in allz | allz2)   # noqa: E731
check('thm:7:pointed', 'SYMBOLIC', sp.simplify(inst - (cc ** 2 * om - om ** 2)) == 0 and len(allz2) > 0
      and all(both(o, c_) for o, c_ in sols4),
      'the instance (s,s,s,s,1,1) reads c^2 omega = omega^2; the four (omega, c) with c^2 = omega = +-1 solve both families')
# the second family can fail: on a gauged Ising with non-symmetric R, the printed family holds and the
# label-swapped pattern (Bonderson's (2.78)-(2.79) read literally) does not (C.3 L7 r2, Opus)
Mns = anyons.ising(1).gauged({('s', 'p', 's'): 1j})
check('thm:7:hexagonFR(second family)', 'NUMERICAL', abs(Mns.R('s', 'p', 's') - Mns.R('p', 's', 's')) > 1e-3
      and Mns.hexagon_defect() < 1e-10, 'on a gauged Ising with R^{sp} != R^{ps}, both printed families hold')
control('thm:7:hexagonFR(second family)', 'NUMERICAL', Mns.hexagon_defect(swapped=True) > 1e-3,
        'the second family with its labels unswapped also holds there')
control('thm:7:pointed', 'SYMBOLIC', not both(1, sp.I) and not both(-1, 1),
        '(omega, c) = (1, i) or (-1, 1) solves both families')
ok = all(anyons.pointed_z2(o, c_).hexagon_defect() < 1e-12 for o, cs in ((1, (1, -1)), (-1, (1j, -1j))) for c_ in cs)
check('thm:7:pointed(four)', 'NUMERICAL', ok, 'omega = 1: c = +-1 (boson, fermion); omega = -1: c = +-i (semion, antisemion)')
control('thm:7:pointed(four)', 'NUMERICAL', anyons.pointed_z2(-1, 1).hexagon_defect() > 1e-3
        and anyons.pointed_z2(1, 1j).hexagon_defect() > 1e-3, 'c = 1 on the semion data, or c = i on the trivial omega, is a braiding')
th = {name: anyons.pointed_z2(o, c_).theta('s') for name, o, c_ in
      (('boson', 1, 1), ('fermion', 1, -1), ('semion', -1, 1j), ('antisemion', -1, -1j))}
check('ex:7:pointedspins', 'NUMERICAL', np.allclose([th['boson'], th['fermion'], th['semion'], th['antisemion']], [1, -1, 1j, -1j]),
      'theta_s = c(s,s): 1, -1, i, -i')
dbl = {name: anyons.pointed_z2(o, c_).R('s', 's', '1') ** 2 for name, o, c_ in
       (('boson', 1, 1), ('fermion', 1, -1), ('semion', -1, 1j))}
check('def:7:symmetric', 'NUMERICAL', abs(dbl['boson'] - 1) < 1e-12 and abs(dbl['fermion'] - 1) < 1e-12
      and abs(dbl['semion'] - 1) > 1, 'the double braiding R^{ss}_1 R^{ss}_1 is 1 for boson and fermion (symmetric), -1 for the semion')
# Z5: five quadratic forms q_k(x) = zeta^{k x^2}, three classes under Aut(Z5) = units (k -> k u^2)
classes = {frozenset((k * u * u) % 5 for u in (1, 2, 3, 4)) for k in range(5)}
check('rem:7:z5', 'EXACT', len(classes) == 3, 'Z5: 5 quadratic forms, 3 classes up to Aut(Z5) ({0}, {1,4}, {2,3})')
# Ising: kappa_sigma = (-1)^{(nu^2-1)/8}; nu in {1,7,9,15} have kappa = +1, {3,5,11,13} have -1
kap = {nu: (-1) ** ((nu * nu - 1) // 8) for nu in range(1, 16, 2)}
check('thm:7:ising(kappa)', 'EXACT', [nu for nu in kap if kap[nu] == 1] == [1, 7, 9, 15]
      and [nu for nu in kap if kap[nu] == -1] == [3, 5, 11, 13], 'kappa = +1 for nu = 1, 7, 9, 15; -1 for 3, 5, 11, 13')
check('thm:7:ising(hexagons)', 'NUMERICAL', all(anyons.ising(nu).hexagon_defect() < 1e-10 for nu in range(1, 16, 2)),
      'Kitaev\'s Table 1 data solve the hexagons for every odd nu, with its kappa')
control('thm:7:ising(hexagons)', 'NUMERICAL', all(anyons.ising(nu, kappa=-kap[nu]).hexagon_defect() > 1e-3 for nu in range(1, 16, 2)),
        'some nu solves the hexagons on the other Ising category')
check('thm:7:ising(theta)', 'NUMERICAL', all(abs(anyons.ising(nu).theta('s') - cmath.exp(1j * math.pi * nu / 8)) < 1e-10
                                            for nu in range(1, 16, 2)), 'theta_sigma = e^{i pi nu/8}')

# ================================================================ the B_3 action on three taus (Sheet 7 seed)
F = np.array([[1 / float(phi), float(phi) ** -0.5], [float(phi) ** -0.5, -1 / float(phi)]])
D = np.diag([complex(w(-4)), complex(w(3))])
s1, s2 = D, F @ D @ F
check('ex:7:b3', 'NUMERICAL', np.allclose(s1 @ s2 @ s1, s2 @ s1 @ s2) and np.allclose(s1 @ s1.conj().T, np.eye(2)),
      'on V^{ttt}_t, sigma_1 = diag(R) and sigma_2 = F diag(R) F satisfy the braid relation and are unitary')
s2bad = F @ D.conj() @ F
control('ex:7:b3', 'NUMERICAL', not np.allclose(s1 @ s2bad @ s1, s2bad @ s1 @ s2bad),
        'mixing the chiralities, sigma_2 = F diag(R)^* F, satisfies the braid relation with sigma_1')

# ex:7:isingspin -- theta_sigma from Kitaev's Table 1 R-symbols: (R^{ss}_1 + R^{ss}_psi)/sqrt2 = e^{i pi nu/8}
ok = True
for nu_v in range(1, 16, 2):
    kv = (-1) ** ((nu_v * nu_v - 1) // 8)
    r1, rp = kv * sp.exp(-sp.I * sp.pi * nu_v / 8), kv * sp.exp(3 * sp.I * sp.pi * nu_v / 8)
    th_s = (r1 + rp) / sp.sqrt(2)
    ok &= abs(complex(th_s - sp.exp(sp.I * sp.pi * nu_v / 8))) < 1e-12
check('ex:7:isingspin', 'SYMBOLIC', ok, 'theta_sigma = (R^{ss}_1 + R^{ss}_psi)/sqrt2 = e^{i pi nu/8} with Kitaev\'s R, every odd nu')
r1_1, rp_1 = sp.exp(-sp.I * sp.pi / 8), sp.exp(3 * sp.I * sp.pi / 8)
check('ex:7:isingspin(nu=1)', 'SYMBOLIC', abs(complex((r1_1 + rp_1) / sp.sqrt(2) - sp.exp(sp.I * sp.pi / 8))) < 1e-14
      and abs(complex(r1_1 + rp_1 - 2 * sp.cos(sp.pi / 4) * sp.exp(sp.I * sp.pi / 8))) < 1e-14,
      'nu = 1: e^{-i pi/8} + e^{3 i pi/8} = e^{i pi/8} 2 cos(pi/4), so theta_sigma = e^{i pi/8}')
# The quadratic-form definition used by the cited pointed classification.
# For Z5 encode roots of unity by their exponents modulo 5, so this is exact.
q5 = lambda k, x: (k * x * x) % 5
b5 = lambda k, x, y: (q5(k, x + y) - q5(k, x) - q5(k, y)) % 5
check('pointed:7:quadratic form', 'EXACT',
      all(q5(k, -x) == q5(k, x)
          and b5(k, x + y, z) == (b5(k, x, z) + b5(k, y, z)) % 5
          and b5(k, x, y + z) == (b5(k, x, y) + b5(k, x, z)) % 5
          for k, x, y, z in itertools.product(range(5), repeat=4)),
      'all five printed Z5 functions are even and their polarisation is multiplicative in each argument')
control('pointed:7:quadratic form', 'EXACT', any((-x) % 5 != x for x in range(5)),
        'the nontrivial linear character q(x)=exp(2pi i x/5) is a quadratic form')
# Exact certificate for the nu = 1 spin computation relocated after the printed R-data.
spin_sum_exact = sp.simplify(sp.expand_complex(r1_1 + rp_1))
spin_target_exact = sp.simplify(sp.expand_complex(sp.sqrt(2) * sp.exp(sp.I * sp.pi / 8)))
check('ex:7:isingspin(nu=1 exact)', 'EXACT',
      sp.to_number_field(spin_sum_exact - spin_target_exact).as_expr() == 0,
      'e^{-i pi/8} + e^{3i pi/8} = sqrt(2) e^{i pi/8}, exactly in radicals')
control('ex:7:isingspin(nu=1 exact)', 'EXACT',
        sp.to_number_field(sp.expand_complex(r1_1 - rp_1) - spin_target_exact).as_expr() != 0,
        'a minus between the two Ising R-symbols gives the same spin')
# the double braiding R^{ab}_c R^{ba}_c is gauge invariant: factor (u^{ba}/u^{ab})(u^{ab}/u^{ba}) = 1
uab, uba = sp.symbols('u_ab u_ba', nonzero=True)
Mg7 = anyons.toric_code().gauged({('e', 'm', 'x'): 1j})
check('rem:7:double', 'NUMERICAL', abs(Mg7.R('e', 'm', 'x') * Mg7.R('m', 'e', 'x') - (-1)) < 1e-12
      and abs(Mg7.R('e', 'm', 'x') - anyons.toric_code().R('e', 'm', 'x')) > 1e-3,
      'a gauge u^{em} = i changes R^{em} but not the double braiding R^{em} R^{me} = -1')
# the semion and fermion spins from the spin formula with d = 1: theta_s = R^{ss}_1 = c
check('ex:7:semionspin', 'NUMERICAL', abs(anyons.pointed_z2(-1, 1j).theta('s') - 1j) < 1e-12
      and abs(anyons.pointed_z2(1, -1).theta('s') + 1) < 1e-12, 'semion theta = i, fermion theta = -1')
# rem:7:mueger -- in Fibonacci, R^{tt}_c R^{tt}_c != 1 for both channels, so tau is not transparent
check('rem:7:mueger', 'NUMERICAL', all(abs(fib.R('t', 't', c_) * fib.R('t', 't', c_) - 1) > 1e-3 for c_ in ('1', 't'))
      and all(abs(anyons.pointed_z2(1, c_).R('s', 's', '1') ** 2 - 1) < 1e-12 for c_ in (1, -1)),
      'Fibonacci: the double braiding of tau with tau is e^{-8 pi i/5} or e^{6 pi i/5}, never 1; sVec: always 1')
# the toric code (QC L14): e and m have trivial spin, mutual double braiding -1
tc = anyons.toric_code()
check('ex:7:toric', 'NUMERICAL', abs(tc.theta('e') - 1) < 1e-12 and abs(tc.theta('m') - 1) < 1e-12
      and abs(tc.theta('x') + 1) < 1e-12 and abs(tc.R('e', 'm', 'x') * tc.R('m', 'e', 'x') + 1) < 1e-12,
      'toric code: theta_e = theta_m = 1, theta_eps = -1, R^{em} R^{me} = -1')

print()
if FAILS:
    print(f'{len(FAILS)} FAILED: ' + ', '.join(FAILS))
    sys.exit(1)
print('All L7 checks pass.')
