"""Algebra script for Lecture 5, *Fusion categories: particles and how they fuse*.

This script checks, on instances, the fusion rules, ring identities, FP dimensions, vertex
normalisations and fusion-space counts that lectures/lec05.tex prints, labelled SYMBOLIC,
EXACT or NUMERICAL, most with a control that must fail.  The diagram equations are checked
as matrix identities in Rep(S3) (the bubble and theta there hold by the construction of the
vertices; completeness and the cup are genuine tests); pictures, flags and orientations are
checked by rendering, not here.  Not checked here: the cited results (unitary =>
pseudo-unitary, the canonical spherical structure, D8/Q8) and the imported pivotal example
Vec_Z2 with a_s = -id (checked in check-l4-algebra.py, ex:4:negdim).  Fusion rules are given as N[a][b][c] = N_{ab}^c (Bible K5 symbol
table); duals by a -> a*.  Vertices use the isotopy-invariant normalisation of Bible K5:
    bubble        psi^{ab dag}_c psi^{ab}_{c'} = delta_{cc'} sqrt(d_a d_b / d_c) id_c,
    completeness  id_a (x) id_b = sum_c sqrt(d_c / (d_a d_b)) psi^{ab}_c psi^{ab dag}_c,
checked in Rep(S3), where vertices are scaled isometric intertwiners.

Run:  python3 scripts/check-l5-algebra.py     (exit status 1 on failure)
"""
import itertools
import sys

import numpy as np
import sympy as sp

FAILS = []


def check(label, kind, ok, what):
    print(f"{'OK  ' if ok else 'FAIL'} [{kind:9s}] {label}: {what}")
    if not ok:
        FAILS.append(label)


def control(label, kind, failed, what):
    check(label + ' (control)', kind, failed, what + ' -- must fail, and does')


def close(a, b, tol=1e-9):
    return np.allclose(a, b, atol=tol, rtol=0)


# ---------------------------------------------------------------- the fusion rings
phi = (1 + sp.sqrt(5)) / 2


def ring_fib():
    L = ['1', 't']
    N = {a: {b: {c: 0 for c in L} for b in L} for a in L}
    for a in L:
        N['1'][a][a] = N[a]['1'][a] = 1
    N['t']['t']['1'] = N['t']['t']['t'] = 1
    return L, N, {'1': '1', 't': 't'}


def ring_ising():
    L = ['1', 's', 'p']
    N = {a: {b: {c: 0 for c in L} for b in L} for a in L}
    for a in L:
        N['1'][a][a] = N[a]['1'][a] = 1
    N['s']['s']['1'] = N['s']['s']['p'] = 1
    N['s']['p']['s'] = N['p']['s']['s'] = 1
    N['p']['p']['1'] = 1
    return L, N, {a: a for a in L}


def ring_su2(k):
    L = [sp.Rational(n, 2) for n in range(k + 1)]
    N = {a: {b: {c: 0 for c in L} for b in L} for a in L}
    for a, b in itertools.product(L, repeat=2):
        j = abs(a - b)
        while j <= min(a + b, k - a - b):
            N[a][b][j] = 1
            j += 1
    return L, N, {a: a for a in L}


def ring_group(G, mul, inv):
    N = {a: {b: {c: int(mul(a, b) == c) for c in G} for b in G} for a in G}
    return list(G), N, {g: inv(g) for g in G}


def ring_s3():
    L = ['1', 'sgn', 'std']
    N = {a: {b: {c: 0 for c in L} for b in L} for a in L}
    for a in L:
        N['1'][a][a] = N[a]['1'][a] = 1
    N['sgn']['sgn']['1'] = 1
    N['sgn']['std']['std'] = N['std']['sgn']['std'] = 1
    N['std']['std']['1'] = N['std']['std']['sgn'] = N['std']['std']['std'] = 1
    return L, N, {a: a for a in L}


def associative(L, N):
    for a, b, c, e in itertools.product(L, repeat=4):
        lhs = sum(N[a][b][x] * N[x][c][e] for x in L)
        rhs = sum(N[b][c][y] * N[a][y][e] for y in L)
        if lhs != rhs:
            return False
    return True


def rigidity(L, N, dual):
    unit = L[0]
    ok = all(N[a][b][c] == N[b][dual[c]][dual[a]] for a, b, c in itertools.product(L, repeat=3))
    ok &= all(N[a][b][unit] == int(b == dual[a]) for a, b in itertools.product(L, repeat=2))
    ok &= all(N[unit][a][b] == int(a == b) for a, b in itertools.product(L, repeat=2))
    return ok


def reversal(L, N, dual):
    """N_{ab}^c = N_{b*a*}^{c*}, from (a (x) b)* = b* (x) a* (prop:4:tensordual)."""
    return all(N[a][b][c] == N[dual[b]][dual[a]][dual[c]] for a, b, c in itertools.product(L, repeat=3))


Z3 = [0, 1, 2]
rings = {'Fibonacci': ring_fib(), 'Ising': ring_ising(), 'Rep(S3)': ring_s3(),
         'Vec_Z3': ring_group(Z3, lambda a, b: (a + b) % 3, lambda a: (-a) % 3),
         'SU(2)_2': ring_su2(2), 'SU(2)_3': ring_su2(3), 'SU(2)_4': ring_su2(4)}
for name, (L, N, dual) in rings.items():
    check(f'thm:5:fusionring({name})', 'EXACT', associative(L, N) and rigidity(L, N, dual),
          'associative, unit 1, N_{ab}^1 = delta_{b,a*}, N_{ab}^c = N_{bc*}^{a*}')
# control: a ring that violates the rigidity symmetry (tau (x) tau = tau only, no unit channel)
Lf, Nf, df = ring_fib()
Nbad = {a: {b: dict(Nf[a][b]) for b in Lf} for a in Lf}
Nbad['t']['t']['1'] = 0
control('thm:5:fusionring', 'EXACT', not rigidity(Lf, Nbad, df), 'tau (x) tau = tau alone satisfies N_{ab}^1 = delta')
# Rep(S3) from characters: N_{ab}^c = <chi_a chi_b, chi_c>
cls = [1, 3, 2]                                            # class sizes: e, transpositions, 3-cycles
chi = {'1': [1, 1, 1], 'sgn': [1, -1, 1], 'std': [2, 0, -1]}
Ls3, Ns3, _ = ring_s3()
ok = all(sum(c * chi[a][i] * chi[b][i] * chi[cc][i] for i, c in enumerate(cls)) == 6 * Ns3[a][b][cc]
         for a, b, cc in itertools.product(Ls3, repeat=3))
check('ex:5:reps3', 'EXACT', ok, 'Rep(S3) fusion from characters: std (x) std = 1 + sgn + std')

# thm:5:fusionring, the third identity: N_{ab}^c = N_{b*a*}^{c*} in every ring (Vec_S3 included)
check('thm:5:fusionring(reversal)', 'EXACT', all(reversal(L_, N_, d_) for (L_, N_, d_) in
                                                  list(rings.values()) + [ring_group(list(itertools.permutations(range(3))),
                                                  lambda g, h: tuple(g[h[i]] for i in range(3)),
                                                  lambda g: tuple(sorted(range(3), key=lambda i: g[i])))]),
      'N_{ab}^c = N_{b*a*}^{c*} in all the rings, Vec_S3 included')
# control (Opus, C.3 L5 r1): Z[x]/(x^3 - x - 1), basis 1, x, x^2, x* = x^2, satisfies the old properties
# but not the reversal, so it is not a fusion ring
Lc = ['1', 'x', 'y']                                           # y = x^2
Nc = {a_: {b_: {c_: 0 for c_ in Lc} for b_ in Lc} for a_ in Lc}
for a_ in Lc:
    Nc['1'][a_][a_] = Nc[a_]['1'][a_] = 1
Nc['x']['x']['y'] = 1                                          # x x = x^2
Nc['x']['y']['1'] = Nc['x']['y']['x'] = 1                      # x x^2 = x^3 = 1 + x
Nc['y']['x']['1'] = Nc['y']['x']['x'] = 1
Nc['y']['y']['x'] = Nc['y']['y']['y'] = 1                      # x^4 = x + x^2
dc = {'1': '1', 'x': 'y', 'y': 'x'}
check('thm:5:fusionring(x^3 = x + 1 model)', 'EXACT', associative(Lc, Nc) and rigidity(Lc, Nc, dc),
      'Z[x]/(x^3 - x - 1) with x* = x^2 is associative and has the first two identities')
control('thm:5:fusionring(reversal)', 'EXACT', not reversal(Lc, Nc, dc),
        'Z[x]/(x^3 - x - 1) also has N_{ab}^c = N_{b*a*}^{c*}')

# control: Ising with N_{psi sigma}^sigma set to 0 keeps N^1 = delta; the table is then neither
# associative nor cyclic (no cyclic-only control exists: for an associative table with N^1 = delta and
# an involution *, the cyclic identity follows -- C.3 L5 r2, Opus)
Li0, Ni0, di0 = ring_ising()
Ncyc = {a_: {b_: dict(Ni0[a_][b_]) for b_ in Li0} for a_ in Li0}
Ncyc['p']['s']['s'] = 0
control('thm:5:fusionring(cyclic)', 'EXACT', not rigidity(Li0, Ncyc, di0)
        and all(Ncyc[a_][b_]['1'] == int(b_ == di0[a_]) for a_ in Li0 for b_ in Li0),
        'a table with the right N^1 but N_{psi sigma}^sigma = 0 passes rigidity()')
# rem:5:kitaev -- the unit-norm vertex is (d_c/(d_a d_b))^{1/4} psi: its norm is 1 given the bubble
da_, db_, dc_ = sp.symbols('d_a d_b d_c', positive=True)
check('rem:5:kitaev', 'SYMBOLIC', sp.simplify(((dc_ / (da_ * db_)) ** sp.Rational(1, 4)) ** 2 * sp.sqrt(da_ * db_ / dc_) - 1) == 0,
      '((d_c/d_a d_b)^{1/4})^2 sqrt(d_a d_b/d_c) = 1: the conversion factor per vertex')

# ex:5:assoc -- (tau (x) tau) (x) tau = 1 + 2 tau = tau (x) (tau (x) tau)
Lf, Nf, _ = ring_fib()
left = {c: sum(Nf['t']['t'][x] * Nf[x]['t'][c] for x in Lf) for c in Lf}
right = {c: sum(Nf['t']['t'][y] * Nf['t'][y][c] for y in Lf) for c in Lf}
check('ex:5:assoc', 'EXACT', left == right == {'1': 1, 't': 2}, '(tau tau) tau = 1 + 2 tau = tau (tau tau)')
# ex:5:isingmatrix -- N_sigma in the basis 1, sigma, psi
Li, Ni, _ = ring_ising()
Ns = [[Ni['s'][b_][c] for b_ in Li] for c in Li]
check('ex:5:isingmatrix', 'EXACT', Ns == [[0, 1, 0], [1, 0, 1], [0, 1, 0]], 'N_sigma = [[0,1,0],[1,0,1],[0,1,0]]')
# ex:5:su2-2 -- SU(2)_2 has the Ising fusion ring under 0, 1/2, 1 -> 1, sigma, psi
L2_, N2_, _ = ring_su2(2)
m = {L2_[0]: '1', L2_[1]: 's', L2_[2]: 'p'}
check('ex:5:su2-2', 'EXACT', all(N2_[a_][b_][c] == Ni[m[a_]][m[b_]][m[c]] for a_ in L2_ for b_ in L2_ for c in L2_),
      'SU(2)_2 fusion = Ising fusion under j = 0, 1/2, 1 -> 1, sigma, psi')
# ex:5:su2-3 -- SU(2)_3: 1 (x) 1 = 0 + 1 (a Fibonacci subring); d_{1/2} = d_1 = phi
L3_, N3_, _ = ring_su2(3)
one = sp.Integer(1)
check('ex:5:su2-3', 'EXACT', {c: N3_[one][one][c] for c in L3_} == {0: 1, sp.Rational(1, 2): 0, 1: 1, sp.Rational(3, 2): 0},
      'in SU(2)_3, 1 (x) 1 = 0 + 1: the objects 0, 1 fuse like Fibonacci')

# rem:5:matrices -- N_a N_b = sum_c N_{ab}^c N_c ((N_a)_{cb} = N_{ab}^c, left multiplication by a)
def Nmat(L, N, a):
    return sp.Matrix([[N[a][b_][c] for b_ in L] for c in L])


S3g = list(itertools.permutations(range(3)))
s3mul = lambda g, h: tuple(g[h[i]] for i in range(3))
s3inv = lambda g: tuple(sorted(range(3), key=lambda i: g[i]))
rings_nc = dict(rings, **{'Vec_S3': ring_group(S3g, s3mul, s3inv)})
ok = True
for name, (L, N, dual) in rings_nc.items():
    ok &= all(Nmat(L, N, a) * Nmat(L, N, b_) == sum((N[a][b_][c] * Nmat(L, N, c) for c in L), sp.zeros(len(L)))
              for a in L for b_ in L)
check('rem:5:matrices', 'EXACT', ok, 'N_a N_b = sum_c N_{ab}^c N_c in all the rings, Vec_S3 included')
Ls, Nsg, _ = rings_nc['Vec_S3']
check('thm:5:fusionring(Vec_S3)', 'EXACT', associative(Ls, Nsg) and rigidity(Ls, Nsg, rings_nc['Vec_S3'][2]),
      'Vec_S3 is a fusion ring')
check('rem:5:noncomm', 'EXACT', any(Nmat(Ls, Nsg, a) * Nmat(Ls, Nsg, b_) != Nmat(Ls, Nsg, b_) * Nmat(Ls, Nsg, a)
                                    for a in Ls for b_ in Ls),
      'in Vec_S3 the matrices N_a do not all commute (the ring is not commutative)')

# ---------------------------------------------------------------- FPdim
def fpdim(L, N):
    out = {}
    for a in L:
        M = sp.Matrix([[N[a][b][c] for b in L] for c in L])   # left multiplication by a
        ev = [complex(e) for e in M.eigenvals(multiple=True)]
        out[a] = max(e.real for e in ev if abs(e.imag) < 1e-9)
    return out


for name, (L, N, dual) in rings.items():
    d = fpdim(L, N)
    ok = all(abs(d[a] * d[b] - sum(N[a][b][c] * d[c] for c in L)) < 1e-9 for a, b in itertools.product(L, repeat=2))
    ok &= all(d[a] >= 1 - 1e-12 for a in L)
    check(f'thm:5:fpdim({name})', 'NUMERICAL', ok, 'FPdim is multiplicative, d_a d_b = sum_c N d_c, and >= 1')
dF = fpdim(*ring_fib()[:2])
dI = fpdim(*ring_ising()[:2])
check('ex:5:fib(d)', 'NUMERICAL', abs(dF['t'] - float(phi)) < 1e-12, 'FPdim(tau) = phi = (1 + sqrt 5)/2')
check('ex:5:ising(d)', 'NUMERICAL', abs(dI['s'] - 2 ** 0.5) < 1e-12 and abs(dI['p'] - 1) < 1e-12,
      'FPdim(sigma) = sqrt 2, FPdim(psi) = 1')
for k in (2, 3, 4):
    L, N, _ = ring_su2(k)
    d = fpdim(L, N)
    q = sp.pi / (k + 2)
    ok = all(abs(d[j] - float(sp.sin((2 * j + 1) * q) / sp.sin(q))) < 1e-9 for j in L)
    check(f'ex:5:su2k(d, k={k})', 'NUMERICAL', ok, 'd_j = sin((2j+1) pi/(k+2)) / sin(pi/(k+2))')
dS3 = fpdim(*ring_s3()[:2])
check('ex:5:reps3(d)', 'NUMERICAL', [round(dS3[a], 9) for a in ['1', 'sgn', 'std']] == [1, 1, 2],
      'FPdim = dim in Rep(S3): 1, 1, 2')
control('thm:5:fpdim', 'NUMERICAL', abs(dF['t'] - (1 - float(phi))) > 1e-9,
        'FPdim(tau) is the other eigenvalue 1 - phi = -1/phi (the Yang-Lee value)')

# thm:5:fpdim proof sketch: right multiplication by R = sum_a [a] has positive entries; its
# Perron-Frobenius eigenvector is a common eigenvector of every N_a (left and right multiplications
# commute), with eigenvalue FPdim(a)
import numpy as np_
ok = True
for name, (L, N, dual) in rings_nc.items():
    Rr = np_.array([[sum(N[b_][a][c] for a in L) for b_ in L] for c in L], dtype=float)  # [b] -> [b] R
    ok &= bool((Rr > 0).all())
    w, V = np_.linalg.eig(Rr)
    v = np_.real(V[:, np_.argmax(np_.real(w))]); v = v / v.sum()
    ok &= bool((v > 0).all())
    d = fpdim(L, N)
    for a in L:
        Na = np_.array(Nmat(L, N, a), dtype=float)
        ok &= bool(np_.allclose(Na @ v, d[a] * v))
check('thm:5:fpdim(sketch)', 'NUMERICAL', ok,
      'R-multiplication is positive; its PF vector v satisfies N_a v = FPdim(a) v for every a (Vec_S3 too)')
Lf, Nf, _ = ring_fib()
control('thm:5:fpdim(sketch)', 'NUMERICAL',
        not np_.allclose(np_.array(Nmat(Lf, Nf, 't'), dtype=float) @ np_.array([1.0, 1.0]), float(phi) * np_.array([1.0, 1.0])),
        'the vector (1, 1) is an eigenvector of N_tau with eigenvalue phi')
# uniqueness step: a positive multiplicative f gives the eigenvector u_c = f(c*) of M (right
# multiplication by R), eigenvalue sum_a f(a); test with f = FPdim
ok = True
for name, (L, N, dual) in rings_nc.items():
    d = fpdim(L, N)
    Mr = np_.array([[sum(N[b_][a][c] for a in L) for b_ in L] for c in L], dtype=float)
    u = np_.array([d[dual[c]] for c in L])
    ok &= bool(np_.allclose(Mr @ u, sum(d.values()) * u))
check('thm:5:fpdim(unique)', 'NUMERICAL', ok, 'u_c = FPdim(c*) is an eigenvector of M with eigenvalue sum_a FPdim(a)')
# left multiplication by a commutes with right multiplication by R (associativity), in Vec_S3
Rr = sp.Matrix([[sum(Nsg[b_][a][c] for a in Ls) for b_ in Ls] for c in Ls])
check('thm:5:fpdim(commute)', 'EXACT', all(Nmat(Ls, Nsg, a) * Rr == Rr * Nmat(Ls, Nsg, a) for a in Ls),
      'N_a commutes with right multiplication by R, though the N_a do not commute with each other')

L3_, N3_, _ = ring_su2(3)
d3 = fpdim(L3_, N3_)
check('ex:5:su2-3(d)', 'NUMERICAL', abs(d3[sp.Rational(1, 2)] - float(phi)) < 1e-9 and abs(d3[sp.Integer(1)] - float(phi)) < 1e-9,
      'SU(2)_3: d_{1/2} = d_1 = phi')
# rem:5:positive -- the only positive solution of x^2 = 1 + x is phi (uniqueness of a positive character)
xs = sp.solve(sp.Symbol('x') ** 2 - 1 - sp.Symbol('x'), sp.Symbol('x'))
check('rem:5:positive', 'SYMBOLIC', [x_ for x_ in xs if x_.is_positive] == [phi],
      'x^2 = 1 + x has exactly one positive root, phi: d_tau = phi once d > 0')

# global dimensions
check('def:5:globaldim', 'SYMBOLIC',
      sp.simplify(1 + phi ** 2 - (2 + phi)) == 0 and sp.simplify(1 + 2 + 1 - 4) == 0,
      'dim Fib = 1 + phi^2 = 2 + phi; dim Ising = 1 + 2 + 1 = 4')
check('def:5:globaldim(S3, Z3)', 'EXACT', 1 + 1 + 4 == 6 and 3 * 1 == 3, 'dim Rep(S3) = 6 = |S3|; dim Vec_Z3 = 3')

# The operational unitary structure moved from L6 to L5: dagger and positivity.
# Exact matrices give a non-real inner product, so a transpose cannot masquerade as a dagger.
v_unit = sp.Matrix([1 + sp.I, 2, -sp.I])
w_unit = sp.Matrix([sp.I, 1 - sp.I, 3])
inner_unit = (v_unit.H * w_unit)[0]
check('def:5:unitary(inner product)', 'EXACT', sp.simplify(inner_unit - (3 + 2 * sp.I)) == 0
      and sp.simplify((v_unit.H * v_unit)[0]) == 7,
      'on Hom(C,C^3), v^dagger w is the inner product, antilinear first, and v^dagger v = 7 > 0')
control('def:5:unitary(inner product)', 'EXACT', sp.simplify((v_unit.T * w_unit)[0] - inner_unit) != 0,
        'transpose without complex conjugation gives the same inner product')
f_unit = sp.Matrix([[1, sp.I], [2 - sp.I, 0]])
g_unit = sp.Matrix([[sp.I, 2], [0, 1 + sp.I]])
check('def:5:unitary(tensor dagger)', 'EXACT',
      sp.kronecker_product(f_unit, g_unit).H == sp.kronecker_product(f_unit.H, g_unit.H),
      'the dagger of f tensor g is f^dagger tensor g^dagger exactly')

# ---------------------------------------------------------------- fusion spaces and trees
def tree_dim(L, N, word, c):
    """dim Hom(c, a1 (x) ... (x) an) by fusing from the left: sum over intermediate channels."""
    vec = {x: int(x == word[0]) for x in L}
    for a in word[1:]:
        vec = {y: sum(vec[x] * N[x][a][y] for x in L) for y in L}
    return vec[c]


fib_seq = [1, 1]
for _ in range(12):
    fib_seq.append(fib_seq[-1] + fib_seq[-2])
Lf, Nf, _ = ring_fib()
ok = all(tree_dim(Lf, Nf, ['t'] * n, '1') == fib_seq[n - 2] and tree_dim(Lf, Nf, ['t'] * n, 't') == fib_seq[n - 1]
         for n in range(2, 12))
check('thm:5:trees(Fib)', 'EXACT', ok,
      'dim V^{tau^n}_1 = F_{n-1}, dim V^{tau^n}_tau = F_n (Fibonacci numbers, F_1 = F_2 = 1)')
check('thm:5:trees(Fib small)', 'EXACT',
      [tree_dim(Lf, Nf, ['t'] * n, 't') for n in range(1, 7)] == [1, 1, 2, 3, 5, 8],
      'n = 1..6 tau particles in total charge tau: 1, 1, 2, 3, 5, 8')
control('thm:5:trees(Fib)', 'EXACT', tree_dim(Lf, Nf, ['t'] * 4, 't') != 2 ** 3,
        '4 tau particles have 2^3 states in channel tau (qubit counting)')
# the dimension does not depend on the bracketing (fuse from the right instead)
def tree_dim_right(L, N, word, c):
    vec = {x: int(x == word[-1]) for x in L}
    for a in reversed(word[:-1]):
        vec = {y: sum(N[a][x][y] * vec[x] for x in L) for y in L}
    return vec[c]


Li, Ni, _ = ring_ising()
ok = all(tree_dim(L_, N_, w, c) == tree_dim_right(L_, N_, w, c)
         for (L_, N_) in [(Lf, Nf), (Li, Ni)] for n in range(2, 6)
         for w in itertools.product(L_, repeat=n) for c in L_)
check('thm:5:trees(bracketing)', 'EXACT', ok, 'left- and right-bracketed trees count the same dimension')
check('ex:5:ising(trees)', 'EXACT', [tree_dim(Li, Ni, ['s'] * (2 * m), '1') for m in range(1, 6)] == [1, 2, 4, 8, 16],
      '2m sigma particles in total charge 1: 2^{m-1} states')

# Scope guards for the revised objectives and fixed-tree basis statement.
control('objectives:5:Ising sector', 'EXACT',
        all(tree_dim(Li, Ni, ['s'] * n, '1') == 0 for n in (1, 3, 5, 7)),
        'odd numbers of sigma particles have a nonzero vacuum fusion space')
control('thm:5:trees(fixed shape)', 'EXACT',
        tree_dim(Lf, Nf, ['t'] * 4, 't') + tree_dim_right(Lf, Nf, ['t'] * 4, 't')
        != tree_dim(Lf, Nf, ['t'] * 4, 't'),
        'the union of left- and right-bracketed labelled trees is one basis')

# ---------------------------------------------------------------- vertices in Rep(S3)
S3 = list(itertools.permutations(range(3)))


def rho3(s):
    M = np.zeros((3, 3))
    for i in range(3):
        M[s[i], i] = 1
    return M


Fm = np.array([[1, -0.5], [-1, -0.5], [0, 1.0]])           # an orthogonal basis of the plane
Fm = Fm / np.linalg.norm(Fm, axis=0)                       # orthonormal: std is unitary
std = lambda s: Fm.T @ rho3(s) @ Fm                        # noqa: E731
sgn = lambda s: np.array([[np.linalg.det(rho3(s))]])       # noqa: E731
triv = lambda s: np.array([[1.0]])                          # noqa: E731
irr = {'1': triv, 'sgn': sgn, 'std': std}
dim = {'1': 1, 'sgn': 1, 'std': 2}


def intertwiners(A, B):
    """Orthonormal basis (Frobenius) of Hom_G(A, B) as matrices B-dim x A-dim."""
    da, db = A(S3[0]).shape[0], B(S3[0]).shape[0]
    rows = []
    for s in S3:
        # T A(s) - B(s) T = 0, vec(T) column-major
        rows.append(np.kron(A(s).T, np.eye(db)) - np.kron(np.eye(da), B(s)))
    M = np.vstack(rows)
    _, sv, vh = np.linalg.svd(M)
    null = vh[np.sum(sv > 1e-9):].conj()
    return [v.reshape(da, db).T for v in null]


ab = lambda s: np.kron(std(s), std(s))                      # noqa: E731  std (x) std
ok_bubble, ok_complete = True, True
total = np.zeros((4, 4))
for c in ['1', 'sgn', 'std']:
    T = intertwiners(irr[c], ab)
    assert len(T) == 1
    v = T[0]
    v = v / np.sqrt(np.trace(v.T @ v) / dim[c])           # isometry: v^T v = id_c
    psi = (dim['std'] * dim['std'] / dim[c]) ** 0.25 * v  # isotopy-invariant vertex
    ok_bubble &= close(psi.T @ psi, np.sqrt(dim['std'] * dim['std'] / dim[c]) * np.eye(dim[c]))
    total += np.sqrt(dim[c] / (dim['std'] * dim['std'])) * psi @ psi.T
    ok_bubble &= np.isclose(np.trace(psi.T @ psi), np.sqrt(dim['std'] ** 2 * dim[c]))   # theta
ok_complete = close(total, np.eye(4))
check('eq:5:bubble', 'NUMERICAL', ok_bubble,
      'Rep(S3), std (x) std: psi^dag psi = sqrt(d_a d_b / d_c) id_c, and the theta (closed bubble) is sqrt(d_a d_b d_c)')
check('eq:5:completeness', 'NUMERICAL', ok_complete,
      'sum_c sqrt(d_c / (d_a d_b)) psi psi^dag = id on std (x) std')
unit_weights = sum(psi_c @ psi_c.T for psi_c in [
    (dim['std'] ** 2 / dim[c]) ** 0.25 * (lambda v: v / np.sqrt(np.trace(v.T @ v) / dim[c]))(intertwiners(irr[c], ab)[0])
    for c in ['1', 'sgn', 'std']])
control('eq:5:completeness', 'NUMERICAL', not close(unit_weights, np.eye(4)),
        'completeness with the unit-norm weights 1 (Kitaev E.1) applied to isotopy-invariant vertices')
# eq:5:cup -- psi^{std std}_1 = coev (sum_i e_i (x) e_i in an orthonormal basis of the real
# orthogonal std), and its bubble is the loop d_std = 2
T1 = intertwiners(irr['1'], ab)[0]
v1 = T1 / np.sqrt(np.trace(T1.T @ T1))
psi1 = (dim['std'] ** 2 / dim['1']) ** 0.25 * v1
coev_std = np.eye(2).reshape(4, 1)
check('eq:5:cup', 'NUMERICAL', (close(psi1, coev_std) or close(psi1, -coev_std))
      and np.isclose((coev_std.T @ coev_std).item(), dim['std']),
      'psi^{std std}_1 = coev (up to the sign the gauge leaves); with the standard coev, coev^dag coev = 2 = d_std')
# the normalisation is not fixed by the snakes: (2 coev, ev / 2) satisfies both snakes (computed), and
# its cup has coev^dag coev = 8, not d_std = 2 -- so "standard duals" is a real choice
ev_std = np.eye(2).reshape(1, 4)
I2s_ = np.eye(2)
snakes_ok = (close(np.kron(I2s_, ev_std / 2) @ np.kron(2 * coev_std, I2s_), I2s_)
             and close(np.kron(ev_std / 2, I2s_) @ np.kron(I2s_, 2 * coev_std), I2s_))
check('eq:5:cup(rescaled snakes)', 'NUMERICAL', snakes_ok, '(2 coev, ev/2) satisfies both snake equations')
control('eq:5:cup(standard duals)', 'NUMERICAL', not np.isclose(((2 * coev_std).T @ (2 * coev_std)).item(), dim['std']),
        'the rescaled cup 2 coev, whose snakes are straight, also has coev^dag coev = d_std')
# rem:5:trees3 -- three tau's with total charge tau: the trees x = 1 and x = tau
check('rem:5:trees3', 'EXACT', [x for x in Lf if Nf['t']['t'][x] and Nf[x]['t']['t']] == ['1', 't'],
      'tau tau tau -> tau: intermediate x = 1 or tau, two trees')
check('rem:5:isingqubit', 'EXACT', tree_dim(Li, Ni, ['s'] * 4, '1') == 2, 'four sigma with total charge 1: a qubit (2 states)')
# rem:5:recursion -- f_n = f_{n-1} + f_{n-2}, and the total-1 space after n-1 leaves is the total-tau space after n-2
Lf2, Nf2, _ = ring_fib()
fn = lambda n: tree_dim(Lf2, Nf2, ['t'] * n, 't')                           # noqa: E731
check('rem:5:recursion', 'EXACT', all(fn(n) == fn(n - 1) + fn(n - 2) and tree_dim(Lf2, Nf2, ['t'] * (n - 1), '1') == fn(n - 2)
                                      for n in range(3, 14)),
      'f_n = f_{n-1} + f_{n-2}, with dim V^{tau^{n-1}}_1 = f_{n-2}')
# rem:5:isingqubit -- the two trees: x1 in {1, psi}, then x2 = sigma, then sigma sigma -> 1
Li2, Ni2, _ = ring_ising()
trees4 = [(x1, x2) for x1 in Li2 for x2 in Li2 if Ni2['s']['s'][x1] and Ni2[x1]['s'][x2] and Ni2[x2]['s']['1']]
check('rem:5:isingqubit(trees)', 'EXACT', trees4 == [('1', 's'), ('p', 's')], 'four sigma to 1: (x1, x2) = (1, sigma), (psi, sigma)')
check('eq:5:dimsum', 'EXACT', dim['std'] * dim['std'] == sum(dim[c] for c in ['1', 'sgn', 'std']),
      'd_a d_b = sum_c N_{ab}^c d_c for std (x) std: 4 = 1 + 1 + 2 (the trace of completeness)')

print()
if FAILS:
    print(f'{len(FAILS)} FAILED: ' + ', '.join(FAILS))
    sys.exit(1)
print('All L5 checks pass.')
