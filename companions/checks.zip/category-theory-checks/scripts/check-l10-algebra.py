"""Algebra script for Lecture 10, *Modular tensor categories and anyon models*.

This script checks, on instances, the modular data that lectures/lec10.tex prints: the
S- and T-matrices (Bible K17: S_ab = (dim C)^{-1/2} sum_c N_{a bbar}^c d_c theta_c/(theta_a
theta_b), T = diag(theta)), unitarity and symmetry of S, S^2 = C, (ST)^3 = e^{2 pi i c/8}
S^2, the Gauss sum and c mod 8, the Verlinde formula, the killing loop, the Muger
criterion, Fibonacci in full, and the tables for the semion, Ising (the 16-fold way), the
toric code and SU(2)_k, and the non-self-dual Z(Vec_Z3), where S differs from its
conjugate and C != 1; every check is NUMERICAL, some with a control that must fail.  Pictures are checked by rendering, not here.

Run:  python3 scripts/check-l10-algebra.py     (exit status 1 on failure)
"""
import cmath
import math
import pathlib
import sys

import numpy as np
import sympy as sp

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import anyons  # noqa: E402

FAILS = []


def check(label, kind, ok, what):
    print(f"{'OK  ' if ok else 'FAIL'} [{kind:9s}] {label}: {what}")
    if not ok:
        FAILS.append(label)


def control(label, kind, failed, what):
    check(label + ' (control)', kind, failed, what + ' -- must fail, and does')


close = lambda a, b, tol=1e-9: np.allclose(a, b, atol=tol)                 # noqa: E731


def modular(L, N, d, th, dual):
    """S (K17), T, dim C and the Gauss sum from fusion data, dimensions and spins."""
    D2 = sum(d[a] ** 2 for a in L)
    S = np.array([[sum(N(a, dual[b], c) * d[c] * th[c] for c in L) / (th[a] * th[b]) for b in L] for a in L]) / np.sqrt(D2)
    T = np.diag([th[a] for a in L])
    C = np.array([[1.0 if dual[a] == b else 0.0 for b in L] for a in L])
    gauss = sum(d[a] ** 2 * th[a] for a in L)
    return S, T, C, D2, gauss


def same_c(c1, c2):
    """c1 = c2 mod 8, compared on the circle e^{2 pi i c/8}: no branch cut at 0 = 8."""
    return abs(cmath.exp(2j * math.pi * (c1 - c2) / 8) - 1) < 1e-9


def cmod8(gauss, D2):
    return (cmath.phase(gauss / math.sqrt(D2)) / (2 * math.pi) * 8) % 8


def verlinde(L, N, S, dual):
    i1 = 0
    ok = True
    for ia, a in enumerate(L):
        for ib, b in enumerate(L):
            for ic, c in enumerate(L):
                v = sum(S[ia, x] * S[ib, x] * np.conj(S[ic, x]) / S[i1, x] for x in range(len(L)))
                ok &= abs(v - N(a, b, c)) < 1e-9
    return ok


def verlinde_first(L, N, S, dual):
    """N_ab^c = sum_x S_ax S_bx S_{x cbar} / S_1x (the first form, from S^{-1} = SC)."""
    idx = {a: i for i, a in enumerate(L)}
    return all(abs(sum(S[idx[a], x] * S[idx[b], x] * S[x, idx[dual[c]]] / S[0, x] for x in range(len(L))) - N(a, b, c)) < 1e-9
               for a in L for b in L for c in L)


def model_data(M):
    L = M.L
    th = {a: M.theta(a) for a in L}
    return L, M.N, M.d, th, M.dual


phi = (1 + 5 ** 0.5) / 2

# ================================================================ S10.5 Fibonacci, live
fib = anyons.fibonacci()
L, N, d, th, dual = model_data(fib)
S, T, C, D2, g = modular(L, N, d, th, dual)
S_print = np.array([[1, phi], [phi, -1]]) / np.sqrt(2 + phi)
check('ex:10:fibS', 'NUMERICAL', close(S, S_print) and close(D2, 2 + phi),
      'Fibonacci: dim C = 2 + phi, S = (2 + phi)^{-1/2} [[1, phi], [phi, -1]]')
check('ex:10:fibST', 'NUMERICAL', close(S @ S.conj().T, np.eye(2)) and close(S, S.T) and close(S @ S, C)
      and close(np.linalg.matrix_power(S @ T, 3), cmath.exp(2j * math.pi * (14 / 5) / 8) * S @ S),
      'S unitary and symmetric, S^2 = C = 1, (ST)^3 = e^{2 pi i (14/5)/8} S^2')
check('ex:10:fibc', 'NUMERICAL', same_c(cmod8(g, D2), 14 / 5) and abs(abs(g) - np.sqrt(D2)) < 1e-9,
      'Gauss sum: 1 + phi^2 e^{4 pi i/5} = sqrt(2 + phi) e^{2 pi i c/8} with c = 14/5')
# Exact identification of the Gauss-sum phase printed in the worked example.
phi_exact = (1 + sp.sqrt(5)) / 2
norm_exact = sp.sqrt(2 + phi_exact)
re_exact = (sp.Rational(1, 2) - phi_exact) / norm_exact
im_exact = phi_exact ** 2 * sp.sin(sp.pi / 5) / norm_exact
check('ex:10:fibc(phase)', 'EXACT', sp.simplify(re_exact + sp.sin(sp.pi / 5)) == 0
      and sp.simplify(im_exact - sp.cos(sp.pi / 5)) == 0
      and sp.simplify(re_exact - sp.cos(7 * sp.pi / 10)) == 0
      and sp.simplify(im_exact - sp.sin(7 * sp.pi / 10)) == 0,
      'normalised Gauss sum has real part -sin(pi/5), imaginary part cos(pi/5), hence phase 7pi/10')
control('ex:10:fibc(phase)', 'EXACT', sp.simplify(im_exact - sp.sin(-7 * sp.pi / 10)) != 0,
        'the normalised Gauss sum has phase -7pi/10')
Sm, Tm, Cm, D2m, gm = modular(*model_data(anyons.fibonacci(-1)))
check('ex:10:fibc(conjugate)', 'NUMERICAL', same_c(cmod8(gm, D2m), (-14 / 5) % 8),
      'the conjugate chirality has c = -14/5 (= 26/5 mod 8), as printed')
control('ex:10:fibc', 'NUMERICAL', not same_c(cmod8(gm, D2m), 14 / 5),
        'the conjugate chirality also has c = 14/5')
check('thm:10:verlinde(fib)', 'NUMERICAL', verlinde(L, N, S, dual),
      'Verlinde: N_ab^c = sum_x S_ax S_bx conj(S_cx) / S_1x reproduces tau tau = 1 + tau')
Sbad = np.array([[1, phi], [phi, 1]]) / np.sqrt(2 + phi)
control('thm:10:verlinde(fib)', 'NUMERICAL', not verlinde(L, N, Sbad, dual), 'S with S_tt = +1 satisfies Verlinde')

# The loop-fusion picture represents the character identity, including its coefficient.
loop_values = (phi_exact, -1 / phi_exact)
check('lem:10:character(diagram)', 'EXACT', all(sp.simplify(x ** 2 - 1 - x) == 0 for x in loop_values),
      'Fibonacci: two tau loops fuse to one vacuum loop plus one tau loop, on both simple strands')
control('lem:10:character(diagram)', 'EXACT', not all(sp.simplify(x ** 2 - 1 + x) == 0 for x in loop_values),
        'the tau summand in loop fusion has coefficient -1')

# ================================================================ the killing loop
# sum_a (d_a / dim C) (Hopf link of a with x) = delta_{x,1} d_x: the omega_0 loop kills every x != 1
Stil = S * np.sqrt(D2)                                       # the unnormalised Hopf link values
kill = [sum(d[a] * Stil[ia, ix] for ia, a in enumerate(L)) / D2 for ix, x in enumerate(L)]
check('eq:10:killing', 'NUMERICAL', close(kill, [1, 0]), 'Fibonacci: the omega_0 loop around x is delta_{x,1}')

# ================================================================ the tables
models = {'semion': (anyons.pointed_z2(-1, 1j), 1.0), 'Ising': (anyons.ising(1), 0.5),
          'toric code': (anyons.toric_code(), 0.0), 'Fibonacci': (fib, 14 / 5)}
ok = True
for name, (M, cexp) in models.items():
    L_, N_, d_, th_, du_ = model_data(M)
    S_, T_, C_, D2_, g_ = modular(L_, N_, d_, th_, du_)
    ok &= close(S_ @ S_.conj().T, np.eye(len(L_))) and close(S_ @ S_, C_) and same_c(cmod8(g_, D2_), cexp) \
        and close(np.linalg.matrix_power(S_ @ T_, 3), cmath.exp(2j * math.pi * cexp / 8) * S_ @ S_) and verlinde(L_, N_, S_, du_)
check('tab:10:models', 'NUMERICAL', ok, 'semion c = 1, Ising c = 1/2, toric code c = 0, Fibonacci c = 14/5: S unitary, S^2 = C, (ST)^3, Verlinde')
# the toric code S = (1/2)(+-1)
Ltc, Ntc, dtc, thtc, dutc = model_data(anyons.toric_code())
Stc = modular(Ltc, Ntc, dtc, thtc, dutc)[0]
Stc_print = 0.5 * np.array([[1, 1, 1, 1], [1, 1, -1, -1], [1, -1, 1, -1], [1, -1, -1, 1]])
order = [Ltc.index(a) for a in ('1', 'e', 'm', 'x')]                          # anyons.py writes x for eps
check('ex:10:toricS', 'NUMERICAL', close(Stc[np.ix_(order, order)], Stc_print),
      'toric code: S is the printed matrix, sign by sign, in the order 1, e, m, eps')
tc_labels = [(0, 0), (1, 0), (0, 1), (1, 1)]  # 1, e, m, eps
tc_twists = dict(zip(tc_labels, map(sp.Integer, [1, 1, 1, -1])))
tc_sum = lambda a, b: ((a[0] + b[0]) % 2, (a[1] + b[1]) % 2)  # noqa: E731
tc_exact = sp.Matrix([[tc_twists[tc_sum(a, b)] / (tc_twists[a] * tc_twists[b] * sp.sqrt(4))
                       for b in tc_labels] for a in tc_labels])
tc_phase = tc_twists[tc_sum(tc_labels[1], tc_labels[2])] / (tc_twists[tc_labels[1]] * tc_twists[tc_labels[2]])
check('ex:10:toricS(normalisation)', 'EXACT', tc_phase == -1 and tc_exact[1, 2] == sp.Rational(-1, 2)
      and tc_exact == sp.Rational(1, 2) * sp.Matrix([[1, 1, 1, 1], [1, 1, -1, -1], [1, -1, 1, -1], [1, -1, -1, 1]]),
      'theta_eps/(theta_e theta_m) = -1 is the double-braiding phase; S_em = -1/2')
control('ex:10:toricS(normalisation)', 'EXACT', tc_phase / sp.sqrt(4) != tc_phase,
        'the normalised S entry equals the double-braiding phase')
# Ising's 16-fold way: c = nu/2 for the eight odd nu
ok = all(same_c(cmod8(*[modular(*model_data(anyons.ising(nu)))[k] for k in (4, 3)]), nu / 2) for nu in range(1, 16, 2))
check('rem:10:16fold', 'NUMERICAL', ok, 'the Ising-type theories have c = nu/2 mod 8, nu odd')
# SU(2)_2 from L9's formulas (d_j = [2j+1]_q, theta_j = e^{2 pi i j(j+1)/4}), against the nu = 3 hexagon solution
L2k = [0, 0.5, 1]
d2k = {j: math.sin((2 * j + 1) * math.pi / 4) / math.sin(math.pi / 4) for j in L2k}
th2k = {j: cmath.exp(2j * math.pi * j * (j + 1) / 4) for j in L2k}
N2k = lambda a, b, c: int(abs(a - b) <= c <= min(a + b, 2 - a - b) and (a + b - c) == int(a + b - c))  # noqa: E731
S2k, T2k, C2k, D22k, g2k = modular(L2k, N2k, d2k, th2k, {j: j for j in L2k})
i3 = anyons.ising(3)
check('rem:10:isingvssu22', 'NUMERICAL', close(anyons.ising(1).theta('s'), cmath.exp(1j * math.pi / 8))
      and close(i3.theta('s'), th2k[0.5]) and same_c(cmod8(g2k, D22k), 1.5)
      and same_c(cmod8(*[modular(*model_data(anyons.ising(1)))[k] for k in (4, 3)]), 0.5),
      'Ising (nu = 1): theta_sigma = e^{i pi/8}, c = 1/2; SU(2)_2 from L9: theta_{1/2} = e^{3 pi i/8} (the nu = 3 solution), c = 3/2')
control('rem:10:isingvssu22', 'NUMERICAL', not close(anyons.ising(1).theta('s'), th2k[0.5]),
        'Ising and SU(2)_2 have the same theta_sigma')

# ================================================================ SU(2)_k
ok = True
for k in range(1, 7):
    Lk = [n / 2 for n in range(k + 1)]
    qq = cmath.exp(1j * math.pi / (k + 2))
    dk = {j: (math.sin((2 * j + 1) * math.pi / (k + 2)) / math.sin(math.pi / (k + 2))) for j in Lk}
    thk = {j: cmath.exp(2j * math.pi * j * (j + 1) / (k + 2)) for j in Lk}
    Nk = lambda a, b, c, k=k: int(abs(a - b) <= c <= min(a + b, k - a - b) and (a + b - c) == int(a + b - c))  # noqa: E731
    Sk, Tk, Ck, D2k, gk = modular(Lk, Nk, dk, thk, {j: j for j in Lk})
    Sform = np.array([[math.sqrt(2 / (k + 2)) * math.sin((2 * a + 1) * (2 * b + 1) * math.pi / (k + 2)) for b in Lk] for a in Lk])
    ok &= close(Sk, Sform) and same_c(cmod8(gk, D2k), 3 * k / (k + 2)) and verlinde(Lk, Nk, Sk, {j: j for j in Lk})
check('tab:10:su2k', 'NUMERICAL', ok, 'SU(2)_k, k = 1..6: S_jj\' = sqrt(2/(k+2)) sin((2j+1)(2j\'+1) pi/(k+2)), c = 3k/(k+2), Verlinde')

# ================================================================ S10.2 the Muger criterion
sv = anyons.pointed_z2(1, -1)                                 # sVec: symmetric
Lsv, Nsv, dsv, thsv, dusv = model_data(sv)
Ssv = modular(Lsv, Nsv, dsv, thsv, dusv)[0]
check('thm:10:modular', 'NUMERICAL', abs(np.linalg.det(Ssv)) < 1e-12 and abs(np.linalg.det(S)) > 1e-3,
      'sVec (every object transparent) has singular S; Fibonacci (trivial Muger centre) has invertible S')
killsv = [sum(dsv[a] * Ssv[ia, ix] * math.sqrt(2) for ia, a in enumerate(Lsv)) / 2 for ix in range(2)]
control('lem:10:killing', 'NUMERICAL', not close(killsv, [1, 0]), 'the killing loop kills s in sVec (whose Muger centre is not trivial)')

# ================================================================ a non-self-dual model: Z(Vec_Z3)
Lz, Nz, dz, thz, duz = model_data(anyons.double_z3())
Sz, Tz, Cz, D2z, gz = modular(Lz, Nz, dz, thz, duz)
check('thm:10:sl2z(Z3)', 'NUMERICAL', not close(Cz, np.eye(9)) and close(Sz @ Sz, Cz) and close(Sz @ Sz.conj().T, np.eye(9))
      and close(np.linalg.matrix_power(Sz @ Tz, 3), gz / np.sqrt(D2z) * Sz @ Sz) and abs(gz / np.sqrt(D2z) - 1) < 1e-9,
      'Z(Vec_Z3): C != 1, S^2 = C, S unitary, (ST)^3 = e^{2 pi i c/8} S^2 with c = 0')
check('thm:10:verlinde(Z3)', 'NUMERICAL', verlinde_first(Lz, Nz, Sz, duz) and verlinde(Lz, Nz, Sz, duz),
      'Z(Vec_Z3): both forms of Verlinde, with S_{x cbar} and with conj(S_cx)')
control('thm:10:verlinde(Z3)', 'NUMERICAL', not verlinde_first(Lz, Nz, Sz, {a: a for a in Lz}),
        'the first form without the bar, S_{xc}')
Sbar = Sz.conj()
control('def:10:st(Z3)', 'NUMERICAL', not close(np.linalg.matrix_power(Sbar @ Tz, 3), cmath.exp(2j * math.pi * cmod8(gz, D2z) / 8) * Sbar @ Sbar),
        'the conjugate S (Bonderson (2.63), N_ab) with T = diag(theta) satisfies (ST)^3 = e^{2 pi i c/8} S^2')

# ================================================================ S diagonalises fusion, in L5's convention
# L5: (N_a)_{cb} = N_{ab}^c.  Then N_a = S^{-1} diag(S_ax/S_1x) S; the transpose S diag S^{-1} differs as soon as
# a simple is not self-dual.  Z(Vec_Z3), labels (g, k), S_(g,k),(h,l) = zeta^{-(gl+hk)}/3 (K17), a = (1, 0).
zeta3 = cmath.exp(2j * math.pi / 3)
L3 = [(g, k) for g in range(3) for k in range(3)]
S3m = np.array([[zeta3 ** (-(g * l + h * k)) / 3 for (h, l) in L3] for (g, k) in L3])
ok_conv, ok_old = True, True
for a in L3:
    Na = np.zeros((9, 9))
    for ib, b in enumerate(L3):
        Na[L3.index(((a[0] + b[0]) % 3, (a[1] + b[1]) % 3)), ib] = 1
    Dg = np.diag(S3m[L3.index(a)] / S3m[L3.index((0, 0))])
    ok_conv &= np.allclose(Na, np.linalg.inv(S3m) @ Dg @ S3m)
    ok_old &= np.allclose(Na, S3m @ Dg @ np.linalg.inv(S3m))
check('thm:10:verlinde(matrix)', 'NUMERICAL', ok_conv, 'Z(Vec_Z3): with (N_a)_{cb} = N_{ab}^c (L5), N_a = S^{-1} diag(S_ax/S_1x) S for all nine a')
control('thm:10:verlinde(matrix)', 'NUMERICAL', not ok_old, 'N_a = S diag(S_ax/S_1x) S^{-1} in L5\'s convention')

print()
if FAILS:
    print(f'{len(FAILS)} FAILED: ' + ', '.join(FAILS))
    sys.exit(1)
print('All L10 checks pass.')
