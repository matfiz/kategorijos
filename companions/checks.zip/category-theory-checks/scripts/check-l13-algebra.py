"""Algebra script for Lecture 13, *Boundaries, defects and non-invertible symmetries*.

This script checks, on instances: the Lagrangian algebras of Z(Vec_Z2) (1 (+) X with X a
boson of order two: exactly 1 (+) e and 1 (+) m; not 1 (+) eps, whose multiplication is not
commutative) and of the double semion (one, 1 (+) b), matching the counts of indecomposable
module categories (2 and 1; DMNO Prop. 4.8); the square-zero algebras on 1 (+) X
(associative, commutative, connected, not separable); the star and plaquette incidences
behind the boundary parity count; the Kramers-Wannier operator on a periodic chain (SSS
(1.4)-(1.5): D^2 = (1 + eta) T^{-1}, eta D = D eta = D, D X_j = Z_{j-1} Z_j D, with the
translation T O_j T^{-1} = O_{j+1}; Shao's operator D_Shao = D^dagger/sqrt 2, not a rescaling
of D, with D_Shao^2 = (1/2)(1 + eta) T); the KW image g H(1/g), isospectral with H(g) in the
eta-even sector only; and the Ising F-symbol as TY(Z2, chi, +1/sqrt 2).  Every check is EXACT (integers) or
NUMERICAL (floating point with tolerances); some carry a control that must fail.

Run:  python3 scripts/check-l13-algebra.py     (exit status 1 on failure)
"""
import cmath
import itertools
import math
import pathlib
import sys
from functools import reduce

import numpy as np

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import anyons  # noqa: E402

FAILS = []


def check(label, kind, ok, what):
    print(f"{'OK  ' if ok else 'FAIL'} [{kind:9s}] {label}: {what}")
    if not ok:
        FAILS.append(label)


def control(label, kind, failed, what):
    """failed must be True: the false statement `what` is refuted."""
    check(label + ' (control)', kind, failed, what + ' -- must fail, and does')


close = lambda a, b, tol=1e-9: np.allclose(a, b, atol=tol)                 # noqa: E731


# ================================================================ S13.2 Lagrangian algebras in Z(Vec_A^omega)
def centre(A, add, omega):
    """Simple objects (g, gamma) of Z(Vec_A^omega), as in check-l12-algebra.py (EGNO (7.41) on simples)."""
    n = 4 * len(A)
    roots = [cmath.exp(2j * math.pi * r / n) for r in range(n)]
    out = []
    for g in A:
        for vals in itertools.product(roots, repeat=len(A) - 1):
            gam = dict(zip(A[1:], vals))
            gam[A[0]] = 1
            if all(abs(gam[add(h, k)] - omega(h, k, g) * gam[k] * gam[h] * omega(g, h, k) / omega(h, g, k)) < 1e-9
                   for h in A for k in A):
                out.append((g, gam))
    return out


def lagrangian_count(A, add, omega):
    """Connected etale algebras 1 (+) X with FPdim^2 = FPdim Z = |A|^2 when |A| = 2: X != 1 with X (x) X = 1
    (so the multiplication X (x) X -> 1 can be nonzero, which separability forces) and commutative,
    m o c_{X,X} = m, i.e. the self-braiding of X on its vacuum channel is 1."""
    Z = centre(A, add, omega)
    count = 0
    for g, gam in Z:
        trivial = g == A[0] and all(abs(gam[h] - 1) < 1e-9 for h in A)
        order_two = add(g, g) == A[0]
        if not trivial and order_two and abs(gam[g] - 1) < 1e-9:     # c_{X,X} = gamma_g on X (x) X = vacuum
            count += 1
    return count, Z


Z2 = [0, 1]
add2 = lambda a, b: (a + b) % 2                                           # noqa: E731
one = lambda *x: 1                                                        # noqa: E731
semion_omega = lambda a, b, c: -1 if (a, b, c) == (1, 1, 1) else 1        # noqa: E731
n_tc, Ztc = lagrangian_count(Z2, add2, one)
n_ds, Zds = lagrangian_count(Z2, add2, semion_omega)
labels = {}
for g, gam in Ztc:
    labels[{(0, False): '1', (0, True): 'e', (1, False): 'm', (1, True): 'eps'}[(g, abs(gam[1] + 1) < 1e-9)]] = gam[g]
check('thm:13:lagrangian', 'NUMERICAL', n_tc == 2 and abs(labels['e'] - 1) < 1e-9 and abs(labels['m'] - 1) < 1e-9
      and abs(labels['eps'] + 1) < 1e-9,
      'Z(Vec_Z2): the Lagrangian algebras are 1 (+) e and 1 (+) m (c_{X,X} = 1); 1 (+) eps fails (c_{eps,eps} = -1)')
control('thm:13:lagrangian', 'NUMERICAL', n_tc != 3, 'all three non-trivial anyons give Lagrangian algebras')
check('thm:13:dmno(count)', 'NUMERICAL', n_tc == 2 and n_ds == 1,
      'Lagrangian algebras = indecomposable module categories: 2 for Vec_Z2 (L11), 1 for the semion\'s Vec_Z2^omega '
      '(only the regular module; the double semion\'s boson b)')

# the square-zero algebras on 1 (+) X: basis (1, x), x.x = lam 1; right regular representation
def right_mult(lam):
    """matrices of right multiplication by 1 and by x on the basis (1, x) of A = 1 (+) X."""
    R1 = np.eye(2)
    Rx = np.array([[0, lam], [1, 0]], dtype=complex)                     # 1.x = x, x.x = lam 1
    return R1, Rx


def is_associative(lam):
    mult = {(0, 0): (1, 0), (0, 1): (0, 1), (1, 0): (0, 1), (1, 1): (lam, 0)}  # basis products as coordinates
    def m(u, v):
        out = np.zeros(2, dtype=complex)
        for i, j in itertools.product(range(2), range(2)):
            out += u[i] * v[j] * np.array(mult[i, j])
        return out
    E = [np.array([1, 0], dtype=complex), np.array([0, 1], dtype=complex)]
    return all(np.allclose(m(m(a, b), c), m(a, m(b, c))) for a in E for b in E for c in E)


def regular_semisimple(lam):
    """A_A is semisimple iff right multiplication by x is diagonalisable (A = C[x]/(x^2 - lam))."""
    _, Rx = right_mult(lam)
    w, V = np.linalg.eig(Rx)
    return abs(np.linalg.det(V)) > 1e-8
ok = is_associative(0) and not regular_semisimple(0) and is_associative(1) and regular_semisimple(1)
check('thm:13:lagrangian(squarezero)', 'NUMERICAL', ok,
      'x.x = 0 on 1 (+) X is associative and unital, with A_A not semisimple (not separable); x.x = 1 is semisimple')
commutative = lambda lam, cXX: abs(lam * cXX - lam) < 1e-12              # noqa: E731  m o c = m on X (x) X
check('thm:13:lagrangian(commutative)', 'EXACT', commutative(0, -1) and commutative(1, 1) and not commutative(1, -1),
      'm o c = m on X (x) X: the square-zero algebra on 1 (+) eps is commutative (both sides 0); x.x = 1 needs c_{X,X} = 1')
control('thm:13:lagrangian(commutative)', 'EXACT', not commutative(1, -1), '1 (+) eps with x.x = 1 is commutative')

# ================================================================ S13.1 the boundary parity count
def strip(W, Hh):
    """Square lattice on a cylinder of circumference W: rows y = 0..Hh, a smooth boundary at the
    top row y = Hh, and a rough boundary below y = 0 (dangling edges to outer ends with no star)."""
    edges = [('h', x, y) for x in range(W) for y in range(Hh + 1)]               # (x,y)-(x+1,y)
    edges += [('v', x, y) for x in range(W) for y in range(-1, Hh)]              # (x,y)-(x,y+1); y = -1 dangles
    ends = lambda e: [(e[1], e[2]), ((e[1] + 1) % W, e[2])] if e[0] == 'h' else [(e[1], e[2]), (e[1], e[2] + 1)]  # noqa: E731
    stars = {(x, y): [e for e in edges if (x, y) in ends(e)] for x in range(W) for y in range(Hh + 1)}
    plaq = [[('h', x, y), ('h', x, y + 1), ('v', x, y), ('v', (x + 1) % W, y)] for x in range(W) for y in range(Hh)]
    plaq += [[('h', x, 0), ('v', x, -1), ('v', (x + 1) % W, -1)] for x in range(W)]  # truncated, rough side
    in_st = {e: sum(e in st for st in stars.values()) for e in edges}
    in_pl = {e: sum(e in pl for pl in plaq) for e in edges}
    return edges, stars, plaq, in_st, in_pl


edges, stars, plaq, in_st, in_pl = strip(5, 3)
top = [e for e in edges if e[0] == 'h' and e[2] == 3]
dangling = [e for e in edges if e[0] == 'v' and e[2] == -1]
ok = all(in_pl[e] == 1 for e in top) and all(in_st[e] == 2 for e in edges if e not in dangling) \
    and all(in_st[e] == 1 for e in dangling) and all(in_pl[e] == 2 for e in edges if e not in top) \
    and all(len(stars[x, 3]) == 3 for x in range(5)) and all(len(pl) == 3 for pl in plaq[-5:])
check('thm:13:tcboundaries', 'EXACT', ok,
      'smooth top: its edges lie in one plaquette (m absorbed), every non-dangling edge in two stars (e parity kept); '
      'rough bottom: dangling edges meet one star (e absorbed), every non-top edge lies in two plaquettes (m parity kept)')
# the open strip (no periodic identification): at its two ends a dangling edge lies in only one
# plaquette, so the parity count is local, near one long boundary and away from its ends
W = 5
open_plaq = [[('h', x, y), ('h', x, y + 1), ('v', x, y), ('v', x + 1, y)] for x in range(W - 1) for y in range(3)]
open_plaq += [[('h', x, 0), ('v', x, -1), ('v', x + 1, -1)] for x in range(W - 1)]
in_pl_open = {x: sum(('v', x, -1) in pl for pl in open_plaq) for x in range(W)}
control('thm:13:tcboundaries(local)', 'EXACT', not all(in_pl_open[x] == 2 for x in range(W)),
        'on the open strip every dangling edge lies in two plaquettes (the corners: 1), so the parity count needs no locality')

# ================================================================ S13.3 Kramers-Wannier on a periodic chain
# The bicharacter in the TY definition, in additive coordinates for Z2.
chi_ty = lambda a, b: (-1) ** (a * b)
radical_ty = lambda chi: [a for a in Z2 if all(chi(a, b) == 1 for b in Z2)]
check('def:13:ty(bicharacter)', 'EXACT',
      all(chi_ty((a + b) % 2, c) == chi_ty(a, c) * chi_ty(b, c)
          and chi_ty(a, (b + c) % 2) == chi_ty(a, b) * chi_ty(a, c)
          for a, b, c in itertools.product(Z2, repeat=3))
      and all(chi_ty(a, b) == chi_ty(b, a) for a, b in itertools.product(Z2, repeat=2))
      and radical_ty(chi_ty) == [0],
      'chi(eta,eta)=-1 is symmetric, multiplicative in each variable and nondegenerate')
control('def:13:ty(bicharacter)', 'EXACT',
        len(radical_ty(lambda a, b: 1)) != 1,
        'the trivial bicharacter on Z2 is nondegenerate')

I2 = np.eye(2)
X = np.array([[0, 1], [1, 0]], dtype=complex)
Zm = np.diag([1, -1]).astype(complex)
Y = 1j * X @ Zm


def op(o, j, N):
    return reduce(np.kron, [o if k == j else I2 for k in range(N)])


ok_all, ok_shao, ok_ctrl, ok_scal, ok_img, ok_even, ok_odd, ok_unique, ok_sss = (True,) * 9
for N in (3, 4, 5, 6):
    d = 2 ** N
    Id = np.eye(d)
    Xs = [op(X, j, N) for j in range(N)]
    Zs = [op(Zm, j, N) for j in range(N)]
    Ys = [op(Y, j, N) for j in range(N)]
    eta = reduce(np.matmul, Xs)
    t = [(Xs[j] @ Xs[j + 1] + Ys[j] @ Ys[j + 1] + Zs[j] @ Zs[j + 1] + Id) / 2 for j in range(N - 1)]
    T = reduce(np.matmul, t)                                       # Shao (3.44), T_Ising
    shift = all(np.allclose(T @ Zs[j] @ np.linalg.inv(T), Zs[(j + 1) % N]) for j in range(N))
    fac = []
    for j in range(N - 1):
        fac.append((Id + 1j * Xs[j]) / np.sqrt(2))
        fac.append((Id + 1j * Zs[j] @ Zs[j + 1]) / np.sqrt(2))
    fac.append((Id + 1j * Xs[N - 1]) / np.sqrt(2))
    U = np.exp(-2j * np.pi * N / 8) * reduce(np.matmul, fac)       # Shao (3.46)
    Dshao = U @ (Id + eta) / 2                                     # Shao (3.48)
    D = np.sqrt(2) * Dshao.conj().T                                # SSS's D (their fn 1; compared with their (2.36) below)
    ok_all &= shift and close(D @ D, (Id + eta) @ np.linalg.inv(T)) and close(eta @ D, D) and close(D @ eta, D) \
        and all(close(D @ Xs[j], Zs[(j - 1) % N] @ Zs[j] @ D) for j in range(N)) \
        and all(close(D @ Zs[(j - 1) % N] @ Zs[j], Xs[(j - 1) % N] @ D) for j in range(N))
    if N <= 5:                                                     # the two KW relations fix D up to a scalar
        rows = []
        for j in range(N):
            for A, B in ((Xs[j], Zs[(j - 1) % N] @ Zs[j]), (Zs[(j - 1) % N] @ Zs[j], Xs[(j - 1) % N])):
                rows.append(np.kron(A.T, Id) - np.kron(Id, B))     # M A = B M, column-major vec(M)
        ok_unique &= int(np.sum(np.linalg.svd(np.vstack(rows), compute_uv=False) < 1e-9)) == 1
    ok_shao &= close(Dshao @ Dshao, 0.5 * (Id + eta) @ T)
    # SSS (2.36), entered in its printed (descending) order, independently of Shao's construction
    sss = []
    for j in range(N - 1, -1, -1):
        sss.append((Id - 1j * Xs[j]) / np.sqrt(2))
        if j > 0:
            sss.append((Id - 1j * Zs[j] @ Zs[j - 1]) / np.sqrt(2))
    Dsss = np.exp(2j * np.pi * N / 8) * (Id + eta) / np.sqrt(2) @ reduce(np.matmul, sss)
    ok_sss &= close(Dsss, D)                                      # D_Shao = D_SSS^dagger / sqrt 2, sign included
    c = np.vdot(D.flatten(), Dshao.flatten()) / np.vdot(D.flatten(), D.flatten())  # best scalar c with Dshao ~ c D
    ok_scal &= not close(Dshao, c * D)                              # Shao's operator is not a rescaling of D
    ok_ctrl &= not close(D @ D, Id + eta)                          # the fusion rule N (x) N = 1 + eta fails on the lattice
    # the KW image of H, and the spectra by eta-sector
    Hg = lambda g: -sum(Zs[j] @ Zs[(j + 1) % N] + g * Xs[j] for j in range(N))   # noqa: E731
    g = 0.37
    ok_img &= close(D @ Hg(g), g * Hg(1 / g) @ D)
    Pe, Po = (Id + eta) / 2, (Id - eta) / 2
    def sector(Hm, P):
        w, V = np.linalg.eigh(P)
        B = V[:, w > 0.5]
        return np.sort(np.linalg.eigvalsh(B.conj().T @ Hm @ B))
    ok_even &= np.allclose(sector(Hg(g), Pe), sector(g * Hg(1 / g), Pe))
    ok_odd &= not np.allclose(sector(Hg(g), Po), sector(g * Hg(1 / g), Po))
check('thm:13:kw(lattice)', 'NUMERICAL', ok_all,
      'N = 3..6: with T O_j T^{-1} = O_{j+1}, D^2 = (1 + eta) T^{-1}, eta D = D eta = D, D X_j = Z_{j-1} Z_j D, '
      'D Z_{j-1} Z_j = X_{j-1} D (SSS (1.4)-(1.5))')
check('thm:13:kw(unique)', 'NUMERICAL', ok_unique,
      'N = 3..5: D X_j = Z_{j-1} Z_j D and D Z_{j-1} Z_j = X_{j-1} D have a one-dimensional solution space, so the '
      'relations fix D up to a scalar')
check('thm:13:kw(SSS)', 'NUMERICAL', ok_sss,
      'N = 3..6: SSS (2.36), built directly, equals sqrt 2 D_Shao^dagger with D_Shao from Shao (3.46)-(3.48), sign included')
check('thm:13:kw(Shao)', 'NUMERICAL', ok_shao, 'Shao\'s operator D_Shao = D^dagger/sqrt 2 has D_Shao^2 = (1/2)(1 + eta) T')
control('thm:13:kw(Shao)', 'NUMERICAL', ok_scal, 'Shao\'s operator is a rescaling c D of SSS\'s D')
control('thm:13:kw(lattice)', 'NUMERICAL', ok_ctrl, 'on the periodic chain D^2 = 1 + eta (the continuum fusion rule)')
check('thm:13:kw(spectra)', 'NUMERICAL', ok_img and ok_even,
      'N = 3..6, g = 0.37: D H(g) = g H(1/g) D, and H(g), g H(1/g) have the same eta-even spectrum (Integrability Prop. 18.9)')
control('thm:13:kw(spectra)', 'NUMERICAL', ok_odd, 'H(g) and g H(1/g) also have the same eta-odd spectrum (sector by sector)')

# ================================================================ S13.3 the continuum line: Ising = TY(Z2, chi, +1/sqrt 2)
ising = anyons.ising(1)
F = np.array([[ising.F('s', 's', 's', 's', e, f) for f in ('1', 'p')] for e in ('1', 'p')])
tau = 1 / math.sqrt(2)
check('thm:13:kw(TY)', 'NUMERICAL', close(F, tau * np.array([[1, 1], [1, -1]])) and close(ising.kappa('s'), 1),
      'Ising (nu = 1): F^{sss}_s = tau [[1, 1], [1, -1]] with tau = +1/sqrt 2 and kappa_sigma = +1: TY(Z2, chi, +1/sqrt 2)')
control('thm:13:kw(TY)', 'NUMERICAL', not close(F, -tau * np.array([[1, 1], [1, -1]])), 'the Ising line category has tau = -1/sqrt 2')

print()
if FAILS:
    print(f'{len(FAILS)} FAILED: ' + ', '.join(FAILS))
    sys.exit(1)
print('All L13 checks pass.')
