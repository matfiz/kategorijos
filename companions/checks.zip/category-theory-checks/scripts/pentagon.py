"""The pentagon, solved: L6's "hands on" (syllabus.md S4, L6).

For a multiplicity-free fusion ring, every F-symbol [F^{abc}_d]_{ef} with none of a, b, c
the unit is an unknown (with a unit it is 1, Bible K13).  The pentagon (B2.77) is a system
of polynomial equations in these unknowns.  It can have continuous families of solutions,
because vertex rescalings act on it (K15); a gauge condition, supplied with the fusion
rules, removes that freedom.  sympy then solves the system exactly.

    python3 scripts/pentagon.py           Fibonacci and Z2, printed
    python3 scripts/pentagon.py --test    the same, as checks (used by make formulas)

Fibonacci, gauge [F^{ttt}_t]_{1t} = [F^{ttt}_t]_{t1}: four solutions, with
[F^{ttt}_t]_{11} = 1/phi (unitary: d = phi) or -phi (Yang-Lee: d = -1/phi, not unitary),
each with the off-diagonal entry's sign free (the gauge left over: u^{tt}_t -> i u^{tt}_t
changes it).  Z2: omega = F^{sss}_s = +-1.
"""
import itertools
import sys

import sympy as sp


def unknowns(labels, N):
    """{(a,b,c,d,e,f): symbol or 1} for every allowed F-symbol."""
    one, F = labels[0], {}
    for a, b, c, d, e, f in itertools.product(labels, repeat=6):
        if N(a, b, e) and N(e, c, d) and N(b, c, f) and N(a, f, d):
            F[(a, b, c, d, e, f)] = 1 if one in (a, b, c) else sp.Symbol(f'F{a}{b}{c}{d}_{e}{f}')
    return F


def pentagon_equations(labels, F):
    g = lambda *k: F.get(k, 0)
    eqs = set()
    for a, b, c, d, e, f, gg, k, l in itertools.product(labels, repeat=9):
        ex = sp.expand(g(f, c, d, e, gg, l) * g(a, b, l, e, f, k)
                       - sum(g(a, b, c, gg, f, h) * g(a, h, d, e, gg, k) * g(b, c, d, k, h, l)
                             for h in labels))
        if ex != 0:
            eqs.add(ex)
    return sorted(eqs, key=sp.default_sort_key)


def solve(labels, N, gauge):
    """All solutions of the pentagon plus the gauge conditions gauge(F) (a list of
    expressions set to zero), and F invertible (each 1x1 block non-zero)."""
    F = unknowns(labels, N)
    syms = sorted({s for s in F.values() if isinstance(s, sp.Symbol)}, key=str)
    eqs = pentagon_equations(labels, F) + list(gauge(F))
    sols = sp.solve(eqs, syms, dict=True)
    # discard solutions where some 1x1 F-block vanishes (F must be invertible)
    blocks = {}
    for (a, b, c, d, e, f), v in F.items():
        blocks.setdefault((a, b, c, d), []).append(v)
    ok = []
    for s in sols:
        if all(not (len(vs) == 1 and sp.simplify(sp.sympify(vs[0]).subs(s)) == 0)
               for vs in blocks.values()):
            ok.append(s)
    return F, ok


def fibonacci():
    L = ['1', 't']
    N = lambda a, b, c: int(c == b) if a == '1' else int(c == a) if b == '1' else int((a, b) == ('t', 't'))
    gauge = lambda F: [F[('t', 't', 't', 't', '1', 't')] - F[('t', 't', 't', 't', 't', '1')]]
    return L, N, gauge


def z2():
    L = ['1', 's']
    N = lambda a, b, c: int(c == b) if a == '1' else int(c == a) if b == '1' else int(c == '1')
    return L, N, lambda F: []


def main(test=False):
    phi = (1 + sp.sqrt(5)) / 2
    L, N, gauge = fibonacci()
    F, sols = solve(L, N, gauge)
    x = sp.Symbol('Ftttt_11')
    vals = sorted({sp.nsimplify(sp.simplify(s[x])) for s in sols}, key=lambda v: float(v))
    if not test:
        print(f'Fibonacci: {len(sols)} solutions in the symmetric gauge')
        for s in sols:
            print('   ', {k: sp.simplify(v) for k, v in s.items()})
    L2, N2, g2 = z2()
    F2, sols2 = solve(L2, N2, g2)
    w = sorted(sp.simplify(s[sp.Symbol('Fssss_11')]) for s in sols2)
    if not test:
        print(f'Z2: omega = F^sss_s in {w}')
        return True
    checks = [
        ('L6 Fibonacci pentagon: 4 solutions in the symmetric gauge', len(sols) == 4),
        ('L6 Fibonacci [F^ttt_t]_11 in {-phi, 1/phi} (Yang-Lee, unitary)',
         [sp.simplify(v - t) for v, t in zip(vals, [-phi, 1 / phi])] == [0, 0]),
        ('L6 Fibonacci F^ttt_1 = 1 in every solution',
         all(sp.simplify(s[sp.Symbol('Fttt1_tt')] - 1) == 0 for s in sols)),
        ('L6 Z2 pentagon: omega = +-1', w == [-1, 1]),
    ]
    for label, ok in checks:
        print(('ok    ' if ok else 'FAIL  ') + label)
    return all(ok for _, ok in checks)


if __name__ == '__main__':
    raise SystemExit(0 if main(test='--test' in sys.argv) else 1)
