"""Multiplicity-free anyon models and the checks of the notation bible, K5 and K13-K17.

One shared module for scripts/check-syllabus-formulas.py, scripts/pentagon.py and the
lectures' algebra scripts.  Conventions are the bible's, with Bonderson's equation numbers:

  F   [F^{abc}_d]_{ef}: the tree ((ab)_e c)_d equals sum_f F_{ef} times (a(bc)_f)_d   (K13, B2.16)
  R   c_{a,b} psi^{ab}_c = R^{ab}_c psi^{ba}_c                                     (K14, B2.54)
  kappa_a = d_a [F^{a abar a}_a]_{11}                                              (K16, B2.23)
  theta_a = d_a^{-1} sum_c N_{aa}^c d_c R^{aa}_c                                   (K14, B2.61)
  S_ab = (dim C)^{-1/2} sum_c N_{a bbar}^c d_c theta_c / (theta_a theta_b)          (K17, Kitaev eq. 223)

Every value is a complex float; comparisons use TOL.  Run as a script for the self-test,
which includes must-fail controls (a wrong sign must be caught).
"""
import cmath
import itertools
import math

import numpy as np

TOL = 1e-10
PHI = (1 + 5 ** 0.5) / 2


class Model:
    """labels, fusion N(a,b,c) in {0,1}, F(a,b,c,d,e,f), R(a,b,c), d[a], dual[a]."""

    def __init__(self, name, labels, fusion, F, R, d, dual=None):
        self.name, self.L, self._N, self._F, self._R = name, list(labels), fusion, F, R
        self.d = d
        self.dual = dual or {a: a for a in labels}

    def N(self, a, b, c):
        if a == self.L[0]:
            return int(b == c)
        if b == self.L[0]:
            return int(a == c)
        return int(self._N(a, b, c))

    def F(self, a, b, c, d, e, f):
        if not (self.N(a, b, e) and self.N(e, c, d) and self.N(b, c, f) and self.N(a, f, d)):
            return 0.0
        if self.L[0] in (a, b, c):
            return 1.0
        return self._F(a, b, c, d, e, f)

    def R(self, a, b, c):
        if not self.N(a, b, c):
            return 0.0
        if self.L[0] in (a, b):
            return 1.0
        return self._R(a, b, c)

    # ---- derived data -------------------------------------------------------------
    def kappa(self, a):
        one = self.L[0]
        return self.d[a] * self.F(a, self.dual[a], a, a, one, one)

    def theta(self, a):
        return sum(self.N(a, a, c) * self.d[c] * self.R(a, a, c) for c in self.L) / self.d[a]

    def gdim(self):
        return sum(self.d[a] ** 2 for a in self.L)

    def S(self):
        D = self.gdim() ** 0.5
        th = {a: self.theta(a) for a in self.L}
        return np.array([[sum(self.N(a, self.dual[b], c) * self.d[c] * th[c] for c in self.L) / (th[a] * th[b] * D)
                          for b in self.L] for a in self.L])

    def T(self):
        return np.diag([self.theta(a) for a in self.L])

    def central_charge(self):
        """c mod 8 from the Gauss sum (K17)."""
        g = sum(self.d[a] ** 2 * self.theta(a) for a in self.L) / self.gdim() ** 0.5
        return (cmath.phase(g) / (2 * math.pi) * 8) % 8

    # ---- the axioms ---------------------------------------------------------------
    def pentagon_defect(self):
        """max |lhs - rhs| of B2.77 over all labels."""
        L, F, worst = self.L, self.F, 0.0
        for a, b, c, d, e, f, g, l, k in itertools.product(L, repeat=9):
            lhs = F(f, c, d, e, g, l) * F(a, b, l, e, f, k)
            rhs = sum(F(a, b, c, g, f, h) * F(a, h, d, e, g, k) * F(b, c, d, k, h, l) for h in L)
            worst = max(worst, abs(lhs - rhs))
        return worst

    def hexagon_defect(self, swapped=False):
        """max defect of the hexagons B2.57-B2.58 (K14).  swapped=True tests instead
        Bonderson's printed (2.78)-(2.79) pattern (draft 1's "every R inverted"), which
        holds only where R^{ab} = R^{ba}: a must-fail control in a non-symmetric gauge."""
        L, F, R, worst = self.L, self.F, self.R, 0.0
        inv = lambda z: 0 if z == 0 else 1 / z
        for a, b, c, d, e, g in itertools.product(L, repeat=6):
            lhs = R(c, a, e) * F(a, c, b, d, e, g) * R(c, b, g)
            rhs = sum(F(c, a, b, d, e, f) * R(c, f, d) * F(a, b, c, d, f, g) for f in L)
            if swapped:
                lhs2 = inv(R(c, a, e)) * F(a, c, b, d, e, g) * inv(R(c, b, g))
                rhs2 = sum(F(c, a, b, d, e, f) * inv(R(c, f, d)) * F(a, b, c, d, f, g) for f in L)
            else:
                lhs2 = inv(R(a, c, e)) * F(a, c, b, d, e, g) * inv(R(b, c, g))
                rhs2 = sum(F(c, a, b, d, e, f) * inv(R(f, c, d)) * F(a, b, c, d, f, g) for f in L)
            worst = max(worst, abs(lhs - rhs), abs(lhs2 - rhs2))
        return worst

    def ribbon_defect(self):
        """R^{ab}_c R^{ba}_c = theta_c / (theta_a theta_b)   (B2.60)."""
        th = {a: self.theta(a) for a in self.L}
        return max(abs(self.R(a, b, c) * self.R(b, a, c) - th[c] / (th[a] * th[b]))
                   for a, b, c in itertools.product(self.L, repeat=3) if self.N(a, b, c))

    def theta_two_ways_defect(self):
        """theta_a = kappa_a (R^{abar a}_1)^*   (B2.61)."""
        one = self.L[0]
        return max(abs(self.theta(a) - self.kappa(a) * np.conj(self.R(self.dual[a], a, one)))
                   for a in self.L)

    def dual_vertex_moduli(self):
        """|A^{ab}_c| and |B^{ab}_c| (K5, B2.30-B2.31): all should be 1."""
        one, out = self.L[0], []
        for a, b, c in itertools.product(self.L, repeat=3):
            if self.N(a, b, c):
                ab = self.dual[a]
                A = (self.d[a] * self.d[b] / self.d[c]) ** 0.5 * np.conj(self.kappa(a)) \
                    * np.conj(self.F(ab, a, b, b, one, c))
                B = (self.d[a] * self.d[b] / self.d[c]) ** 0.5 * self.F(a, b, self.dual[b], a, c, one)
                out += [abs(A), abs(B)]
        return out

    def gauged(self, u):
        """The model in the new basis, old vertex = u[(a,b,c)] * new vertex (K15, B2.80-81)."""
        F0, R0 = self._F, self._R
        g = lambda a, b, c: u.get((a, b, c), 1.0)
        F = lambda a, b, c, d, e, f: g(a, f, d) * g(b, c, f) / (g(a, b, e) * g(e, c, d)) * F0(a, b, c, d, e, f)
        R = lambda a, b, c: g(b, a, c) / g(a, b, c) * R0(a, b, c)
        return Model(self.name + ' (gauged)', self.L, self._N, F, R, self.d, self.dual)


# ---- the course's models ---------------------------------------------------------------
def fibonacci(chirality=+1):
    """Fibonacci in Bonderson's gauge; chirality -1 is the complex conjugate (K14)."""
    Ft = np.array([[1 / PHI, PHI ** -0.5], [PHI ** -0.5, -1 / PHI]])
    R = {('t', 't', '1'): cmath.exp(-4j * math.pi / 5 * chirality),
         ('t', 't', 't'): cmath.exp(3j * math.pi / 5 * chirality)}
    return Model('Fibonacci', ['1', 't'], lambda a, b, c: True,
                 lambda a, b, c, d, e, f: Ft['1t'.index(e), '1t'.index(f)] if d == 't' else 1.0,
                 lambda a, b, c: R[(a, b, c)], {'1': 1.0, 't': PHI})


def ising(nu=1, kappa=None):
    """Ising-type: F^{sss}_s = kappa H; R from Kitaev Table 1 with odd nu.
    kappa defaults to (-1)^((nu^2-1)/8) (K10); passing the other sign gives a model that
    must FAIL the hexagons (a control)."""
    if kappa is None:
        kappa = (-1) ** ((nu * nu - 1) // 8)
    fuse = {('s', 's'): {'1', 'p'}, ('s', 'p'): {'s'}, ('p', 's'): {'s'}, ('p', 'p'): {'1'}}
    H = np.array([[1, 1], [1, -1]]) / 2 ** 0.5

    def F(a, b, c, d, e, f):
        if (a, b, c, d) == ('s', 's', 's', 's'):
            return kappa * H['1p'.index(e), '1p'.index(f)]
        if (a, b, c, d) in {('s', 'p', 's', 'p'), ('p', 's', 'p', 's')}:
            return -1.0
        return 1.0
    w = cmath.exp(1j * math.pi * nu / 8)
    R = {('s', 's', '1'): kappa / w, ('s', 's', 'p'): kappa * w ** 3,
         ('s', 'p', 's'): (-1j) ** nu, ('p', 's', 's'): (-1j) ** nu, ('p', 'p', '1'): -1.0}
    return Model(f'Ising nu={nu} kappa={kappa:+d}', ['1', 's', 'p'], lambda a, b, c: c in fuse[(a, b)],
                 F, lambda a, b, c: R[(a, b, c)], {'1': 1.0, 's': 2 ** 0.5, 'p': 1.0})


def pointed_z2(omega=1, c_ss=1):
    """Vec_Z2^omega with the braiding c(s,s): omega = -1 with c = +-i is the (anti)semion;
    omega = +1 with c = +-1 is the boson / the fermion (sVec)."""
    return Model(f'Z2 omega={omega} c={c_ss}', ['1', 's'], lambda a, b, c: c == '1',
                 lambda a, b, c, d, e, f: omega, lambda a, b, c: c_ss, {'1': 1.0, 's': 1.0})


def toric_code():
    """Z(Vec_Z2): labels 1, e, m, eps = (charge, flux); trivial F;
    c_{(a1,b1),(a2,b2)} = (-1)^{b1 a2}, so theta_e = theta_m = 1, theta_eps = -1."""
    lab = {'1': (0, 0), 'e': (1, 0), 'm': (0, 1), 'x': (1, 1)}
    inv = {v: k for k, v in lab.items()}
    prod = lambda a, b: inv[((lab[a][0] + lab[b][0]) % 2, (lab[a][1] + lab[b][1]) % 2)]
    return Model('toric code', ['1', 'e', 'm', 'x'], lambda a, b, c: prod(a, b) == c,
                 lambda *x: 1.0, lambda a, b, c: (-1) ** (lab[a][1] * lab[b][0]),
                 {k: 1.0 for k in lab})


def double_z3():
    """Z(Vec_Z3), the Z3 toric code: labels (g, r) = (flux, charge), trivial F,
    R^{(g,r),(h,s)} = zeta^{g s}, so theta_(g,r) = zeta^{g r}.  Non-self-dual: the
    regression case for the S/T convention (bible review r1, codex finding 2)."""
    z = cmath.exp(2j * math.pi / 3)
    L = [f'{g}{r}' for g in range(3) for r in range(3)]
    add = lambda a, b: f'{(int(a[0]) + int(b[0])) % 3}{(int(a[1]) + int(b[1])) % 3}'
    dual = {a: f'{-int(a[0]) % 3}{-int(a[1]) % 3}' for a in L}
    return Model('Z(Vec_Z3)', L, lambda a, b, c: add(a, b) == c, lambda *x: 1.0,
                 lambda a, b, c: z ** (int(a[0]) * int(b[1])), {a: 1.0 for a in L}, dual)


# ---- self-test --------------------------------------------------------------------------
def _self_test():
    fails = []

    def ok(label, cond):
        print(('ok    ' if cond else 'FAIL  ') + label)
        if not cond:
            fails.append(label)

    for m in [fibonacci(), fibonacci(-1), ising(1), pointed_z2(-1, 1j), toric_code()]:
        ok(f'{m.name}: pentagon', m.pentagon_defect() < TOL)
        ok(f'{m.name}: hexagons', m.hexagon_defect() < TOL)
        ok(f'{m.name}: ribbon', m.ribbon_defect() < TOL)
        ok(f'{m.name}: theta two ways', m.theta_two_ways_defect() < TOL)
        ok(f'{m.name}: |A| = |B| = 1', all(abs(x - 1) < TOL for x in m.dual_vertex_moduli()))
        S = m.S()
        ok(f'{m.name}: S unitary and symmetric', np.allclose(S @ S.conj().T, np.eye(len(m.L)))
           and np.allclose(S, S.T))
    # controls: each must be detected
    ok('control: Ising nu=1 with kappa=-1 fails the hexagons', ising(1, kappa=-1).hexagon_defect() > 1e-3)
    bad = fibonacci()
    bad._R = lambda a, b, c: {('t', 't', '1'): cmath.exp(4j * math.pi / 5),
                              ('t', 't', 't'): cmath.exp(3j * math.pi / 5)}[(a, b, c)]
    ok('control: Fibonacci with one R conjugated fails the hexagons', bad.hexagon_defect() > 1e-3)
    ok('control: Z2 omega=-1 with c=1 fails the hexagons', pointed_z2(-1, 1).hexagon_defect() > 1e-3)
    print(f'{len(fails)} failure(s)' if fails else 'anyons.py self-test passed')
    return not fails


if __name__ == '__main__':
    raise SystemExit(0 if _self_test() else 1)
