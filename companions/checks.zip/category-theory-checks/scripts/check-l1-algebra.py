"""Algebra script for Lecture 1, *Categories: a theory of systems and processes*.

Every formula, number and diagram equation that lectures/lec01.tex prints is checked here
before it is printed, labelled SYMBOLIC (sympy, generic entries), EXACT (integers, exact
permutation matrices), NUMERICAL (floating point on fixed or random instances).  A diagram
equation is checked as an equation between composites of matrices, read with time running
upward (Bible K1): a chain of boxes f, then g, then h, from the bottom, is h @ g @ f.  The
three diagram equations of L1 are exact equalities, with no scalar.

The running example is S3 acting on C^3 by permuting coordinates (Symmetries L1, L3):
rho(s) e_i = e_{s(i)}.  Permutations compose as functions, (s t)(i) = s(t(i)), so t acts
first; as strands (Symmetries lec01.tex:541-550) t is the lower layer.

Labels are the lecture's \\label{} keys (a parenthesis names the item within it).  A check
tests a printed claim on instances: exhaustively over S3, symbolically for generic entries
of fixed shapes, or on random samples.  It does not prove a general quantifier (the
lecture's proofs do that), and it does not parse the TeX.  Most checks carry a control that
must fail, so that a check which cannot fail is visible.  Not checked here: the citations
(checked against the PDFs) and the two pictures without equations (the braid and the pair
of pants), apart from the permutation the braid is said to induce.

Run:  python3 scripts/check-l1-algebra.py     (exit status 1 on failure)
"""
import itertools
import sys

import numpy as np
import sympy as sp

FAILS = []
RNG = np.random.default_rng(20261021)


def check(label, kind, ok, what):
    print(f"{'OK  ' if ok else 'FAIL'} [{kind:9s}] {label}: {what}")
    if not ok:
        FAILS.append(label)


def control(label, kind, failed, what):
    """A must-fail control: `failed` is True when the wrong statement is indeed refuted."""
    check(label + ' (control)', kind, failed, what + ' -- must fail, and does')


def crandn(*shape):
    return RNG.standard_normal(shape) + 1j * RNG.standard_normal(shape)


def close(a, b, tol=1e-10):
    return np.allclose(a, b, atol=tol, rtol=0)


# ================================================================ S3 and its representation
S3 = list(itertools.permutations(range(3)))           # s as the tuple (s(0), s(1), s(2))
ONE = (0, 1, 2)


def compose(s, t):
    """s o t: t first, then s."""
    return tuple(s[t[i]] for i in range(3))


def inverse(s):
    r = [0] * 3
    for i, si in enumerate(s):
        r[si] = i
    return tuple(r)


def rho(s):
    """rho(s) e_i = e_{s(i)}: the permutation matrix with column i equal to e_{s(i)}."""
    M = sp.zeros(3, 3)
    for i in range(3):
        M[s[i], i] = 1
    return M


def transposition(i, j):
    t = list(range(3))
    t[i], t[j] = t[j], t[i]
    return tuple(t)


# ===================================================================== S1.2 categories
# eq:1:chain -- a chain of boxes f, g, h (time upward) is one morphism: h(gf) = (hg)f.
f, g, h = crandn(3, 2), crandn(4, 3), crandn(2, 4)
check('eq:1:chain', 'NUMERICAL', close(h @ (g @ f), (h @ g) @ f),
      'the chain f, g, h from the bottom: h o (g o f) = (h o g) o f, as matrices 2x2')
check('eq:1:chain(units)', 'NUMERICAL', close(np.eye(3) @ f, f) and close(f @ np.eye(2), f),
      'an identity box may be erased: id o f = f = f o id')
fs, gs, hs = crandn(2, 2), crandn(2, 2), crandn(2, 2)
control('eq:1:chain(order)', 'NUMERICAL', not close(hs @ gs @ fs, fs @ gs @ hs),
        'reading the chain downward (f o g o h instead of h o g o f, square matrices)')

# ex:1:categories(BG) -- the group axioms of S3 are the category axioms of BS3.
assoc = all(compose(a, compose(b, c)) == compose(compose(a, b), c)
            for a in S3 for b in S3 for c in S3)
units = all(compose(a, ONE) == a == compose(ONE, a) for a in S3)
check('ex:1:categories(BG)', 'EXACT', assoc and units,
      'BS3: composition g o h = gh is associative with identity 1 (all 6^3 triples)')
check('def:1:iso(BG)', 'EXACT', all(compose(a, inverse(a)) == ONE == compose(inverse(a), a) for a in S3),
      'BS3 is a groupoid: every g has the inverse g^{-1}')

# ex:1:categories(Rep) -- intertwiners compose.
a_, b_, c_, d_ = sp.symbols('a b c d')
J3 = sp.ones(3, 3)
xi_gen = a_ * sp.eye(3) + b_ * J3                      # the generic intertwiner C^3 -> C^3
eta_gen = c_ * sp.eye(3) + d_ * J3
ok = all(sp.simplify(xi_gen * rho(s) - rho(s) * xi_gen) == sp.zeros(3, 3) for s in S3)
ok2 = all(sp.simplify(eta_gen * xi_gen * rho(s) - rho(s) * eta_gen * xi_gen) == sp.zeros(3, 3)
          for s in S3)
check('ex:1:categories(Rep)', 'SYMBOLIC', ok and ok2,
      'a I + b J intertwines rho with itself, and so does the composite of two such')

# ex:1:categories(braid) and ex:1:functors(braid) -- the drawn braid: a crossing of strands
# 1, 2 at the bottom, then of strands 2, 3; the strand starting at i ends at pi(i).
tau1, tau2 = transposition(0, 1), transposition(1, 2)
pi = compose(tau2, tau1)                               # tau1 first (lower layer)
check('ex:1:functors(braid)', 'EXACT', pi == (2, 0, 1),
      'the braid induces 1 -> 3, 2 -> 1, 3 -> 2, the permutation tau2 tau1 = (1 3 2)')
control('ex:1:functors(braid order)', 'EXACT', compose(tau1, tau2) != (2, 0, 1),
        'stacking in the other order, tau1 tau2, gives a different permutation')

# def:1:iso -- the inverse is unique: if g and h are both two-sided inverses of f, then
# h = h o (f o g) = (h o f) o g = g.  Here g is computed as a right inverse (solve f g = I)
# and h as a left inverse (solve h f = I, transposed), independently, and every step of
# the printed chain is compared.
fi = crandn(3, 3)
gi = np.linalg.solve(fi, np.eye(3))                    # f g = I
hi = np.linalg.solve(fi.T, np.eye(3)).T                # h f = I
steps = [hi, hi @ (fi @ gi), (hi @ fi) @ gi, gi]
check('def:1:iso(unique)', 'NUMERICAL', all(close(x, y) for x, y in zip(steps, steps[1:])),
      'h = h o (f o g) = (h o f) o g = g, each step')
fd = np.diag([2.0, 3.0, 5.0])
bad_steps = [np.eye(3), np.eye(3) @ (fd @ np.eye(3)), (np.eye(3) @ fd) @ np.eye(3), np.eye(3)]
control('def:1:iso(unique)', 'NUMERICAL', not all(close(x, y) for x, y in zip(bad_steps, bad_steps[1:])),
        'the chain with g = h = id for f = diag(2, 3, 5), which is not their inverse')

# ======================================================================= S1.3 functors
# ex:1:functors(dual) -- (g o f)* = f* o g*: in dual bases the dual map is the transpose
# (Linear Algebra prop:dualtranspose), so the claim is (GF)^T = F^T G^T.
F_ = sp.Matrix(3, 2, sp.symbols('f0:6'))
G_ = sp.Matrix(2, 3, sp.symbols('g0:6'))
check('ex:1:functors(dual)', 'SYMBOLIC', sp.simplify((G_ * F_).T - F_.T * G_.T) == sp.zeros(2, 2),
      '(g o f)* = f* o g*: the dual reverses composition (contravariant)')
Fq = sp.Matrix(2, 2, sp.symbols('m0:4'))
Gq = sp.Matrix(2, 2, sp.symbols('n0:4'))
control('ex:1:functors(dual covariant)', 'SYMBOLIC',
        sp.simplify((Gq * Fq).T - Gq.T * Fq.T) != sp.zeros(2, 2),
        '(g o f)* = g* o f* for square f, g (where both sides are defined)')
# the dual as a functor on functionals, without bases: f*(phi) = phi o f
phi = crandn(1, 2)
fv, gv = crandn(2, 3), crandn(2, 2)                    # f: C^3 -> C^2, g: C^2 -> C^2
star = lambda m: (lambda p: p @ m)                     # noqa: E731  f*(phi) = phi o f
check('ex:1:functors(dual, functionals)', 'NUMERICAL', close(star(gv @ fv)(phi), star(fv)(star(gv)(phi))),
      '(g o f)*(phi) = phi o g o f = f*(g*(phi)) on a sample')

# lem:1:iso -- functors preserve isomorphisms: F(f^{-1}) = F(f)^{-1}; for BG -> Vect_fd,
# every rho(g) is invertible with rho(g^{-1}) = rho(g)^{-1}.
check('lem:1:iso', 'EXACT', all(rho(inverse(s)) * rho(s) == sp.eye(3) for s in S3),
      'rho(g^{-1}) rho(g) = id for every g in S3')

# =========================================== S1.4 natural transformations; Rep = Fun(BG, Vect)
# thm:1:repfun -- the functor axioms are the homomorphism axioms.
check('thm:1:repfun(functor)', 'EXACT',
      all(rho(compose(s, t)) == rho(s) * rho(t) for s in S3 for t in S3) and rho(ONE) == sp.eye(3),
      'rho(gh) = rho(g) rho(h) and rho(1) = id: rho is a functor BS3 -> Vect_fd')
wrong = lambda s: rho(s).T                             # noqa: E731  the transpose reverses order
control('thm:1:repfun(functor)', 'EXACT',
        not all(wrong(compose(s, t)) == wrong(s) * wrong(t) for s in S3 for t in S3),
        's -> rho(s)^T as a covariant functor')

# ex:1:s3 -- the sum s: C^3 -> C (trivial representation) is natural; p_1 is not.
s_map = sp.Matrix([[1, 1, 1]])
p1 = sp.Matrix([[1, 0, 0]])
u_map = sp.Matrix([1, 1, 1])
triv = lambda s: sp.Matrix([[1]])                      # noqa: E731
check('ex:1:s3(sum)', 'EXACT', all(triv(t) * s_map == s_map * rho(t) for t in S3),
      's(rho(g) x) = s(x): the sum is a natural transformation rho => trivial')
check('ex:1:s3(u)', 'EXACT', all(rho(t) * u_map == u_map * triv(t) for t in S3),
      'u(1) = e1 + e2 + e3 is natural trivial => rho')
check('ex:1:s3(composite)', 'EXACT', u_map * s_map == J3 and all(J3 * rho(t) == rho(t) * J3 for t in S3),
      'u o s = J (every entry 1), and J commutes with every permutation matrix')
t12 = transposition(0, 1)
e1 = sp.Matrix([1, 0, 0])
check('ex:1:s3(p1)', 'EXACT', (p1 * rho(t12) * e1)[0, 0] == 0 and (p1 * e1)[0, 0] == 1,
      'p1(rho((1 2)) e1) = p1(e2) = 0, but p1(e1) = 1: p1 is not natural')

# eq:1:naturality and eq:1:vertical -- the sliding pictures with three different functors
# BS3 -> Vect_fd: F = rho on C^3, F' = the trivial representation on C, F'' = P rho P^{-1} on
# C^3 for a fixed non-monomial P, so F'' != F (C.3-L01 round 2); xi = s : F => F' (the sum)
# and zeta = P u : F' => F''.  For every g in S3,
#   F(g), xi, zeta (bottom to top)  =  xi, F'(g), zeta  =  xi, zeta, F''(g).
Pm = sp.Matrix([[1, 1, 0], [0, 1, 1], [1, 0, 2]])
rho2 = lambda t: Pm * rho(t) * Pm.inv()              # noqa: E731  F''
zeta = Pm * u_map
check('eq:1:naturality', 'EXACT', all(triv(t) * s_map == s_map * rho(t) for t in S3)
      and all(rho2(t) * zeta == zeta * triv(t) for t in S3),
      "F'(g) o xi = xi o F(g) for xi = s, and F''(g) o zeta = zeta o F'(g) for zeta = P u")
check("eq:1:naturality(F'' != F)", 'EXACT', any(rho2(t) != rho(t) for t in S3),
      "F'' = P rho P^{-1} is a different functor from F")
ok = True
for t in S3:
    left = zeta * s_map * rho(t)                       # F(g), then xi, then zeta
    mid = zeta * triv(t) * s_map                       # xi, then F'(g), then zeta
    right = rho2(t) * zeta * s_map                     # xi, zeta, then F''(g)
    ok &= left == mid == right
check('eq:1:vertical', 'EXACT', ok, "the two slides: zeta xi F(g) = zeta F'(g) xi = F''(g) zeta xi, all g in S3")
control('eq:1:vertical(top box)', 'EXACT',
        any(rho(t) * zeta * s_map != zeta * s_map * rho(t) for t in S3),
        "with F(g) instead of F''(g) in the top box of the right-hand picture, the pictures agree")
check('eq:1:vertical(composite)', 'EXACT', all(rho2(t) * zeta * s_map == zeta * s_map * rho(t) for t in S3),
      "the composite zeta o xi = P u s is natural from F to F''")
bad = sp.diag(1, 2, 3)
control('eq:1:vertical', 'EXACT',
        any(zeta * s_map * bad * rho(t) != rho2(t) * zeta * s_map * bad for t in S3),
        'with xi replaced by s o diag(1, 2, 3), not natural, the outer pictures agree')

# ======================================================== S1.5 equivalence; V** vs V*
# thm:1:doubledual(a) -- a_V(v)(phi) = phi(v) is natural: f**(a_V(v)) = a_W(f(v)).
n, m = 3, 2
fm = crandn(m, n)                                      # f: V = C^3 -> W = C^2
v = crandn(n, 1)
a_V = lambda vec: (lambda functional: (functional @ vec)[0, 0])   # noqa: E731
fstar = lambda psi: psi @ fm                           # noqa: E731  f*: W* -> V*
fss = lambda x: (lambda psi: x(fstar(psi)))           # noqa: E731  f**(x) = x o f*
ok = True
for _ in range(5):
    psi = crandn(1, m)
    ok &= abs(fss(a_V(v))(psi) - a_V(fm @ v)(psi)) < 1e-10
check('thm:1:doubledual(a)', 'NUMERICAL', ok,
      'f**(a_V(v))(psi) = psi(f(v)) = a_W(f(v))(psi) on samples')

# thm:1:doubledual(b) -- for f = i id_V, f* theta f = i^2 theta = -theta for every linear theta.
k = 3
Theta = sp.Matrix(k, k, sp.symbols('t0:9'))            # the matrix of theta: V -> V* in dual bases
fI = sp.I * sp.eye(k)
check('thm:1:doubledual(b)', 'SYMBOLIC', sp.simplify(fI.T * Theta * fI + Theta) == sp.zeros(k, k),
      'f = i id: f* o theta o f = -theta, so naturality forces theta = 0')
control('thm:1:doubledual(b) with f = -id', 'SYMBOLIC',
        sp.simplify((-sp.eye(k)).T * Theta * (-sp.eye(k)) + Theta) != sp.zeros(k, k),
        'f = -id refutes nothing (f* theta f = theta), which is why the proof takes i')
# the same with the naturality square written as theta_W o f = (f*)^{-1} o theta_V
check('thm:1:doubledual(b, square)', 'SYMBOLIC',
      sp.simplify(Theta * fI - (fI.T).inv() * Theta - 2 * sp.I * Theta) == sp.zeros(k, k),
      'theta o f - (f*)^{-1} o theta = i theta + i theta = 2i theta for f = i id')
# D(f) = (f*)^{-1} is covariant on isomorphisms: ((g f)*)^{-1} = (g*)^{-1} (f*)^{-1}.
P_ = sp.Matrix(2, 2, sp.symbols('p0:4'))
Q_ = sp.Matrix(2, 2, sp.symbols('q0:4'))
check('thm:1:doubledual(D covariant)', 'SYMBOLIC',
      sp.simplify(((Q_ * P_).T).inv() - (Q_.T).inv() * (P_.T).inv()) == sp.zeros(2, 2),
      'V -> V*, f -> (f*)^{-1} is a covariant functor on isomorphisms')

# ex:1:basis -- the basis 2 e_i turns theta (e_i -> e^i) into theta / 4.  theta' sends
# e'_i = 2 e_i to e'^i = e^i / 2; its matrix in the original dual bases:
Bp = 2 * sp.eye(k)                                     # columns: the new basis in the old
dual_new = (Bp.inv()).T                                # columns: e'^i in the old dual basis
theta_new = dual_new * Bp.inv()                        # theta'(x) = sum_i x'^i e'^i
check('ex:1:basis', 'EXACT', theta_new == sp.eye(k) / 4,
      "with the basis 2 e_i the isomorphism e_i -> e^i becomes theta / 4")
theta_wrong = Bp.inv()                                 # forgets that the dual basis scales
control('ex:1:basis', 'EXACT', theta_wrong != sp.eye(k) / 4,
        "the model that rescales the basis but keeps e^i as the dual basis gives theta / 4")

# guard:1:riesz -- R(u) = <u, .> (antilinear in the first slot, Bible Q1) satisfies
# f* R(f u) = R(u) for unitary f, and R(i u) = -i R(u).
R = lambda u: (lambda w: (u.conj().T @ w)[0, 0])       # noqa: E731
Uq, _ = np.linalg.qr(crandn(3, 3))
u, w = crandn(3, 1), crandn(3, 1)
check('guard:1:riesz(unitary)', 'NUMERICAL', abs(R(Uq @ u)(Uq @ w) - R(u)(w)) < 1e-10,
      'f* R_W(f u) = R_V(u): <f u, f w> = <u, w> for unitary f')
check('guard:1:riesz(antilinear)', 'NUMERICAL', abs(R(1j * u)(w) - (-1j) * R(u)(w)) < 1e-10,
      'R(i u) = -i R(u)')
check('guard:1:riesz(f = i id)', 'NUMERICAL', abs(R(1j * u)(1j * w) - R(u)(w)) < 1e-10,
      'with f = i id: R(i u)(i w) = (-i)(i) R(u)(w) = R(u)(w), the test every linear theta fails')
Ainv = crandn(3, 3)
control('guard:1:riesz(invertible, not unitary)', 'NUMERICAL',
        abs(R(Ainv @ u)(Ainv @ w) - R(u)(w)) > 1e-6,
        'f* R(f u) = R(u) for an invertible f that is not unitary')

# thm:1:equiv -- M: Mat -> Vect_fd, with a chosen basis b_V for every V and G(f) = b_W^{-1} f b_V.
bV, bW, bX = crandn(3, 3), crandn(2, 2), crandn(4, 4)  # bases of V, W, X (invertible)
f_vw, g_wx = crandn(2, 3), crandn(4, 2)
Gm = lambda fm_, b_in, b_out: np.linalg.solve(b_out, fm_ @ b_in)   # noqa: E731
check('thm:1:equiv(G functor)', 'NUMERICAL',
      close(Gm(g_wx @ f_vw, bV, bX), Gm(g_wx, bW, bX) @ Gm(f_vw, bV, bW)),
      'G(g o f) = G(g) G(f): the bases cancel')
check('thm:1:equiv(natural)', 'NUMERICAL', close(f_vw @ bV, bW @ Gm(f_vw, bV, bW)),
      'f o b_V = b_W o MG(f): b is a natural isomorphism MG => id')
check('thm:1:equiv(GM = id)', 'NUMERICAL', close(Gm(f_vw, np.eye(3), np.eye(2)), f_vw),
      'with b = id on C^n, G(M(A)) = A')

# guard:1:isoequiv -- Mat is skeletal: a 2x3 A and a 3x2 B never give BA = I_3.
A_ = sp.Matrix(2, 3, sp.symbols('x0:6'))
B_ = sp.Matrix(3, 2, sp.symbols('y0:6'))
check('guard:1:isoequiv', 'SYMBOLIC', sp.expand((B_ * A_).det()) == 0,
      'det(BA) = 0 for every 3x2 B and 2x3 A, so m = n whenever m and n are isomorphic in Mat')
control('guard:1:isoequiv', 'SYMBOLIC', sp.expand((A_ * B_).det()) != 0,
        'det(AB) = 0 for the 2x2 product (it is not identically zero)')

print()
if FAILS:
    print(f'{len(FAILS)} FAILED: ' + ', '.join(FAILS))
    sys.exit(1)
print('All L1 checks pass.')
