"""Algebra script for Lecture 12, *Morita equivalence and the Drinfeld centre*.

This script checks, on instances, the dual category of the regular module (X -> (- (x) X)
reverses the tensor product, so g -> (- (x) g^{-1}) is a homomorphism; bible K21), the
half-braidings of Z(Vec_A^omega) solved from EGNO's hexagon (7.41) on simple objects,
Z(Vec_Z2) = the toric code with K21's labels e = (0, chi_-), m = (1, 1) and its S and T,
the double semion from omega(s,s,s) = -1, the e <-> m symmetry, the count of the simples of
Z(Vec_{S3}), and dim Z(Fib) = (dim Fib)^2 with c = 0 for Fib (x) Fib^rev.  Every check is
EXACT or NUMERICAL; some carry a control that must fail.

Run:  python3 scripts/check-l12-algebra.py     (exit status 1 on failure)
"""
import cmath
import itertools
import math
import pathlib
import sys

import numpy as np
import sympy as sp

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
import anyons  # noqa: E402

FAILS = []


def check(label, kind, ok, what):
    print(f"{'OK  ' if ok else 'FAIL'} [{kind:9s}] {label}: {what}")
    if not ok:
        FAILS.append(label)


def control(label, kind, failed, what):
    check(label + ' (control)', kind, failed, what + ' -- must fail, and does')


close = lambda a, b, tol=1e-9: np.allclose(a, b, atol=tol)                 # noqa: E731

# ================================================================ S12.1 the dual of the regular module
S3 = list(itertools.permutations(range(3)))
mul = lambda p, q: tuple(p[q[i]] for i in range(3))                       # (p q)(i) = p(q(i))
inv = lambda p: tuple(sorted(range(3), key=lambda i: p[i]))                # noqa: E731
act = lambda g: (lambda x: mul(x, g))                                     # noqa: E731  the functor - (x) g on simples
comp = lambda F, G_: (lambda x: F(G_(x)))                                 # noqa: E731  F (x) G = F o G (K21)
same = lambda F, G_: all(F(x) == G_(x) for x in S3)                       # noqa: E731
ok = all(same(comp(act(inv(g)), act(inv(h))), act(inv(mul(g, h)))) for g in S3 for h in S3)
check('thm:12:dual(regular)', 'EXACT', ok, 'S3: (- (x) g^{-1}) o (- (x) h^{-1}) = - (x) (gh)^{-1} on simple objects: g -> (- (x) g^{-1}) respects the tensor product')
control('thm:12:dual(regular)', 'EXACT', not all(same(comp(act(g), act(h)), act(mul(g, h))) for g in S3 for h in S3),
        'g -> (- (x) g) is monoidal for composition (it reverses the tensor product)')

# The inverse construction F_V(W) = V tensor W, s_g = rho(g)^(-1).
# Construct the evaluation map from the functor's action on basis-vector maps.
# Different bases at C, W=C^3 and W'=C^2 make naturality nontrivial.
P_v = sp.Matrix([[2, 1], [1, 1]])
P_vw = sp.eye(6)
P_vw[0, 5] = 2
P_vw[3, 1] = -1
P_vwp = sp.eye(4)
P_vwp[0, 2] = 3
P_vwp[3, 1] = -2
functor_bases = {1: P_v, 2: P_vwp, 3: P_vw}


def F_map(g):
    return (functor_bases[g.rows] * sp.kronecker_product(sp.eye(2), g)
            * functor_bases[g.cols].inv())


def evaluation_from_functor(n):
    return sp.Matrix.hstack(*(F_map(sp.eye(n)[:, j]) * sp.eye(2)[:, i]
                              for i in range(2) for j in range(n)))


eval_W, eval_Wp = evaluation_from_functor(3), evaluation_from_functor(2)
g_eval = sp.Matrix([[1, -1, 2], [0, 3, 1]])
w_eval, v_eval = sp.Matrix([1, 2, -1]), sp.Matrix([3, -2])
check('thm:12:dual(evaluation map)', 'EXACT',
      eval_W * sp.kronecker_product(v_eval, w_eval) == F_map(w_eval) * v_eval
      and eval_W.det() != 0 and eval_Wp.det() != 0
      and F_map(g_eval) * eval_W == eval_Wp * sp.kronecker_product(sp.eye(2), g_eval),
      'construct ev_W from F(f_ej)(e_i); it is invertible and natural for a nonidentity rectangular map W -> Wprime')
control('thm:12:dual(evaluation map)', 'EXACT',
        sp.kronecker_product(sp.eye(2), g_eval) * eval_W
        != eval_Wp * sp.kronecker_product(sp.eye(2), g_eval),
        'omit the functor basis conjugation in F(g) and retain naturality')
# Use S3's standard representation to detect reversing a noncommuting product.
basis = sp.Matrix([[1, 0], [-1, 1], [0, -1]])
rho = {}
for g in S3:
    perm = sp.zeros(3)
    for j in range(3):
        perm[g[j], j] = 1
    rho[g] = basis[:2, :].inv() * (perm * basis)[:2, :]
s = {g: rho[g].inv() for g in S3}
check('thm:12:dual(Vec)', 'EXACT',
      all(s[mul(g, h)] == s[h] * s[g] for g in S3 for h in S3)
      and all(sp.kronecker_product(s[g], s[g]).inv()
              == sp.kronecker_product(rho[g], rho[g]) for g in S3),
      'F_V(W) = V tensor W with s_g = rho(g)^(-1): module coherence reverses products; composition gives rho_V tensor rho_U')
control('thm:12:dual(Vec)', 'EXACT',
        any(s[mul(g, h)] != s[g] * s[h] for g in S3 for h in S3),
        'the module coherence is s_gh = s_g s_h for nonabelian G')
# Componentwise Deligne morphisms compose by the tensor product of maps.
A = sp.Matrix([[1, 2], [3, 1], [0, -1]])
B = sp.Matrix([[2, 1, 0], [-1, 0, 3]])
C = sp.Matrix([[1, -1], [0, 2]])
D = sp.Matrix([[3, 0], [1, -2]])
check('def:12:deligne(maps)', 'EXACT',
      sp.kronecker_product(B, D) * sp.kronecker_product(A, C)
      == sp.kronecker_product(B * A, D * C),
      'Deligne morphisms compose componentwise, with ordered tensor factors')


# ================================================================ S12.2-12.3 half-braidings of Z(Vec_A^omega), A abelian
def centre(A, add, omega):
    """Simple objects (g, gamma) of Z(Vec_A^omega): gamma_h is the scalar of h (x) g -> g (x) h, solving EGNO (7.41)
    on simples: gamma_{hk} = omega(h,k,g) gamma_k gamma_h omega(g,h,k) / omega(h,g,k), gamma_0 = 1.  Brute force over
    the roots of unity of order 4|A| (enough for the cases here)."""
    n = 4 * len(A)
    roots = [cmath.exp(2j * math.pi * r / n) for r in range(n)]
    out = []
    for g in A:
        for vals in itertools.product(roots, repeat=len(A) - 1):
            gam = dict(zip(A[1:], vals))
            gam[A[0]] = 1
            if all(abs(gam[add(h, k)] - omega(h, k, g) * gam[k] * gam[h] * omega(g, h, k) / omega(h, g, k)) < 1e-9
                   for h in A for k in A):
                out.append((g, gam))
    return out


Z2 = [0, 1]
add2 = lambda a, b: (a + b) % 2                                           # noqa: E731
one = lambda *x: 1                                                        # noqa: E731
semion_omega = lambda a, b, c: -1 if (a, b, c) == (1, 1, 1) else 1        # noqa: E731

TC = centre(Z2, add2, one)
theta = {(g, tuple(sorted(gam.items()))): gam[g] for g, gam in TC}          # c_{X,X} = gamma'_Z at Z = X: gamma_g
# label by K21: e = (0, chi_-), m = (1, 1), eps = (1, chi_-)
lab = {}
for g, gam in TC:
    chi_minus = abs(gam[1] + 1) < 1e-9
    lab[{(0, False): '1', (0, True): 'e', (1, False): 'm', (1, True): 'eps'}[(g, chi_minus)]] = (g, gam)
c = lambda X, Y: lab[Y][1][lab[X][0]]                                     # noqa: E731  c_{X,Y} = gamma^Y_{X}
ok = len(TC) == 4 and [round(c(a, a).real) for a in ('1', 'e', 'm', 'eps')] == [1, 1, 1, -1] \
    and abs(c('e', 'm') * c('m', 'e') + 1) < 1e-9 and abs(c('e', 'm') - 1) < 1e-9 and abs(c('m', 'e') + 1) < 1e-9
check('thm:12:toric', 'NUMERICAL', ok,
      'Z(Vec_Z2): four simples; theta = 1, 1, 1, -1 on 1, e, m, eps; c_{e,m} = 1, c_{m,e} = -1, double braiding -1 (Kong-Zhang Rem. 4.1.2)')
# its S and T against L10 (Kitaev's formula with these data) and the e <-> m symmetry
order = ['1', 'e', 'm', 'eps']
Sz = np.array([[c(b, a) * c(a, b) for b in order] for a in order]).conj() / 2   # abelian: S~_ab = conj of the double braiding of a, b
Stc = 0.5 * np.array([[1, 1, 1, 1], [1, 1, -1, -1], [1, -1, 1, -1], [1, -1, -1, 1]])
check('thm:12:toric(S)', 'NUMERICAL', close(Sz, Stc), 'the half-braidings give L10\'s toric S = (1/2)(+-1), sign by sign')
swap = [0, 2, 1, 3]
check('thm:12:toric(em)', 'NUMERICAL', close(Sz[np.ix_(swap, swap)], Sz) and [round(c(a, a).real) for a in ('1', 'm', 'e', 'eps')] == [1, 1, 1, -1],
      'e <-> m preserves S and T (necessary for the braided autoequivalence the lecture cites)')
control('thm:12:toric(em)', 'NUMERICAL', not (close(Sz[np.ix_([0, 3, 2, 1], [0, 3, 2, 1])], Sz) and c('e', 'e') == c('eps', 'eps')),
        'e <-> eps also preserves T')
DS = centre(Z2, add2, semion_omega)
ths = sorted((round((gam[g]).real, 6), round((gam[g]).imag, 6)) for g, gam in DS)
check('thm:12:toric(semion)', 'NUMERICAL', len(DS) == 4 and ths == sorted([(1, 0), (1, 0), (0, 1), (0, -1)]),
      'Z(Vec_Z2^omega), omega(s,s,s) = -1: four simples with theta = 1, 1, i, -i (the double semion)')
control('thm:12:toric(semion)', 'NUMERICAL', ths != sorted([(1, 0), (1, 0), (1, 0), (-1, 0)]), 'the twisted centre is again the toric code')

# ================================================================ S12.3 Z(Vec_G) for G = S3: (class, irrep of the centraliser)
classes = []
for g in S3:
    cl = frozenset(mul(mul(h, g), inv(h)) for h in S3)
    if cl not in classes:
        classes.append(cl)
count = 0
for cl in classes:
    g = next(iter(cl))
    C = [h for h in S3 if mul(h, g) == mul(g, h)]
    nclassesC = len({frozenset(mul(mul(h, x), inv(h)) for h in C) for x in C})   # number of irreps of C_G(g)
    count += nclassesC
check('thm:12:double(S3)', 'EXACT', count == 8, 'Z(Vec_{S3}): 3 + 2 + 3 = 8 simples (dim Z = |G|^2 is an identity, not checked)')
control('thm:12:double(S3)(printed trap)', 'EXACT', count != len(S3) * 3,
        'the labels are pairs (g, irrep of G): 6 x 3 = 18 (documents the trap the lecture prints)')
by_elements = 0                        # the trap: one simple per (element g, irrep of C_G(g))
for g in S3:
    C_ = [h for h in S3 if mul(h, g) == mul(g, h)]
    by_elements += len({frozenset(mul(mul(h, y), inv(h)) for h in C_) for y in C_})
control('thm:12:double(S3)', 'EXACT', by_elements != count,
        'the simples are pairs (g, irrep of C_G(g)) over elements g, not over classes (that gives 3 + 3x2 + 2x3 = 15)')

# ================================================================ S12.4 Z(Fib) = Fib (x) Fib^rev
fib = anyons.fibonacci()
phi = (1 + 5 ** 0.5) / 2
dimF = sum(fib.d[a] ** 2 for a in fib.L)
dims = [fib.d[a] * fib.d[b] for a in fib.L for b in fib.L]
thetas = [fib.theta(a) * np.conj(fib.theta(b)) for a in fib.L for b in fib.L]
gauss = sum(x ** 2 * t for x, t in zip(dims, thetas))
check('thm:12:muger(Fib)', 'NUMERICAL', abs(sum(x ** 2 for x in dims) - (2 + phi) ** 2) < 1e-9 and abs(gauss - dimF) < 1e-9,
      'Fib (x) Fib^rev: dim = (2 + phi)^2 = (dim Fib)^2, Gauss sum = dim Fib, so c = 0')
gauss_bad = sum(x ** 2 * fib.theta(a) * fib.theta(b) for x, (a, b) in zip(dims, itertools.product(fib.L, fib.L)))
control('thm:12:muger(Fib)', 'NUMERICAL', abs(gauss_bad - dimF) > 1e-6, 'Fib (x) Fib (not rev) also has c = 0')

print()
if FAILS:
    print(f'{len(FAILS)} FAILED: ' + ', '.join(FAILS))
    sys.exit(1)
print('All L12 checks pass.')
