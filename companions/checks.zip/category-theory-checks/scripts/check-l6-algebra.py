"""Algebra script for Lecture 6, *F-symbols and the pentagon* (begun for the costed passage).

L6 is written and closed (C.3 rounds 1-3).  Gate B asked for a costed passage of the densest stretch
(kickstart PROMPT S9, Phase 5); lectures/costed-L6.tex is about ten minutes of L6 S6.4,
"Fibonacci solved", and this script checks every equation it prints, labelled SYMBOLIC
(sympy) or EXACT.  Conventions: Bible K13 (F-symbols, rows the left tree's channel e,
columns the right tree's f; the pentagon B2.77), K15 (gauge), K11 (unitary data).

Notation of the passage: x = [F^{ttt}_1]_{tt}, and F = F^{ttt}_t = [[A, B], [C, D]] with
rows and columns in the order 1, t.  The six pentagon instances it uses are listed by
(e, f, g, k, l) in K13's equation
    [F^{fcd}_e]_{gl} [F^{abl}_e]_{fk} = sum_h [F^{abc}_g]_{fh} [F^{ahd}_e]_{gk} [F^{bcd}_k]_{hl}
with a = b = c = d = t.

Run:  python3 scripts/check-l6-algebra.py     (exit status 1 on failure)
"""
import itertools
import pathlib
import sys

import sympy as sp

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from pentagon import fibonacci, unknowns  # noqa: E402

FAILS = []


def check(label, kind, ok, what):
    print(f"{'OK  ' if ok else 'FAIL'} [{kind:9s}] {label}: {what}")
    if not ok:
        FAILS.append(label)


L, N, _ = fibonacci()
Fsym = unknowns(L, N)
x, A, B, C, D = sp.symbols('Fttt1_tt Ftttt_11 Ftttt_1t Ftttt_t1 Ftttt_tt')


def pentagon(e, f, g, k, l, F=Fsym):
    a = b = c = d = 't'
    G = lambda *key: F.get(key, 0)                     # noqa: E731
    lhs = G(f, c, d, e, g, l) * G(a, b, l, e, f, k)
    rhs = sum(G(a, b, c, g, f, h) * G(a, h, d, e, g, k) * G(b, c, d, k, h, l) for h in L)
    return sp.expand(lhs - rhs)


# The six instances the passage prints, as (e, f, g, k, l) -> the printed equation lhs - rhs.
PRINTED = {
    'eq:6:p1': (('t', '1', 't', '1', 't'), A - x * B * C),             # A = x B C
    'eq:6:p2': (('t', 't', '1', '1', 't'), B * C - x**2 * A),          # B C = x^2 A
    'eq:6:p3': (('1', '1', 't', 't', '1'), 1 - x * B * C - A**2),      # x B C + A^2 = 1
    'eq:6:p4': (('t', '1', 't', 't', '1'), A**2 + B * C * D),          # A^2 + B C D = 0
    'eq:6:p5': (('t', 't', '1', 't', 't'), B * D - x * B * D),         # B D = x B D
    'eq:6:p6': (('1', 't', 't', 't', 't'), x**2 - x * D**2 - B * C),   # x^2 = x D^2 + B C
}
for label, (inst, printed) in PRINTED.items():
    got = pentagon(*inst)
    check(label, 'SYMBOLIC', sp.expand(got - printed) == 0 or sp.expand(got + printed) == 0,
          f'pentagon instance (e,f,g,k,l) = {inst} is the printed equation')
    wrong_total = ('1' if inst[0] == 't' else 't',) + inst[1:]
    wrong_equation = pentagon(*wrong_total)
    check(label + ' (index control)', 'SYMBOLIC',
          sp.expand(wrong_equation - printed) != 0 and sp.expand(wrong_equation + printed) != 0,
          'changing total charge e gives the same scalar equation -- must fail, and does')

# The passage's argument, step by step.
check('eq:6:p1-p2', 'SYMBOLIC', sp.expand((A - x * B * C).subs(B * C, x**2 * A)) == sp.expand(A * (1 - x**3)),
      'A = x B C and B C = x^2 A give A (1 - x^3) = 0')
check('eq:6:p3 => A != 0', 'SYMBOLIC', sp.expand((1 - x * B * C - A**2).subs({A: 0, B: 0})) == 1,
      'with A = 0 = x B C, the third instance reads 0 = 1')
check('eq:6:p4 => D != 0', 'SYMBOLIC', sp.expand((A**2 + B * C * D).subs(D, 0)) == A**2,
      'with D = 0 the fourth instance reads A^2 = 0, against A != 0')
sols = sp.solve([A**2 + A - 1], [A], dict=True)
phi = (1 + sp.sqrt(5)) / 2
vals = sorted([sp.nsimplify(s[A]) for s in sols], key=float)
check('eq:6:quadratic', 'SYMBOLIC', [sp.simplify(v - t) for v, t in zip(vals, [-phi, 1 / phi])] == [0, 0],
      'A^2 + A = 1 has the roots 1/phi and -phi')
check('eq:6:D', 'SYMBOLIC', sp.expand((A**2 + B * C * D).subs({B * C: A, D: -A})) == 0,
      'with x = 1 and B C = A, the fourth instance gives D = -A')
check('eq:6:p6 consistent', 'SYMBOLIC',
      all(sp.simplify((x**2 - x * D**2 - B * C).subs({x: 1, D: -v, B * C: v}).subs(B * C, v)
                      .subs({B: 1, C: v})) == 0 for v in vals),
      'the sixth instance then holds for both roots')

# Every pentagon equation (not only the six printed) holds for the solution.
for a_val in vals:
    sq = sp.sqrt(a_val)
    sub = {x: 1, A: a_val, B: sq, C: sq, D: -a_val}
    Fnum = {k: (sp.sympify(v).subs(sub)) for k, v in Fsym.items()}
    allok = all(sp.simplify(pentagon(*inst, F=Fnum)) == 0
                for inst in itertools.product(L, repeat=5))
    rest = all(sp.simplify(sp.expand(
        Fnum.get((f, c, d, e, g, l), 0) * Fnum.get((a, b, l, e, f, k), 0)
        - sum(Fnum.get((a, b, c, g, f, h), 0) * Fnum.get((a, h, d, e, g, k), 0)
              * Fnum.get((b, c, d, k, h, l), 0) for h in L))) == 0
        for a, b, c, d, e, f, g, k, l in itertools.product(L, repeat=9))
    check(f'thm:6:fib(A = {a_val})', 'SYMBOLIC', allok and rest,
          'x = 1, F = [[A, sqrt A], [sqrt A, -A]] solves every pentagon equation')

# Unitarity: F unitary needs |A|^2 + |B|^2 = 1 with B C = A; the symmetric unitary gauge.
Fu = sp.Matrix([[1 / phi, 1 / sp.sqrt(phi)], [1 / sp.sqrt(phi), -1 / phi]])
check('eq:6:unitary', 'SYMBOLIC', sp.simplify(Fu * Fu.H - sp.eye(2)) == sp.zeros(2, 2),
      '[[1/phi, phi^{-1/2}], [phi^{-1/2}, -1/phi]] is unitary')
check('eq:6:yanglee', 'SYMBOLIC', sp.simplify(phi**2 - 1) > 0,
      'A = -phi has |A| > 1, so no unitary F has it (a unitary matrix has entries of modulus <= 1)')
check('eq:6:1/phi', 'SYMBOLIC', sp.simplify(1 - 1 / phi**2 - 1 / phi) == 0,
      '|B|^2 = 1 - A^2 = 1/phi for A = 1/phi, so B = C = phi^{-1/2} in the symmetric gauge')

# ================================================================ the lecture beyond the costed passage
import cmath  # noqa: E402
import math  # noqa: E402
import random  # noqa: E402

import anyons  # noqa: E402


def control(label, kind, failed, what):
    check(label + ' (control)', kind, failed, what + ' -- must fail, and does')


def pent_defect(Lb, Ff):
    """max |lhs - rhs| of K13's pentagon over all labels, F given as a function."""
    worst = 0
    for a, b, c, d, e, f, g, l, k in itertools.product(Lb, repeat=9):
        lhs = Ff(f, c, d, e, g, l) * Ff(a, b, l, e, f, k)
        rhs = sum(Ff(a, b, c, g, f, h) * Ff(a, h, d, e, g, k) * Ff(b, c, d, k, h, l) for h in Lb)
        worst = max(worst, abs(complex(lhs - rhs)))
    return worst


# ex:6:vecg -- for Vec_G^omega, F^{ghk}_{ghk} = omega(g,h,k) (1x1) and K13's pentagon at
# (a,b,c,d) = (g,h,k,m) is L3's cocycle condition (f = gh, l = km, g' = ghk, h' = hk, k' = hkm)
def pointed(n, om):
    Lz = list(range(n))

    def Ff(a, b, c, d, e, f):
        if e == (a + b) % n and f == (b + c) % n and d == (a + b + c) % n:
            return om(a, b, c)
        return 0
    return Lz, Ff


def omega_p(n, p_):
    return lambda a, b, c: cmath.exp(2j * math.pi * p_ * a * (b + c - (b + c) % n) / n ** 2)


ok = True
for n_ in (2, 3, 4):
    for p_ in range(n_):
        ok &= pent_defect(*pointed(n_, omega_p(n_, p_))) < 1e-9
check('ex:6:vecg', 'NUMERICAL', ok, 'F^{ghk} = omega_p(g,h,k) solves the pentagon for Z_N, N = 2, 3, 4 (L3\'s cocycles)')
w = sp.Function('omega')
nZ = 3
Lz3, Fz3 = pointed(nZ, lambda a, b, c: w(a, b, c))
ok = True
for g_, h_, k_, m_ in itertools.product(Lz3, repeat=4):
    e_, f_, l_ = (g_ + h_ + k_ + m_) % nZ, (g_ + h_) % nZ, (k_ + m_) % nZ
    gg, hh, kk = (g_ + h_ + k_) % nZ, (h_ + k_) % nZ, (h_ + k_ + m_) % nZ
    lhs = Fz3(f_, k_, m_, e_, gg, l_) * Fz3(g_, h_, l_, e_, f_, kk)
    rhs = sum(Fz3(g_, h_, k_, gg, f_, x_) * Fz3(g_, x_, m_, e_, gg, kk) * Fz3(h_, k_, m_, kk, x_, l_) for x_ in Lz3)
    cocycle = (w((g_ + h_) % nZ, k_, m_) * w(g_, h_, (k_ + m_) % nZ)
               - w(g_, h_, k_) * w(g_, (h_ + k_) % nZ, m_) * w(h_, k_, m_))
    ok &= sp.expand(lhs - rhs - cocycle) == 0
check('ex:6:vecg(cocycle)', 'SYMBOLIC', ok,
      'for Z3 with symbolic omega, the pentagon at (g,h,k,m) is L3\'s cocycle condition, term by term')
random.seed(1)
rnd = {t: cmath.exp(2j * math.pi * random.random()) for t in itertools.product(range(3), repeat=3)}
control('ex:6:vecg', 'NUMERICAL', pent_defect(*pointed(3, lambda a, b, c: 1 if 0 in (a, b, c) else rnd[(a, b, c)])) > 1e-3,
        'random normalised phases on Z3 solve the pentagon')
# ex:6:z2 -- Z2: F^{sss}_s = omega(s,s,s) = +-1, and kappa_s = d_s F = omega(s,s,s) (K16)
check('ex:6:z2', 'NUMERICAL', all(pent_defect(*pointed(2, lambda a, b, c, e=e_: e if a == b == c == 1 else 1)) < 1e-12
                                  for e_ in (1, -1))
      and pent_defect(*pointed(2, lambda a, b, c: 1j if a == b == c == 1 else 1)) > 1e-3,
      'on Z2, F^{sss}_s = +1 and -1 solve the pentagon, i does not')

# thm:6:gauge -- the gauge formula (K15) preserves the pentagon (random unit u, Fibonacci and Ising)
random.seed(2)
fib, isi = anyons.fibonacci(), anyons.ising(1)
ok = True
for M in (fib, isi):
    u = {(a, b, c): cmath.exp(2j * math.pi * random.random())
         for a, b, c in itertools.product(M.L, repeat=3) if M.N(a, b, c) and '1' not in (a, b)}
    ok &= M.gauged(u).pentagon_defect() < 1e-9
check('thm:6:gauge', 'NUMERICAL', ok, 'a gauge transformation with |u| = 1 maps solutions to solutions')
# the Fibonacci entries under the gauge u^{tt}_1 = p, u^{tt}_t = q
pp, qq = sp.symbols('p q', nonzero=True)
uu = {('t', 't', '1'): pp, ('t', 't', 't'): qq}
G = lambda a, b, c: uu.get((a, b, c), 1)                       # noqa: E731
fac = lambda a, b, c, d, e, f: sp.simplify(G(a, f, d) * G(b, c, f) / (G(a, b, e) * G(e, c, d)))  # noqa: E731
facs = {'x': fac('t', 't', 't', '1', 't', 't'), 'A': fac('t', 't', 't', 't', '1', '1'),
        'B': fac('t', 't', 't', 't', '1', 't'), 'C': fac('t', 't', 't', 't', 't', '1'),
        'D': fac('t', 't', 't', 't', 't', 't')}
check('thm:6:gauge(fib)', 'SYMBOLIC',
      facs['x'] == 1 and facs['A'] == 1 and facs['D'] == 1 and sp.simplify(facs['B'] - qq ** 2 / pp) == 0
      and sp.simplify(facs['B'] * facs['C'] - 1) == 0,
      'x, A, D and BC are gauge invariant; B -> (q^2/p) B, C -> (p/q^2) C')
check('thm:6:fib(sign)', 'SYMBOLIC', sp.simplify(facs['B'].subs({pp: 1, qq: sp.I}) + 1) == 0,
      'u^{tt}_t = i (u^{tt}_1 = 1) flips the signs of B and C: the gauge left over')
# the invariant kappa_a = d_a [F^{a a a}_a]_{11}: Ising's kappa survives a random gauge
random.seed(3)
ok = True
for kap in (1, -1):
    M = anyons.ising(1, kappa=kap)
    u = {(a, b, c): cmath.exp(2j * math.pi * random.random())
         for a, b, c in itertools.product(M.L, repeat=3) if M.N(a, b, c) and '1' not in (a, b)}
    ok &= abs(M.gauged(u).kappa('s') - kap) < 1e-12
check('thm:6:ising(invariant)', 'NUMERICAL', ok, 'kappa = d_sigma [F^{sss}_s]_{11} is unchanged by a random gauge')
# but an off-diagonal entry is not invariant (the trap: a gauge-dependent entry quoted as physical)
Mg = anyons.ising(1).gauged({('s', 's', 'p'): 1j})
control('thm:6:gauge(entries)', 'NUMERICAL', abs(Mg.F('s', 's', 's', 's', '1', 'p') - anyons.ising(1).F('s', 's', 's', 's', '1', 'p')) > 1e-9,
        '[F^{sss}_s]_{1 psi} is gauge invariant')

# thm:6:fib, the dimension: [F^{ttt}_t]_{11} = kappa_t / d_t with kappa_t = 1 (K16): d = phi, Yang-Lee d = -1/phi
check('thm:6:fib(d)', 'SYMBOLIC', sp.simplify(1 / (1 / phi) - phi) == 0 and sp.simplify(1 / (-phi) + 1 / phi) == 0,
      '1/A = phi for A = 1/phi; 1/A = -1/phi for the Yang-Lee root A = -phi')
check('thm:6:fib(involution)', 'SYMBOLIC', sp.simplify(Fu * Fu - sp.eye(2)) == sp.zeros(2, 2),
      'F^{ttt}_t is its own inverse (real, symmetric, unitary)')
Fyl = sp.Matrix([[-phi, sp.sqrt(-phi)], [sp.sqrt(-phi), phi]])
check('thm:6:fib(Yang-Lee)', 'SYMBOLIC', sp.simplify(Fyl * Fyl - sp.eye(2)) == sp.zeros(2, 2)
      and sp.simplify((Fyl * Fyl.H)[0, 0] - 1) != 0,
      'the Yang-Lee F (A = -phi, B = C = sqrt(-phi)) squares to 1 but is not unitary')

# thm:6:ising -- kappa H with F^{s p s}_p = F^{p s p}_s = -1 solves every pentagon, kappa = +-1
check('thm:6:ising', 'NUMERICAL', all(anyons.ising(1, kappa=kap).pentagon_defect() < 1e-12 for kap in (1, -1)),
      'F^{sss}_s = kappa H, F^{sps}_p = F^{psp}_s = -1, others 1: every pentagon, kappa = +1 and -1')
Hm = sp.Matrix([[1, 1], [1, -1]]) / sp.sqrt(2)
Lis = ['1', 's', 'p']
check('thm:6:ising(H)', 'SYMBOLIC', sp.simplify(Hm * Hm.H - sp.eye(2)) == sp.zeros(2, 2)
      and all(sp.simplify(sp.sqrt(2) * kap * Hm[0, 0] - kap) == 0 for kap in (1, -1)),
      'kappa H is unitary and kappa = d_sigma [kappa H]_{11} with d_sigma = sqrt 2')
# Ising, exactly: F with entries in Q(sqrt 2), extended by 0 where the trees do not exist (Def 6.1),
# F^{sps}_p = y symbolic; every pentagon instance is checked with exact arithmetic
yv, kv = sp.symbols('y kappa')
fuseI = {('s', 's'): {'1', 'p'}, ('s', 'p'): {'s'}, ('p', 's'): {'s'}, ('p', 'p'): {'1'}}
NI = lambda a, b, c: (a == '1' and b == c) or (b == '1' and a == c) or ('1' not in (a, b) and c in fuseI[(a, b)])  # noqa: E731


def FI(a, b, c, d, e, f, kap, y):
    if not (NI(a, b, e) and NI(e, c, d) and NI(b, c, f) and NI(a, f, d)):
        return 0
    if '1' in (a, b, c):
        return 1
    if (a, b, c, d) == ('s', 's', 's', 's'):
        return kap * Hm['1p'.index(e), '1p'.index(f)]
    if (a, b, c, d) == ('s', 'p', 's', 'p'):
        return y
    if (a, b, c, d) == ('p', 's', 'p', 's'):
        return -1
    return 1


def pentI(a, b, c, d, e, f, g, k, l, kap, y):
    lhs = FI(f, c, d, e, g, l, kap, y) * FI(a, b, l, e, f, k, kap, y)
    rhs = sum(FI(a, b, c, g, f, h, kap, y) * FI(a, h, d, e, g, k, kap, y) * FI(b, c, d, k, h, l, kap, y) for h in Lis)
    return sp.expand(lhs - rhs)


# the instance printed in S6.5: a = b = c = d = sigma, e = psi, f = 1, g = sigma, k = sigma, l = 1
inst_i = pentI('s', 's', 's', 's', 'p', '1', 's', 's', '1', kv, yv)
lhs_i = sp.expand(FI('1', 's', 's', 'p', 's', '1', kv, yv) * FI('s', 's', '1', 'p', '1', 's', kv, yv))
check('eq:6:isinginst', 'SYMBOLIC', lhs_i == 0 and sp.expand(inst_i + kv ** 2 * (1 + yv) / 2) == 0
      and sp.solve(inst_i.subs(kv, 1), yv) == [-1],
      'the instance reads 0 = kappa^2 (1 + [F^{s p s}_p]) / 2 (the left side computed: its trees do not exist), so -1')
check('thm:6:ising(exact)', 'EXACT', all(pentI(*t, kap, -1) == 0 for kap in (1, -1) for t in itertools.product(Lis, repeat=9)),
      'every one of the 3^9 pentagon instances holds exactly, in Q(sqrt 2), for kappa = +1 and -1')
control('thm:6:ising(exact)', 'EXACT', any(pentI(*t, 1, 1) != 0 for t in itertools.product(Lis, repeat=9)),
        'F^{sps}_p = +1 (the other entries as printed) solves every instance')
# Admissible matrices versus symbols extended by zero (the distinction in Def. 6.1).
ising_left = [e for e in Lis if NI('s', 's', e) and NI(e, 's', 's')]
ising_right = [f for f in Lis if NI('s', 's', f) and NI('s', f, 's')]
ising_admissible = sp.Matrix([[FI('s', 's', 's', 's', e, f, 1, -1)
                              for f in ising_right] for e in ising_left])
ising_padded = sp.Matrix([[FI('s', 's', 's', 's', e, f, 1, -1) for f in Lis] for e in Lis])
check('def:6:fsymbol(admissible)', 'EXACT', ising_left == ising_right == ['1', 'p']
      and ising_admissible == Hm and ising_admissible.H * ising_admissible == sp.eye(2),
      'only admissible channels 1, psi index the unitary Ising 2x2 F-matrix')
control('def:6:fsymbol(admissible)', 'EXACT', ising_padded.H * ising_padded != sp.eye(3),
        'padding by the inadmissible sigma row and column keeps the matrix unitary')
# A phase gauge preserves unitarity; a non-phase gauge need not.
phase_B, phase_C = sp.I * Fu[0, 1], -sp.I * Fu[1, 0]
phase_F = sp.Matrix([[Fu[0, 0], phase_B], [phase_C, Fu[1, 1]]])
nonphase_F = sp.Matrix([[Fu[0, 0], 2 * Fu[0, 1]], [Fu[1, 0] / 2, Fu[1, 1]]])
check('summary:6:unitary gauge', 'EXACT', sp.simplify(phase_F.H * phase_F - sp.eye(2)) == sp.zeros(2),
      'the Fibonacci gauge q^2/p = i preserves unitarity')
control('summary:6:unitary gauge', 'EXACT', sp.simplify(nonphase_F.H * nonphase_F - sp.eye(2)) != sp.zeros(2),
        'the non-phase Fibonacci gauge q^2/p = 2 preserves unitarity')
# the printed -1 is gauge dependent: u^{ps}_s = -1 flips F^{sps}_p and the (psi, psi) entry of kappa H, not kappa
Mg6 = anyons.ising(1).gauged({('p', 's', 's'): -1.0})
check('thm:6:ising(gauge)', 'NUMERICAL', abs(Mg6.F('s', 'p', 's', 'p', 's', 's') - 1) < 1e-12
      and abs(Mg6.F('s', 's', 's', 's', 'p', 'p') - anyons.ising(1).F('s', 's', 's', 's', 'p', 'p')) > 1e-3
      and abs(Mg6.kappa('s') - 1) < 1e-12 and Mg6.pentagon_defect() < 1e-12,
      'u^{psi sigma}_sigma -> -u flips F^{s p s}_p to +1 and changes [kappa H]_{psi psi}; kappa and the pentagon stay')


Mbad = anyons.Model('Ising, F^{sps}_p = +1', isi.L, isi._N,
                    lambda a, b, c, d, e, f: 1.0 if (a, b, c, d) in {('s', 'p', 's', 'p'), ('p', 's', 'p', 's')}
                    else isi._F(a, b, c, d, e, f), isi._R, isi.d)
control('thm:6:ising', 'NUMERICAL', Mbad.pentagon_defect() > 1e-3, 'F^{sps}_p = F^{psp}_s = +1 solves the pentagon')
# the Ising unknowns: which F-symbols are not forced to 1 by a unit leg
Lis = ["1", "s", "p"]
Nis = lambda a, b, c: isi.N(a, b, c)                            # noqa: E731
Fis = unknowns(Lis, Nis)
blocks = sorted({k[:4] for k, v in Fis.items() if v != 1})
check('rem:6:isingunknowns', 'EXACT', len(blocks) == 11 and ('s', 's', 's', 's') in blocks,
      'Ising has 11 F-blocks with no unit leg (one 2x2, F^{sss}_s; ten 1x1)')

# ex:6:vecg(gauge) -- for Vec_G^omega a gauge u(g,h) multiplies omega by the coboundary
# u(g,hk) u(h,k) / (u(g,h) u(gh,k)) = (delta u)(g,h,k) (K20's delta), i.e. a monoidal functor with j = 1/u
G3 = range(3)
uz = {(a_, b_): sp.Symbol(f'u{a_}{b_}') if 0 not in (a_, b_) else sp.Integer(1) for a_ in G3 for b_ in G3}
ok = True
for g_, h_, k_ in itertools.product(G3, repeat=3):
    fac_ = uz[(g_, (h_ + k_) % 3)] * uz[(h_, k_)] / (uz[(g_, h_)] * uz[((g_ + h_) % 3, k_)])   # K15 factor
    jz = {key: sp.Integer(1) / v for key, v in uz.items()}
    delta_j = jz[(h_, k_)] * jz[(g_, (h_ + k_) % 3)] / (jz[((g_ + h_) % 3, k_)] * jz[(g_, h_)])
    ok &= sp.simplify(fac_ - 1 / delta_j) == 0
check('ex:6:vecg(gauge)', 'SYMBOLIC', ok,
      'the gauge factor on F^{ghk} is (delta u)(g,h,k) = (delta j)^{-1} with j = 1/u: L3\'s omega\' = omega (delta j)^{-1}')
# eq:6:fibd -- F^{ttt}_t = [[1/d, d^{-1/2}], [d^{-1/2}, -1/d]] is unitary iff d^2 = d + 1 (d > 0)
dd = sp.Symbol('d', positive=True)
Fd = sp.Matrix([[1 / dd, 1 / sp.sqrt(dd)], [1 / sp.sqrt(dd), -1 / dd]])
row = sp.simplify((Fd * Fd.T)[0, 0] - 1)
# (the d-form of F was cut from L6 at C.3 round 1; kept here as Sheet 6's seed)
check('sheet6:fibd', 'SYMBOLIC', sp.solve(row, dd) == [phi] and sp.simplify(Fd.subs(dd, phi) - Fu) == sp.zeros(2, 2),
      'the d-form of F is unitary exactly when d^2 = d + 1, i.e. d = phi, and then it is the printed F')
# eq:6:fmovetau -- the F-move for three taus with e = 1: L_1 = phi^{-1} R_1 + phi^{-1/2} R_tau (row e = 1)
check('eq:6:fmovetau', 'SYMBOLIC', list(Fu.row(0)) == [1 / phi, 1 / sp.sqrt(phi)],
      'row e = 1 of F^{ttt}_t: coefficients phi^{-1} (f = 1) and phi^{-1/2} (f = tau)')
# eq:6:inverse -- the inverse F-move: R_f = sum_e conj([F]_{ef}) L_e (unitarity, alpha^{-1})
check('eq:6:inverse', 'SYMBOLIC', sp.simplify(Fu.inv() - Fu.H) == sp.zeros(2, 2),
      'F^{-1} = F^dagger: the inverse F-move has coefficients conj(F_{ef}), summed over e')
# the instance read in S6.4: (e,f,g,k,l) = (1,1,t,t,1): 1 = A^2 + x B C
check('eq:6:p3(read)', 'SYMBOLIC', sp.expand(pentagon('1', '1', 't', 't', '1') - (1 - A ** 2 - x * B * C)) == 0
      or sp.expand(pentagon('1', '1', 't', 't', '1') + (1 - A ** 2 - x * B * C)) == 0,
      'with a = b = c = d = tau and (e,f,g,k,l) = (1,1,tau,tau,1): 1 = A^2 + x B C, read term by term')
# eq:6:fmovesigma -- row e = 1 of kappa H: kappa/sqrt2 (f = 1) and kappa/sqrt2 (f = psi)
check('eq:6:fmovesigma', 'SYMBOLIC', all(list((kap * Hm).row(0)) == [kap / sp.sqrt(2), kap / sp.sqrt(2)] for kap in (1, -1)),
      'the sigma F-move from e = 1: kappa/sqrt2 times (the f = 1 tree + the f = psi tree)')
# thm:6:ocneanu in F-symbols (C.3 L6 r1): B = r sqrt(A), C = sqrt(A)/r (r > 0) solves the pentagon for every r;
# |u| = 1 cannot change |B|, but u^{tt}_1 = 1, u^{tt}_t = sqrt(r) (u != 0) maps the symmetric solution to it
rr = sp.Symbol('r', positive=True)
ok = True
for a_val in vals:
    sq = sp.sqrt(a_val)
    sub = {x: 1, A: a_val, B: rr * sq, C: sq / rr, D: -a_val}
    Fr = {k: sp.sympify(v).subs(sub) for k, v in Fsym.items()}
    ok &= all(sp.simplify(sp.expand(
        Fr.get((f, c, d, e, g, l), 0) * Fr.get((a, b, l, e, f, k), 0)
        - sum(Fr.get((a, b, c, g, f, h), 0) * Fr.get((a, h, d, e, g, k), 0) * Fr.get((b, c, d, k, h, l), 0) for h in L))) == 0
        for a, b, c, d, e, f, g, k, l in itertools.product(L, repeat=9))
    ok &= sp.simplify(facs['B'].subs({pp: 1, qq: sp.sqrt(rr)}) - rr) == 0 and sp.simplify(facs['C'].subs({pp: 1, qq: sp.sqrt(rr)}) - 1 / rr) == 0
check('thm:6:ocneanu(gauge)', 'SYMBOLIC', ok,
      'for symbolic r > 0 the family B = r sqrt A, C = sqrt A / r solves all 2^9 pentagon instances, and the gauge q = sqrt r (not a phase) reaches it')
# thm:6:gauge with u != 0: a non-phase gauge keeps the pentagon (Ising, real u)
import random as _r  # noqa: E402
_r.seed(5)
Mi = anyons.ising(1)
ureal = {(a, b, c): 0.5 + 2 * _r.random() for a, b, c in itertools.product(Mi.L, repeat=3) if Mi.N(a, b, c) and '1' not in (a, b)}
Mgr = Mi.gauged(ureal)
check('thm:6:gauge(u != 0)', 'NUMERICAL', all(abs(abs(x_) - 1) > 1e-3 for x_ in ureal.values())
      and Mgr.pentagon_defect() < 1e-10 and abs(Mgr.kappa('s') - 1) < 1e-12,
      'a gauge with real u not of modulus 1 keeps every pentagon instance and kappa')
# rem:6:count -- the Fibonacci pentagon: distinct non-trivial equations
from pentagon import pentagon_equations  # noqa: E402
eqsF = pentagon_equations(L, Fsym)
check('rem:6:count', 'EXACT', len(Fsym) - sum(1 for v in Fsym.values() if v == 1) == 5 and len(eqsF) == 12,
      f'Fibonacci: 5 unknowns (x, A, B, C, D), {len(eqsF)} distinct non-trivial pentagon equations')
print('    Fibonacci pentagon equations:', len(eqsF))

print()
if FAILS:
    print(f'{len(FAILS)} FAILED: ' + ', '.join(FAILS))
    sys.exit(1)
print('All L6 checks pass.')
